"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, EyeOff, Settings, ChevronDown, Plus, Trash2, Download, Upload, FileSpreadsheet, FileJson, CheckCircle } from "lucide-react";
import useWidgetStore from "../../store/useWidgetStore";
import { initialMetinList } from "../../data/initialData";
import { exportMetinsToExcel, parseMetinImport } from "../../lib/excelUtils";

const formatNumber = (num) => {
    return new Intl.NumberFormat('tr-TR').format(num);
};

// ============================================================================
// SUMMARY VIEW
// ============================================================================
function MetinSettingsSummaryView({ metins }) {
    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden px-4">
            <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-white/10 backdrop-blur-sm rounded-lg border border-white/10">
                    <Settings className="w-8 h-8 text-purple-400" />
                </div>
            </div>
            <span className="text-3xl font-bold text-white whitespace-nowrap">
                Metin Ayarları
            </span>
            <span className="text-sm text-white/60 mt-2">
                {metins.length} Metin Tanımlı
            </span>
        </div>
    );
}

// ============================================================================
// ACCORDION ITEM
// ============================================================================
function MetinAccordionItem({ metin, isOpen, onToggle, onUpdateHP, onAddDrop, onRemoveDrop, onUpdateDrop }) {
    const marketItems = useWidgetStore((state) => state.marketItems);
    const [selectedItemId, setSelectedItemId] = useState(
        marketItems[0]?.originalId || ""
    );

    const getItemByOriginalId = (originalId) => {
        return marketItems.find((item) => item.originalId === originalId);
    };

    const handleHpChange = (newHp) => {
        const hp = parseFloat(newHp);
        if (!isNaN(hp) && hp > 0) {
            onUpdateHP(metin.id, hp);
        }
    };

    const handleDropChange = (dropId, field, value) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue) && numValue >= 0) {
            onUpdateDrop(metin.id, dropId, field, numValue);
        }
    };

    const handleAddDrop = () => {
        if (selectedItemId) {
            const exists = metin.drops.some((d) => d.itemId === selectedItemId);
            if (exists) {
                alert("Bu eşya zaten bu metinde ekli!");
                return;
            }
            onAddDrop(metin.id, selectedItemId);
        }
    };

    const handleRemoveDrop = (dropId) => {
        if (confirm("Bu drop'u silmek istediğinizden emin misiniz?")) {
            onRemoveDrop(metin.id, dropId);
        }
    };

    return (
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/20 overflow-hidden">
            <button
                onClick={onToggle}
                className="w-full flex items-center justify-between p-4 hover:bg-white/10 transition-colors"
            >
                <div className="flex items-center gap-3">
                    <motion.div
                        animate={{ rotate: isOpen ? 180 : 0 }}
                        transition={{ duration: 0.2 }}
                    >
                        <ChevronDown className="w-5 h-5 text-white/60" />
                    </motion.div>
                    <h3 className="text-lg font-semibold text-white">{metin.name}</h3>
                </div>
                <div className="flex items-center gap-3">
                    <span className="text-sm text-white/60">
                        HP: {formatNumber(metin.hp)}
                    </span>
                    <span className="text-sm text-white/60">
                        {metin.drops.length} Drop
                    </span>
                </div>
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="bg-black/20 border-t border-white/10"
                    >
                        <div className="p-4 space-y-4">
                            {/* HP Input */}
                            <div>
                                <label className="block text-sm font-semibold text-white/80 mb-2">
                                    Metin HP
                                </label>
                                <input
                                    type="number"
                                    value={metin.hp}
                                    onChange={(e) => handleHpChange(e.target.value)}
                                    className="w-full px-3 py-2 font-semibold text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:bg-black/40 placeholder:text-white/40"
                                    min="1"
                                    step="1000"
                                />
                            </div>

                            {/* Drops List */}
                            <div>
                                <h4 className="text-sm font-semibold text-white/80 mb-2">
                                    Drop Listesi
                                </h4>
                                <div className="space-y-2">
                                    {metin.drops.map((drop) => {
                                        const item = getItemByOriginalId(drop.itemId);
                                        return (
                                            <div
                                                key={drop.id}
                                                className="bg-white/5 backdrop-blur-sm p-3 rounded-lg border border-white/10"
                                            >
                                                <div className="flex items-center justify-between mb-2">
                                                    <span className="text-white font-medium">
                                                        {item?.name || drop.itemId}
                                                    </span>
                                                    <button
                                                        onClick={() => handleRemoveDrop(drop.id)}
                                                        className="p-1 hover:bg-red-500/20 rounded transition-colors"
                                                    >
                                                        <Trash2 className="w-4 h-4 text-red-400" />
                                                    </button>
                                                </div>
                                                <div className="grid grid-cols-2 gap-2">
                                                    <div>
                                                        <label className="block text-xs text-white/60 mb-1">
                                                            Adet
                                                        </label>
                                                        <input
                                                            type="number"
                                                            value={drop.count}
                                                            onChange={(e) =>
                                                                handleDropChange(drop.id, "count", e.target.value)
                                                            }
                                                            className="w-full px-2 py-1 text-sm font-medium text-white bg-black/30 border border-white/10 rounded focus:outline-none focus:ring-1 focus:ring-purple-500/50"
                                                            min="1"
                                                        />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs text-white/60 mb-1">
                                                            Şans (%)
                                                        </label>
                                                        <input
                                                            type="number"
                                                            value={drop.chance}
                                                            onChange={(e) =>
                                                                handleDropChange(drop.id, "chance", e.target.value)
                                                            }
                                                            className="w-full px-2 py-1 text-sm font-medium text-white bg-black/30 border border-white/10 rounded focus:outline-none focus:ring-1 focus:ring-purple-500/50"
                                                            min="0"
                                                            max="100"
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>

                            {/* Add Drop */}
                            <div className="pt-2 border-t border-white/10">
                                <h4 className="text-sm font-semibold text-white/80 mb-2">
                                    Yeni Drop Ekle
                                </h4>
                                <div className="flex gap-2">
                                    <select
                                        value={selectedItemId}
                                        onChange={(e) => setSelectedItemId(e.target.value)}
                                        className="flex-1 px-3 py-2 font-medium text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                                    >
                                        {marketItems.map((item) => (
                                            <option
                                                key={item.id}
                                                value={item.originalId}
                                                className="bg-zinc-900"
                                            >
                                                {item.name}
                                            </option>
                                        ))}
                                    </select>
                                    <button
                                        onClick={handleAddDrop}
                                        className="px-4 py-2 bg-green-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-green-600 transition-colors font-medium border border-green-500/30 flex items-center gap-2"
                                    >
                                        <Plus className="w-4 h-4" />
                                        Ekle
                                    </button>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW
// ============================================================================
function MetinSettingsDetailView({ widgetId, metins }) {
    const updateWidgetData = useWidgetStore((state) => state.updateWidgetData);
    const marketItems = useWidgetStore((state) => state.marketItems);
    const syncImportedItems = useWidgetStore((state) => state.syncImportedItems);

    const [openMetinId, setOpenMetinId] = useState(null);
    const [showDataModal, setShowDataModal] = useState(false);
    const [dataModalTab, setDataModalTab] = useState("export");
    const [successMessage, setSuccessMessage] = useState("");
    const [isDragging, setIsDragging] = useState(false);

    const handleUpdateHP = (metinId, newHP) => {
        const updated = metins.map((m) =>
            m.id === metinId ? { ...m, hp: newHP } : m
        );
        updateWidgetData(widgetId, { metins: updated });
    };

    const handleAddDrop = (metinId, itemId) => {
        const updated = metins.map((m) => {
            if (m.id === metinId) {
                return {
                    ...m,
                    drops: [
                        ...m.drops,
                        {
                            id: crypto.randomUUID(),
                            itemId,
                            count: 1,
                            chance: 10,
                        },
                    ],
                };
            }
            return m;
        });
        updateWidgetData(widgetId, { metins: updated });
    };

    const handleRemoveDrop = (metinId, dropId) => {
        const updated = metins.map((m) => {
            if (m.id === metinId) {
                return {
                    ...m,
                    drops: m.drops.filter((d) => d.id !== dropId),
                };
            }
            return m;
        });
        updateWidgetData(widgetId, { metins: updated });
    };

    const handleUpdateDrop = (metinId, dropId, field, value) => {
        const updated = metins.map((m) => {
            if (m.id === metinId) {
                return {
                    ...m,
                    drops: m.drops.map((d) =>
                        d.id === dropId ? { ...d, [field]: value } : d
                    ),
                };
            }
            return m;
        });
        updateWidgetData(widgetId, { metins: updated });
    };

    // Export handler
    const handleExport = async (format) => {
        if (format === 'excel') {
            const result = await exportMetinsToExcel(metins, marketItems, `metin-listesi-${Date.now()}`);
            if (result.success) {
                setSuccessMessage('Excel dosyası başarıyla indirildi!');
                setTimeout(() => setSuccessMessage(""), 3000);
            }
        } else if (format === 'json') {
            // JSON export
            const jsonString = JSON.stringify(metins, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `metin-listesi-${Date.now()}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            setSuccessMessage('JSON dosyası başarıyla indirildi!');
            setTimeout(() => setSuccessMessage(""), 3000);
        }
    };

    // Import handler
    const handleImport = async (file) => {
        try {
            // Step 1: Parse file
            const result = await parseMetinImport(file);

            if (!result.success) {
                alert(result.message);
                return;
            }

            const { metinList, detectedItems } = result;

            // Step 2: Sync imported items with market
            const idMap = syncImportedItems(detectedItems);

            // Step 3: Replace temp IDs with real market IDs
            const updatedMetinList = metinList.map(metin => ({
                ...metin,
                drops: metin.drops.map(drop => ({
                    ...drop,
                    itemId: idMap[drop.itemId] || drop.itemId
                }))
            }));

            // Step 4: Save to widget data
            updateWidgetData(widgetId, { metins: updatedMetinList });

            // Step 5: Show success message
            const newItemsCount = Object.keys(idMap).filter(tempId => {
                const realId = idMap[tempId];
                return detectedItems.some(item => item.tempId === tempId);
            }).length;

            setSuccessMessage(`${metinList.length} metin yüklendi. ${newItemsCount} yeni eşya markete eklendi.`);
            setTimeout(() => setSuccessMessage(""), 5000);
            setShowDataModal(false);

        } catch (error) {
            console.error('Import error:', error);
            alert('İçe aktarma sırasında hata oluştu: ' + error.message);
        }
    };

    // File input handler
    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) handleImport(file);
    };

    // Drag and drop handlers
    const handleDragOver = (e) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = () => {
        setIsDragging(false);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setIsDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file) handleImport(file);
    };

    return (
        <div className="space-y-6 h-full flex flex-col">
            {/* Success Message */}
            {successMessage && (
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="bg-green-600/90 backdrop-blur-sm text-white px-4 py-3 rounded-lg flex items-center gap-2 border border-green-500/30"
                >
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">{successMessage}</span>
                </motion.div>
            )}

            {/* Info Banner */}
            <div className="bg-white/10 backdrop-blur-xl p-4 rounded-xl border border-white/20">
                <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                        <div className="p-2 bg-purple-500/20 backdrop-blur-sm rounded-lg border border-purple-500/30">
                            <Settings className="w-5 h-5 text-purple-400" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-white mb-1">Metin Ayarları</h3>
                            <p className="text-sm text-white/70">
                                Her metinin HP değerini ve drop listesini düzenleyin.
                                Değişiklikler anlık olarak kaydedilir.
                            </p>
                        </div>
                    </div>
                    <button
                        onClick={() => setShowDataModal(true)}
                        className="p-2 bg-blue-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-blue-600 transition-colors border border-blue-500/30"
                        title="İçe/Dışa Aktar"
                    >
                        <Download className="w-5 h-5" />
                    </button>
                </div>
            </div>

            {/* Metins List */}
            <div className="flex-1 overflow-y-auto pr-2 space-y-3">
                {metins.map((metin) => (
                    <MetinAccordionItem
                        key={metin.id}
                        metin={metin}
                        isOpen={openMetinId === metin.id}
                        onToggle={() =>
                            setOpenMetinId(openMetinId === metin.id ? null : metin.id)
                        }
                        onUpdateHP={handleUpdateHP}
                        onAddDrop={handleAddDrop}
                        onRemoveDrop={handleRemoveDrop}
                        onUpdateDrop={handleUpdateDrop}
                    />
                ))}
            </div>

            {/* Import/Export Modal */}
            {showDataModal && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
                    {/* Backdrop */}
                    <div
                        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        onClick={() => setShowDataModal(false)}
                    />

                    {/* Modal */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="relative bg-black/40 backdrop-blur-xl border border-white/20 rounded-2xl p-6 max-w-md w-full shadow-2xl"
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-xl font-bold text-white">Metin Preset Yönetimi</h3>
                            <button
                                onClick={() => setShowDataModal(false)}
                                className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                            >
                                <X className="w-5 h-5 text-white/70" />
                            </button>
                        </div>

                        {/* Tabs */}
                        <div className="flex gap-2 mb-4">
                            <button
                                onClick={() => setDataModalTab("export")}
                                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-all ${dataModalTab === "export"
                                        ? "bg-purple-600 text-white"
                                        : "bg-white/10 text-white/70 hover:bg-white/20"
                                    }`}
                            >
                                <Download className="w-4 h-4 inline mr-2" />
                                Kaydet
                            </button>
                            <button
                                onClick={() => setDataModalTab("import")}
                                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-all ${dataModalTab === "import"
                                        ? "bg-purple-600 text-white"
                                        : "bg-white/10 text-white/70 hover:bg-white/20"
                                    }`}
                            >
                                <Upload className="w-4 h-4 inline mr-2" />
                                Yükle
                            </button>
                        </div>

                        {/* Export Tab */}
                        {dataModalTab === "export" && (
                            <div className="space-y-3">
                                <p className="text-sm text-white/70 mb-3">
                                    Metin ayarlarınızı Excel veya JSON formatında kaydedin.
                                </p>
                                <button
                                    onClick={() => handleExport("excel")}
                                    className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-green-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-green-600 transition-colors font-medium border border-green-500/30"
                                >
                                    <FileSpreadsheet className="w-5 h-5" />
                                    Excel (.xlsx) İndir
                                </button>
                                <button
                                    onClick={() => handleExport("json")}
                                    className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-purple-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-purple-600 transition-colors font-medium border border-purple-500/30"
                                >
                                    <FileJson className="w-5 h-5" />
                                    JSON İndir
                                </button>
                            </div>
                        )}

                        {/* Import Tab */}
                        {dataModalTab === "import" && (
                            <div className="space-y-3">
                                <p className="text-sm text-white/70 mb-3">
                                    Excel (.xlsx) veya JSON dosyası yükleyin. Yeni eşyalar otomatik olarak markete eklenecek.
                                </p>
                                <div
                                    onDragOver={handleDragOver}
                                    onDragLeave={handleDragLeave}
                                    onDrop={handleDrop}
                                    className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${isDragging
                                            ? "border-purple-500 bg-purple-500/10"
                                            : "border-white/20 bg-white/5 hover:bg-white/10"
                                        }`}
                                >
                                    <Upload className="w-12 h-12 text-white/50 mx-auto mb-3" />
                                    <p className="text-white/70 mb-2">Dosyayı buraya sürükleyin</p>
                                    <p className="text-white/50 text-sm mb-4">veya</p>
                                    <label className="inline-block px-4 py-2 bg-purple-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-purple-600 transition-colors cursor-pointer font-medium border border-purple-500/30">
                                        Dosya Seç
                                        <input
                                            type="file"
                                            accept=".xlsx,.xls,.json,.csv"
                                            onChange={handleFileChange}
                                            className="hidden"
                                        />
                                    </label>
                                    <p className="text-white/40 text-xs mt-3">
                                        Desteklenen formatlar: .xlsx, .xls, .json, .csv
                                    </p>
                                </div>
                            </div>
                        )}
                    </motion.div>
                </div>
            )}
        </div>
    );
}

// ============================================================================
// MAIN WIDGET
// ============================================================================
export default function MetinSettingsWidget({ id, data, isSelected, onClick, onHide }) {
    // Use widget data or initialize with default metins
    const metins = data?.metins?.length > 0 ? data.metins : initialMetinList;

    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group rounded-3xl shadow-2xl cursor-pointer overflow-hidden backdrop-blur-xl border border-white/10 ${isSelected
                    ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-6xl z-[100] bg-black/80"
                    : "relative h-64 hover:-translate-y-1 hover:border-purple-400/50 transition-all duration-300 bg-white/5 hover:bg-white/10"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {/* Hide Button */}
            <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => {
                    e.stopPropagation();
                    onHide && onHide();
                }}
                className="absolute top-4 right-4 z-20 p-2 bg-white/10 backdrop-blur-sm shadow-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-white/60 hover:text-purple-400 hover:bg-purple-500/20 border border-white/20"
            >
                <EyeOff className="w-4 h-4" />
            </motion.button>

            {/* Summary View */}
            {!isSelected && (
                <div className="w-full h-full p-6 relative">
                    <Settings className="absolute -bottom-4 -right-4 w-32 h-32 text-white/5 opacity-50 rotate-12 pointer-events-none" />
                    <MetinSettingsSummaryView metins={metins} />
                </div>
            )}

            {/* Detail View */}
            {isSelected && (
                <div className="flex flex-col h-full bg-black/20">
                    <div className="flex items-center justify-between p-8 border-b border-white/20 bg-white/5 backdrop-blur-xl">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                                <Settings className="w-8 h-8 text-purple-400" />
                            </div>
                            <div>
                                <motion.h2 layoutId={`title-${id}`} className="text-2xl font-bold text-white">
                                    Metin Ayarları
                                </motion.h2>
                                <p className="text-white/60">HP ve drop ayarlarını düzenleyin</p>
                            </div>
                        </div>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-white/10 rounded-full transition-colors backdrop-blur-sm border border-white/10 hover:border-white/20"
                        >
                            <X className="w-6 h-6 text-white/80" />
                        </button>
                    </div>
                    <div className="flex-1 p-8 overflow-y-auto">
                        <MetinSettingsDetailView widgetId={id} metins={metins} />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
