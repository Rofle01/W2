/**
 * Dragon Soul Alchemy Simulation Worker
 * 
 * Ejderha Taşı Simyası Monte Carlo Simülasyonu
 * 
 * Supports:
 * - Configurable elements (including optional Amethyst)
 * - Configurable Cor output level (Rough, Cut, Rare, etc.)
 * - Configurable upgrade requirements (2-5 stones per upgrade)
 * - Configurable success rates for class and clarity upgrades
 */

// ============================================================================
// CONSTANTS
// ============================================================================

const SAFETY_LIMIT = 100_000;

// Element definitions with display info
const ELEMENTS = {
    diamond: { name: 'Elmas', color: 'cyan' },
    ruby: { name: 'Yakut', color: 'rose' },
    jade: { name: 'Yeşim', color: 'emerald' },
    sapphire: { name: 'Safir', color: 'blue' },
    garnet: { name: 'Garnet', color: 'orange' },
    onyx: { name: 'Oniks', color: 'zinc' },
    amethyst: { name: 'Ametist', color: 'purple' }
};

// Stone class levels (ascending order)
const CLASS_LEVELS = ['rough', 'cut', 'rare', 'antique', 'legendary', 'mythic'];

// Stone clarity levels (ascending order)
const CLARITY_LEVELS = ['matte', 'clear', 'brilliant'];

// Default configuration
const DEFAULT_CONFIG = {
    activeElements: ['diamond', 'ruby', 'jade', 'sapphire', 'garnet', 'onyx'],
    corOutput: 'rough',
    requirements: {
        classUpgrade: 2,
        clarityUpgrade: 2
    },
    rates: {
        class: 50,
        clarity: 70
    }
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get random element from active elements
 */
function getRandomElement(activeElements) {
    const idx = Math.floor(Math.random() * activeElements.length);
    return activeElements[idx];
}

/**
 * Initialize empty inventory for all elements
 */
function createEmptyInventory(activeElements) {
    const inventory = {};
    activeElements.forEach(element => {
        inventory[element] = {};
        CLASS_LEVELS.forEach(classLevel => {
            inventory[element][classLevel] = {};
            CLARITY_LEVELS.forEach(clarity => {
                inventory[element][classLevel][clarity] = 0;
            });
        });
    });
    return inventory;
}

/**
 * Count total stones at a specific class level for an element
 */
function countAtClassLevel(elementInventory, classLevel) {
    let total = 0;
    CLARITY_LEVELS.forEach(clarity => {
        total += elementInventory[classLevel][clarity];
    });
    return total;
}

/**
 * Simulate opening Cor Draconis and getting stones
 */
function simulateCorOpening(corCount, config) {
    const inventory = createEmptyInventory(config.activeElements);
    const outputLevel = config.corOutput || 'rough';
    const startClarity = 'matte'; // Stones start at matte clarity

    for (let i = 0; i < corCount; i++) {
        const element = getRandomElement(config.activeElements);
        inventory[element][outputLevel][startClarity]++;
    }

    return inventory;
}

/**
 * Attempt to upgrade stones in inventory
 * Returns upgraded inventory
 */
function upgradeInventory(inventory, config) {
    const { classUpgrade, clarityUpgrade } = config.requirements;
    const { class: classRate, clarity: clarityRate } = config.rates;

    const classSuccessRate = classRate / 100;
    const claritySuccessRate = clarityRate / 100;

    // For each element, try to upgrade
    Object.keys(inventory).forEach(element => {
        // Class upgrades (Rough -> Cut -> Rare -> Antique -> Legendary -> Mythic)
        for (let i = 0; i < CLASS_LEVELS.length - 1; i++) {
            const currentClass = CLASS_LEVELS[i];
            const nextClass = CLASS_LEVELS[i + 1];

            // For each clarity level
            CLARITY_LEVELS.forEach(clarity => {
                const stoneCount = inventory[element][currentClass][clarity];
                const attempts = Math.floor(stoneCount / classUpgrade);

                if (attempts > 0) {
                    // Use stones for upgrade attempts
                    inventory[element][currentClass][clarity] -= attempts * classUpgrade;

                    // Calculate successes
                    let successes = 0;
                    for (let a = 0; a < attempts; a++) {
                        if (Math.random() < classSuccessRate) {
                            successes++;
                        }
                    }

                    // Add successful upgrades
                    inventory[element][nextClass][clarity] += successes;

                    // Failed attempts return 1 stone each (standard Metin2 behavior)
                    const failures = attempts - successes;
                    inventory[element][currentClass][clarity] += failures;
                }
            });
        }

        // Clarity upgrades (for all class levels)
        CLASS_LEVELS.forEach(classLevel => {
            for (let c = 0; c < CLARITY_LEVELS.length - 1; c++) {
                const currentClarity = CLARITY_LEVELS[c];
                const nextClarity = CLARITY_LEVELS[c + 1];

                const stoneCount = inventory[element][classLevel][currentClarity];
                const attempts = Math.floor(stoneCount / clarityUpgrade);

                if (attempts > 0) {
                    inventory[element][classLevel][currentClarity] -= attempts * clarityUpgrade;

                    let successes = 0;
                    for (let a = 0; a < attempts; a++) {
                        if (Math.random() < claritySuccessRate) {
                            successes++;
                        }
                    }

                    inventory[element][classLevel][nextClarity] += successes;

                    // Failed clarity upgrades return 1 stone
                    const failures = attempts - successes;
                    inventory[element][classLevel][currentClarity] += failures;
                }
            }
        });
    });

    return inventory;
}

/**
 * Sum two inventories
 */
function sumInventories(inv1, inv2, activeElements) {
    const result = createEmptyInventory(activeElements);

    activeElements.forEach(element => {
        CLASS_LEVELS.forEach(classLevel => {
            CLARITY_LEVELS.forEach(clarity => {
                result[element][classLevel][clarity] =
                    (inv1[element]?.[classLevel]?.[clarity] || 0) +
                    (inv2[element]?.[classLevel]?.[clarity] || 0);
            });
        });
    });

    return result;
}

/**
 * Divide inventory counts by a number (for averaging)
 */
function averageInventory(inventory, divisor, activeElements) {
    const result = createEmptyInventory(activeElements);

    activeElements.forEach(element => {
        CLASS_LEVELS.forEach(classLevel => {
            CLARITY_LEVELS.forEach(clarity => {
                result[element][classLevel][clarity] =
                    (inventory[element][classLevel][clarity] || 0) / divisor;
            });
        });
    });

    return result;
}

/**
 * Run Monte Carlo simulation
 */
function runSimulation(corCount, simCount, config) {
    const updateInterval = Math.max(1, Math.floor(simCount / 20));

    let totalInventory = createEmptyInventory(config.activeElements);

    for (let sim = 0; sim < simCount; sim++) {
        // Open Cor and get initial stones
        let inventory = simulateCorOpening(corCount, config);

        // Upgrade loop - keep upgrading until no more upgrades possible
        let upgradesMade = true;
        let safetyCounter = 0;

        while (upgradesMade && safetyCounter < SAFETY_LIMIT) {
            safetyCounter++;
            const beforeJSON = JSON.stringify(inventory);
            inventory = upgradeInventory(inventory, config);
            upgradesMade = JSON.stringify(inventory) !== beforeJSON;
        }

        // Accumulate results
        totalInventory = sumInventories(totalInventory, inventory, config.activeElements);

        // Progress update
        if ((sim + 1) % updateInterval === 0) {
            self.postMessage({
                type: 'progress',
                progress: Math.round(((sim + 1) / simCount) * 100)
            });
        }
    }

    // Calculate averages
    const averageResults = averageInventory(totalInventory, simCount, config.activeElements);

    return {
        averageInventory: averageResults,
        corCount,
        simCount,
        config: {
            activeElements: config.activeElements,
            corOutput: config.corOutput,
            requirements: config.requirements,
            rates: config.rates
        }
    };
}

// ============================================================================
// MESSAGE HANDLER
// ============================================================================

self.onmessage = (e) => {
    const { action, corCount, simCount, config } = e.data;

    if (action === 'run_simulation') {
        try {
            // Merge with defaults
            const actualConfig = {
                ...DEFAULT_CONFIG,
                ...config,
                requirements: { ...DEFAULT_CONFIG.requirements, ...config?.requirements },
                rates: { ...DEFAULT_CONFIG.rates, ...config?.rates }
            };

            console.log('[Alchemy Worker] Starting simulation:', {
                corCount,
                simCount,
                config: actualConfig
            });

            const startTime = performance.now();
            const result = runSimulation(
                corCount || 100,
                simCount || 100,
                actualConfig
            );
            const endTime = performance.now();

            self.postMessage({
                type: 'complete',
                ...result,
                duration: (endTime - startTime).toFixed(2)
            });
        } catch (error) {
            self.postMessage({
                type: 'error',
                message: error.message || 'Simulation failed'
            });
        }
    }
};
