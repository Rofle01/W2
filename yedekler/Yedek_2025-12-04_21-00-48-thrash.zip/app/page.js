"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutTemplate, Filter } from "lucide-react";
import FinancialWidget from "./components/FinancialWidget";
import MarketWidget from "./components/widgets/MarketWidget";
import CharacterWidget from "./components/widgets/CharacterWidget";
import AnalysisWidget from "./components/widgets/AnalysisWidget";
import MetinSettingsWidget from "./components/widgets/MetinSettingsWidget";
import DamageProgressionWidget from "./components/widgets/DamageProgressionWidget";
import MarketSupplyWidget from "./components/widgets/MarketSupplyWidget";
import CraftingWidget from "./components/widgets/CraftingWidget";
import WorkspaceDock from "./components/WorkspaceDock";
import useWidgetStore from "./store/useWidgetStore";
import { WIDGET_TYPES } from "./store/constants";
import { FilterProvider } from "@/src/experiments/RoadmapFilter/FilterContext";
import { FilterSidebar } from "@/src/experiments/RoadmapFilter/FilterSidebar";

// Widget component mapping
const WIDGET_COMPONENTS = {
  [WIDGET_TYPES.MARKET]: MarketWidget,
  [WIDGET_TYPES.CHARACTER]: CharacterWidget,
  [WIDGET_TYPES.ANALYSIS]: AnalysisWidget,
  [WIDGET_TYPES.METIN_SETTINGS]: MetinSettingsWidget,
  [WIDGET_TYPES.DAMAGE_PROGRESSION]: DamageProgressionWidget,
  [WIDGET_TYPES.MARKET_SUPPLY]: MarketSupplyWidget,
  [WIDGET_TYPES.CRAFTING]: CraftingWidget,
  // All other widgets use FinancialWidget
};

export default function Home() {
  const [selectedId, setSelectedId] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Store'dan workspace verilerini çek
  const activeWorkspaceId = useWidgetStore((state) => state.activeWorkspaceId);
  const workspaces = useWidgetStore((state) => state.workspaces);
  const toggleWidgetVisibility = useWidgetStore((state) => state.toggleWidgetVisibility);

  // Aktif workspace'i bul
  const activeWorkspace = workspaces.find((w) => w.id === activeWorkspaceId);

  // Görünür widget'ları filtrele (optional chaining ile güvenli erişim)
  const visibleWidgets = activeWorkspace?.widgets?.filter((w) => w.isVisible) || [];

  // FIX: Workspace değiştiğinde açık olan widget'ı kapat (Blur sorununu çözer)
  useEffect(() => {
    setSelectedId(null);
  }, [activeWorkspaceId]);

  // Get the appropriate widget component
  const getWidgetComponent = (type) => {
    return WIDGET_COMPONENTS[type] || FinancialWidget;
  };

  return (
    <FilterProvider>
      <div className="flex h-screen overflow-hidden bg-black">
        {/* LEFT SIDEBAR */}
        <AnimatePresence mode="wait">
          {isSidebarOpen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="h-full border-r border-white/10 bg-zinc-950 relative z-20"
            >
              <div className="h-full overflow-y-auto p-4 custom-scrollbar">
                <FilterSidebar />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* RIGHT MAIN CONTENT */}
        <main className="flex-1 relative overflow-y-auto bg-gradient-to-br from-zinc-900 to-black">
          {/* Sidebar Toggle Button */}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="absolute top-6 left-6 z-30 p-2 bg-white/10 hover:bg-white/20 text-white rounded-lg backdrop-blur-sm border border-white/10 transition-all"
            title="Toggle Filter Panel"
          >
            <Filter className={`w-5 h-5 transition-transform ${isSidebarOpen ? 'rotate-180' : ''}`} />
          </button>

          <div className="min-h-full p-6 md:p-8 lg:p-12 pt-20">
            <div className="max-w-7xl mx-auto">
              <header className="mb-8 pl-12">
                <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
                  W2 - Metin2 Ekonomi Yönetimi
                </h1>
                <p className="text-white/80">
                  Gelişmiş analiz araçları ile oyun içi ekonominizi optimize edin
                </p>
                {activeWorkspace && (
                  <p className="text-sm text-white/60 mt-2">
                    Aktif Çalışma Alanı: <span className="font-semibold text-white">{activeWorkspace.name}</span>
                  </p>
                )}
              </header>

              {visibleWidgets.length === 0 ? (
                /* Empty State */
                <div className="flex flex-col items-center justify-center h-[50vh] text-white/40 border-2 border-dashed border-white/20 rounded-3xl bg-white/5 backdrop-blur-sm">
                  <div className="p-4 bg-white/10 rounded-full mb-4">
                    <LayoutTemplate className="w-8 h-8 text-white/60" />
                  </div>
                  <h3 className="text-lg font-semibold text-white/80 mb-1">Bu Çalışma Alanı Boş</h3>
                  <p className="text-sm text-white/50">
                    Widget eklemek için aşağıdaki menüden Grid ikonuna tıklayın.
                  </p>
                </div>
              ) : (
                /* Widget Grid */
                <div key={activeWorkspaceId} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-32">
                  <AnimatePresence mode="popLayout">
                    {visibleWidgets.map((widget) => {
                      const WidgetComponent = getWidgetComponent(widget.type);
                      return (
                        <WidgetComponent
                          key={widget.id}
                          id={widget.id}
                          type={widget.type}
                          data={widget.data}
                          isSelected={selectedId === widget.id}
                          onClick={() => setSelectedId(selectedId === widget.id ? null : widget.id)}
                          onHide={() => toggleWidgetVisibility(widget.id)}
                        />
                      );
                    })}
                  </AnimatePresence>
                </div>
              )}

              {/* Backdrop Overlay for Expanded Widget */}
              <AnimatePresence>
                {selectedId && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setSelectedId(null)}
                    className="fixed inset-0 bg-black/60 backdrop-blur-md z-[90]"
                    transition={{ duration: 0.2 }}
                  />
                )}
              </AnimatePresence>

              {/* Workspace Dock - Unified workspace and widget management */}
              <WorkspaceDock />
            </div>
          </div>
        </main>
      </div>
    </FilterProvider>
  );
}
