/**
 * Sash (Kuşak) Monte Carlo Simulation Worker
 * 
 * Bu worker, kuşak birleştirme maliyetini simüle eder.
 * 
 * Logic:
 * - 1 → 5 (%90 başarı)
 * - 5 → 10 (%80 başarı)
 * - 10 → Hakim (%70 başarı)
 * - Hakim (Acced): 10+10 birleşince 11-20 arası emiş atar
 *   - Weighted Random: 11-15 yüksek, 16-18 orta, 19-20 düşük ihtimal
 * - Upgrade: Hedef emişe ulaşana kadar iki hakimi birleştir
 *   - %50 başarı, artış +1 ile +5 arası
 */

// ============================================================================
// CONSTANTS
// ============================================================================

const COMBINE_RATES = {
    "1_to_5": 0.90,    // %90
    "5_to_10": 0.80,   // %80
    "10_to_hakim": 0.70 // %70
};

const UPGRADE_SUCCESS_RATE = 0.50; // %50
const UPGRADE_MIN_INCREASE = 1;
const UPGRADE_MAX_INCREASE = 5;

// Hakim emiş ağırlıkları (11-20 arası)
// 11-15: yüksek ihtimal, 16-18: orta, 19-20: çok düşük
const HAKIM_WEIGHTS = {
    11: 25,
    12: 22,
    13: 18,
    14: 14,
    15: 10,
    16: 5,
    17: 3,
    18: 2,
    19: 0.7,
    20: 0.3
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Weighted random seçim
 * @param {Object} weights - { value: weight } formatında ağırlıklar
 * @returns {number} Seçilen değer
 */
function weightedRandom(weights) {
    const entries = Object.entries(weights);
    const totalWeight = entries.reduce((sum, [, w]) => sum + w, 0);
    let random = Math.random() * totalWeight;

    for (const [value, weight] of entries) {
        random -= weight;
        if (random <= 0) {
            return parseInt(value, 10);
        }
    }

    // Fallback (olmamalı ama güvenlik için)
    return 11;
}

/**
 * Random int between min and max (inclusive)
 */
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Bir adet Lv1 kuşağı Lv5'e yükseltme maliyeti
 * @param {number} clothPrice - Kumaş fiyatı
 * @returns {{ cost: number, clothUsed: number, success: boolean }}
 */
function combineTo5(clothPrice) {
    // Her deneme 2 kumaş kullanır (2 adet Lv1 kuşak)
    let totalCost = 0;
    let clothUsed = 0;

    while (true) {
        // 2 adet Lv1 kuşak = 2 kumaş
        totalCost += clothPrice * 2;
        clothUsed += 2;

        if (Math.random() < COMBINE_RATES["1_to_5"]) {
            return { cost: totalCost, clothUsed, success: true };
        }
    }
}

/**
 * İki adet Lv5 kuşağı Lv10'a yükseltme maliyeti
 * @param {number} clothPrice - Kumaş fiyatı
 * @returns {{ cost: number, clothUsed: number, success: boolean }}
 */
function combineTo10(clothPrice) {
    let totalCost = 0;
    let clothUsed = 0;

    while (true) {
        // 2 adet Lv5 kuşak gerekli - her birinin maliyetini hesapla
        const lv5_1 = combineTo5(clothPrice);
        const lv5_2 = combineTo5(clothPrice);

        totalCost += lv5_1.cost + lv5_2.cost;
        clothUsed += lv5_1.clothUsed + lv5_2.clothUsed;

        if (Math.random() < COMBINE_RATES["5_to_10"]) {
            return { cost: totalCost, clothUsed, success: true };
        }
    }
}

/**
 * İki adet Lv10 kuşağı Hakim'e yükseltme (11-20 arası emiş atar)
 * @param {number} clothPrice - Kumaş fiyatı
 * @returns {{ cost: number, clothUsed: number, grade: number }}
 */
function combineToHakim(clothPrice) {
    let totalCost = 0;
    let clothUsed = 0;

    while (true) {
        // 2 adet Lv10 kuşak gerekli
        const lv10_1 = combineTo10(clothPrice);
        const lv10_2 = combineTo10(clothPrice);

        totalCost += lv10_1.cost + lv10_2.cost;
        clothUsed += lv10_1.clothUsed + lv10_2.clothUsed;

        if (Math.random() < COMBINE_RATES["10_to_hakim"]) {
            const grade = weightedRandom(HAKIM_WEIGHTS);
            return { cost: totalCost, clothUsed, grade };
        }
    }
}

/**
 * Hakim kuşağı hedef emişe yükseltme
 * @param {number} clothPrice - Kumaş fiyatı
 * @param {number} targetGrade - Hedef emiş (örn: 25)
 * @returns {{ cost: number, clothUsed: number, finalGrade: number }}
 */
function upgradeToTarget(clothPrice, targetGrade) {
    // İlk hakim kuşağını al
    let current = combineToHakim(clothPrice);
    let totalCost = current.cost;
    let clothUsed = current.clothUsed;
    let currentGrade = current.grade;

    // Hedef emişe ulaşana kadar upgrade
    while (currentGrade < targetGrade) {
        // İkinci bir hakim kuşak gerekli
        const second = combineToHakim(clothPrice);
        totalCost += second.cost;
        clothUsed += second.clothUsed;

        // %50 başarı şansı
        if (Math.random() < UPGRADE_SUCCESS_RATE) {
            // Başarılı - +1 ile +5 arası artış
            const increase = randomInt(UPGRADE_MIN_INCREASE, UPGRADE_MAX_INCREASE);
            currentGrade = Math.min(currentGrade + increase, 100); // Max %100
        }
        // Başarısız - ikinci hakim kaybedilir, mevcut kuşak kalır
    }

    return { cost: totalCost, clothUsed, finalGrade: currentGrade };
}

/**
 * Monte Carlo simülasyonu çalıştır
 * @param {number} clothPrice - Kumaş fiyatı
 * @param {number} targetGrade - Hedef emiş oranı
 * @param {number} simCount - Simülasyon sayısı
 */
function runSimulation(clothPrice, targetGrade, simCount) {
    const results = [];
    const updateInterval = Math.max(1, Math.floor(simCount / 20)); // Her %5'te güncelle

    let totalCost = 0;
    let totalCloth = 0;
    let minCost = Infinity;
    let maxCost = 0;

    for (let i = 0; i < simCount; i++) {
        const result = upgradeToTarget(clothPrice, targetGrade);

        results.push(result.cost);
        totalCost += result.cost;
        totalCloth += result.clothUsed;

        if (result.cost < minCost) minCost = result.cost;
        if (result.cost > maxCost) maxCost = result.cost;

        // Progress update
        if ((i + 1) % updateInterval === 0 || i === simCount - 1) {
            self.postMessage({
                type: "progress",
                progress: Math.round(((i + 1) / simCount) * 100),
                currentStep: i + 1,
                totalSteps: simCount
            });
        }
    }

    const avgCost = totalCost / simCount;
    const avgCloth = totalCloth / simCount;

    // Maliyet dağılımı için histogram (10 bucket)
    const distribution = calculateDistribution(results, 10);

    return {
        avgCost: Math.round(avgCost),
        minCost: Math.round(minCost),
        maxCost: Math.round(maxCost),
        totalClothUsed: Math.round(avgCloth),
        simCount,
        targetGrade,
        distribution
    };
}

/**
 * Sonuç dağılımını hesapla (histogram için)
 * @param {number[]} results - Maliyet listesi
 * @param {number} bucketCount - Bucket sayısı
 */
function calculateDistribution(results, bucketCount) {
    if (results.length === 0) return [];

    const min = Math.min(...results);
    const max = Math.max(...results);
    const range = max - min || 1;
    const bucketSize = range / bucketCount;

    const buckets = Array(bucketCount).fill(0);

    for (const value of results) {
        const bucketIndex = Math.min(
            Math.floor((value - min) / bucketSize),
            bucketCount - 1
        );
        buckets[bucketIndex]++;
    }

    return buckets.map((count, i) => ({
        range: `${formatCurrency(min + i * bucketSize)} - ${formatCurrency(min + (i + 1) * bucketSize)}`,
        count,
        percentage: ((count / results.length) * 100).toFixed(1)
    }));
}

/**
 * Para formatla
 */
function formatCurrency(value) {
    if (value >= 1000000000) {
        return `${(value / 1000000000).toFixed(1)}B`;
    }
    if (value >= 1000000) {
        return `${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
        return `${(value / 1000).toFixed(1)}K`;
    }
    return Math.round(value).toString();
}

// ============================================================================
// MESSAGE HANDLER
// ============================================================================

self.onmessage = (e) => {
    const { action, clothPrice, targetGrade, simCount } = e.data;

    if (action === "run_simulation") {
        try {
            console.log("[Sash Worker] Starting simulation:", {
                clothPrice,
                targetGrade,
                simCount
            });

            const startTime = performance.now();
            const result = runSimulation(
                clothPrice || 1000000,
                targetGrade || 25,
                simCount || 1000
            );
            const endTime = performance.now();

            self.postMessage({
                type: "complete",
                ...result,
                duration: (endTime - startTime).toFixed(2)
            });
        } catch (error) {
            self.postMessage({
                type: "error",
                message: error.message || "Simulation failed"
            });
        }
    }
};
