"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, EyeOff, Settings, ChevronDown, Plus, Trash2 } from "lucide-react";
import * as LucideIcons from "lucide-react";
import useWidgetStore from "../../store/useWidgetStore";

const formatNumber = (num) => {
    return new Intl.NumberFormat('tr-TR').format(num);
};

// ============================================================================
// SUMMARY VIEW
// ============================================================================
function MetinSettingsSummaryView() {
    const metinList = useWidgetStore((state) => state.metinList);

    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden px-4">
            <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-purple-50 rounded-lg">
                    <Settings className="w-8 h-8 text-purple-600" />
                </div>
            </div>
            <span className="text-3xl font-bold text-zinc-800 whitespace-nowrap">
                Metin Ayarları
            </span>
            <span className="text-sm text-zinc-500 mt-2">
                {metinList.length} Metin Tanımlı
            </span>
        </div>
    );
}

// ============================================================================
// ACCORDION ITEM
// ============================================================================
function MetinAccordionItem({ metin, isOpen, onToggle }) {
    const marketItems = useWidgetStore((state) => state.marketItems);
    const updateMetinHp = useWidgetStore((state) => state.updateMetinHp);
    const addMetinDrop = useWidgetStore((state) => state.addMetinDrop);
    const removeMetinDrop = useWidgetStore((state) => state.removeMetinDrop);
    const updateMetinDrop = useWidgetStore((state) => state.updateMetinDrop);

    const [selectedItemId, setSelectedItemId] = useState(
        marketItems[0]?.originalId || ""
    );

    const getItemByOriginalId = (originalId) => {
        return marketItems.find((item) => item.originalId === originalId);
    };

    const handleHpChange = (newHp) => {
        const hp = parseFloat(newHp);
        if (!isNaN(hp) && hp > 0) {
            updateMetinHp(metin.id, hp);
        }
    };

    const handleDropChange = (dropId, field, value) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue) && numValue >= 0) {
            updateMetinDrop(metin.id, dropId, { [field]: numValue });
        }
    };

    const handleAddDrop = () => {
        if (selectedItemId) {
            const exists = metin.drops.some((d) => d.itemId === selectedItemId);
            if (exists) {
                alert("Bu eşya zaten bu metinde ekli!");
                return;
            }
            addMetinDrop(metin.id, {
                itemId: selectedItemId,
                count: 1,
                chance: 10,
            });
        }
    };

    const handleRemoveDrop = (dropId) => {
        if (confirm("Bu drop'u silmek istediğinizden emin misiniz?")) {
            removeMetinDrop(metin.id, dropId);
        }
    };

    return (
        <div className="bg-white rounded-xl border border-zinc-200 overflow-hidden">
            <button
                onClick={onToggle}
                className="w-full flex items-center justify-between p-4 hover:bg-zinc-50 transition-colors"
            >
                <div className="flex items-center gap-3">
                    <motion.div
                        animate={{ rotate: isOpen ? 180 : 0 }}
                        transition={{ duration: 0.2 }}
                    >
                        <ChevronDown className="w-5 h-5 text-zinc-500" />
                    </motion.div>
                    <div className="text-left">
                        <h4 className="font-semibold text-zinc-800">{metin.name}</h4>
                        <p className="text-sm text-zinc-500">
                            HP: {formatNumber(metin.hp)} | {metin.drops.length} Drop
                        </p>
                    </div>
                </div>
                <div className="px-3 py-1 bg-purple-100 rounded-full text-xs font-medium text-purple-700">
                    {isOpen ? "Düzenle" : "Aç"}
                </div>
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                    >
                        <div className="p-4 border-t border-zinc-200 space-y-4 bg-zinc-50">
                            {/* HP Input */}
                            <div className="bg-white p-4 rounded-lg border border-zinc-200">
                                <label className="block text-sm font-medium text-zinc-700 mb-2">
                                    Metin Canı (HP)
                                </label>
                                <input
                                    type="number"
                                    value={metin.hp}
                                    onChange={(e) => handleHpChange(e.target.value)}
                                    className="w-full px-3 py-2 font-semibold text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder:text-zinc-400"
                                    min="1"
                                    step="100"
                                />
                            </div>

                            {/* Drops List */}
                            <div className="bg-white p-4 rounded-lg border border-zinc-200">
                                <h5 className="text-sm font-semibold text-zinc-700 mb-3">
                                    Düşen Eşyalar
                                </h5>

                                <div className="space-y-2">
                                    {metin.drops.map((drop) => {
                                        const item = getItemByOriginalId(drop.itemId);
                                        const ItemIcon = item
                                            ? LucideIcons[item.icon] || LucideIcons.Circle
                                            : LucideIcons.Circle;

                                        return (
                                            <div
                                                key={drop.id}
                                                className="flex items-center gap-3 p-3 bg-zinc-50 rounded-lg hover:bg-zinc-100 transition-colors"
                                            >
                                                <div className="p-2 bg-white rounded-lg border border-zinc-200">
                                                    <ItemIcon className="w-4 h-4 text-purple-600" />
                                                </div>

                                                <div className="flex-1 min-w-0">
                                                    <p className="text-sm font-medium text-zinc-800 truncate">
                                                        {item?.name || drop.itemId}
                                                    </p>
                                                </div>

                                                <div className="w-20">
                                                    <input
                                                        type="number"
                                                        value={drop.count}
                                                        onChange={(e) =>
                                                            handleDropChange(drop.id, "count", e.target.value)
                                                        }
                                                        className="w-full px-2 py-1 text-sm font-semibold text-zinc-900 bg-white border border-zinc-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder:text-zinc-400"
                                                        min="1"
                                                        placeholder="Adet"
                                                    />
                                                </div>

                                                <div className="w-20">
                                                    <input
                                                        type="number"
                                                        value={drop.chance}
                                                        onChange={(e) =>
                                                            handleDropChange(drop.id, "chance", e.target.value)
                                                        }
                                                        className="w-full px-2 py-1 text-sm font-semibold text-zinc-900 bg-white border border-zinc-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder:text-zinc-400"
                                                        min="0"
                                                        max="100"
                                                        placeholder="%"
                                                    />
                                                </div>

                                                <button
                                                    onClick={() => handleRemoveDrop(drop.id)}
                                                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                                    title="Sil"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            </div>
                                        );
                                    })}
                                </div>

                                {/* Add New Drop */}
                                <div className="mt-4 pt-4 border-t border-zinc-200">
                                    <p className="text-xs font-medium text-zinc-600 mb-2">
                                        Yeni Eşya Ekle
                                    </p>
                                    <div className="flex gap-2">
                                        <select
                                            value={selectedItemId}
                                            onChange={(e) => setSelectedItemId(e.target.value)}
                                            className="flex-1 px-3 py-2 text-sm font-medium text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                                        >
                                            {marketItems
                                                .filter((item) => item.originalId)
                                                .map((item) => (
                                                    <option key={item.id} value={item.originalId}>
                                                        {item.name}
                                                    </option>
                                                ))}
                                        </select>
                                        <button
                                            onClick={handleAddDrop}
                                            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2 text-sm font-medium"
                                        >
                                            <Plus className="w-4 h-4" />
                                            Ekle
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW
// ============================================================================
function MetinSettingsDetailView() {
    const metinList = useWidgetStore((state) => state.metinList);
    const [openMetinId, setOpenMetinId] = useState(null);

    const handleToggle = (metinId) => {
        setOpenMetinId(openMetinId === metinId ? null : metinId);
    };

    return (
        <div className="space-y-6 h-full flex flex-col">
            <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-xl border border-purple-200">
                <div className="flex items-start gap-3">
                    <div className="p-2 bg-purple-100 rounded-lg">
                        <Settings className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-purple-800 mb-1">
                            Metin Simülasyon Ayarları
                        </h3>
                        <p className="text-sm text-purple-700">
                            Her metinin HP'sini ve drop listesini düzenleyebilirsiniz.
                            Değişiklikler analiz sonuçlarını otomatik günceller.
                        </p>
                    </div>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3">
                {metinList.map((metin) => (
                    <MetinAccordionItem
                        key={metin.id}
                        metin={metin}
                        isOpen={openMetinId === metin.id}
                        onToggle={() => handleToggle(metin.id)}
                    />
                ))}
            </div>

            <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 text-sm text-zinc-600">
                💡 <strong>İpucu:</strong> Drop ekleme/çıkarma ve değer değişiklikleri,
                "Analiz & Simülasyon" widget'ındaki karlılık hesaplamalarını anında günceller.
            </div>
        </div>
    );
}

// ============================================================================
// MAIN WIDGET
// ============================================================================
export default function MetinSettingsWidget({ id, isSelected, onClick, onHide }) {
    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group bg-white rounded-3xl shadow-sm border border-zinc-200 cursor-pointer overflow-hidden ${isSelected
                    ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-5xl z-50 shadow-2xl"
                    : "relative h-64 hover:-translate-y-1 hover:shadow-lg hover:border-purple-200 transition-all duration-300"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {!isSelected && (
                <>
                    <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => {
                            e.stopPropagation();
                            onHide && onHide();
                        }}
                        className="absolute top-4 right-4 z-20 p-2 bg-white/80 backdrop-blur-sm shadow-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-zinc-400 hover:text-red-500 hover:bg-red-50"
                    >
                        <EyeOff className="w-4 h-4" />
                    </motion.button>

                    <div className="w-full h-full p-6 relative">
                        <Settings className="absolute -bottom-4 -right-4 w-32 h-32 text-purple-50 opacity-50 rotate-12 pointer-events-none" />
                        <MetinSettingsSummaryView />
                    </div>
                </>
            )}

            {isSelected && (
                <div className="flex flex-col h-full bg-zinc-50/50">
                    <div className="flex items-center justify-between p-8 border-b border-zinc-200 bg-white">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-purple-50 rounded-2xl">
                                <Settings className="w-8 h-8 text-purple-600" />
                            </div>
                            <div>
                                <motion.h2
                                    layoutId={`title-${id}`}
                                    className="text-2xl font-bold text-zinc-800"
                                >
                                    Metin Ayarları
                                </motion.h2>
                                <p className="text-zinc-500">Simülasyon parametrelerini düzenle</p>
                            </div>
                        </div>

                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                        >
                            <X className="w-6 h-6 text-zinc-500" />
                        </button>
                    </div>

                    <div className="flex-1 p-8 overflow-hidden">
                        <MetinSettingsDetailView />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
