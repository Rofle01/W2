"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { X, EyeOff, Sword, Zap, Clock } from "lucide-react";
import useWidgetStore from "../../store/useWidgetStore";

// Helper: Format compact
const formatCompact = (number) => {
    if (number >= 1000000) {
        return `${(number / 1000000).toFixed(1)}M`;
    } else if (number >= 1000) {
        return `${(number / 1000).toFixed(1)}k`;
    }
    return number.toString();
};

// ============================================================================
// SUMMARY VIEW
// ============================================================================
function CharacterSummaryView() {
    const userStats = useWidgetStore((state) => state.userStats);

    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden px-4">
            <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-red-50 rounded-lg">
                    <Sword className="w-8 h-8 text-red-600" />
                </div>
            </div>
            <span className="text-3xl font-bold text-zinc-800 whitespace-nowrap">
                {formatCompact(userStats.damage)} Hasar
            </span>
            <div className="flex items-center gap-4 mt-2 text-sm text-zinc-500">
                <span className="flex items-center gap-1">
                    <Zap className="w-4 h-4" />
                    {userStats.hitsPerSecond} v/sn
                </span>
                <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {userStats.findTime}s
                </span>
            </div>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW
// ============================================================================
function CharacterDetailView() {
    const userStats = useWidgetStore((state) => state.userStats);
    const updateUserStats = useWidgetStore((state) => state.updateUserStats);

    const [localStats, setLocalStats] = useState(userStats);

    const handleChange = (field, value) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue) && numValue >= 0) {
            const newStats = { ...localStats, [field]: numValue };
            setLocalStats(newStats);
            updateUserStats({ [field]: numValue });
        }
    };

    return (
        <div className="space-y-6 h-full flex flex-col">
            {/* Info Banner */}
            <div className="bg-gradient-to-r from-red-50 to-orange-50 p-4 rounded-xl border border-red-200">
                <div className="flex items-start gap-3">
                    <div className="p-2 bg-red-100 rounded-lg">
                        <Sword className="w-5 h-5 text-red-600" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-red-800 mb-1">Karakter İstatistikleri</h3>
                        <p className="text-sm text-red-700">
                            Metin kesme hızınızı ve karlılığınızı hesaplamak için gerekli bilgiler.
                            Değerler anlık olarak kaydedilir.
                        </p>
                    </div>
                </div>
            </div>

            {/* Stats Inputs */}
            <div className="flex-1 space-y-4">
                {/* Damage */}
                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-3 mb-3">
                        <div className="p-2 bg-red-100 rounded-lg">
                            <Sword className="w-5 h-5 text-red-600" />
                        </div>
                        <div className="flex-1">
                            <label className="block text-sm font-semibold text-zinc-800">
                                Ortalama Hasar (Vuruş Başına)
                            </label>
                            <p className="text-xs text-zinc-500 mt-0.5">
                                Bir vuruşta verdiğiniz ortalama hasarı girin
                            </p>
                        </div>
                    </div>
                    <input
                        type="number"
                        value={localStats.damage}
                        onChange={(e) => handleChange('damage', e.target.value)}
                        className="w-full px-4 py-3 text-lg font-semibold text-zinc-900 bg-white border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all placeholder:text-zinc-400"
                        placeholder="3000"
                        min="0"
                        step="100"
                    />
                </div>

                {/* Hits Per Second */}
                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-3 mb-3">
                        <div className="p-2 bg-orange-100 rounded-lg">
                            <Zap className="w-5 h-5 text-orange-600" />
                        </div>
                        <div className="flex-1">
                            <label className="block text-sm font-semibold text-zinc-800">
                                Saniye Başına Vuruş (Saldırı Hızı)
                            </label>
                            <p className="text-xs text-zinc-500 mt-0.5">
                                Bir saniyede kaç kez vurduğunuzu girin
                            </p>
                        </div>
                    </div>
                    <input
                        type="number"
                        value={localStats.hitsPerSecond}
                        onChange={(e) => handleChange('hitsPerSecond', e.target.value)}
                        className="w-full px-4 py-3 text-lg font-semibold text-zinc-900 bg-white border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all placeholder:text-zinc-400"
                        placeholder="2.5"
                        min="0"
                        step="0.1"
                    />
                </div>

                {/* Find Time */}
                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-3 mb-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                            <Clock className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                            <label className="block text-sm font-semibold text-zinc-800">
                                Metin Bulma Süresi (Saniye)
                            </label>
                            <p className="text-xs text-zinc-500 mt-0.5">
                                Bir metinden diğerine geçiş süresi
                            </p>
                        </div>
                    </div>
                    <input
                        type="number"
                        value={localStats.findTime}
                        onChange={(e) => handleChange('findTime', e.target.value)}
                        className="w-full px-4 py-3 text-lg font-semibold text-zinc-900 bg-white border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all placeholder:text-zinc-400"
                        placeholder="10"
                        min="0"
                        step="1"
                    />
                </div>
            </div>

            {/* Stats Summary */}
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
                <h4 className="text-sm font-semibold text-zinc-700 mb-2">Hesaplanan Değerler</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="bg-white p-3 rounded-lg">
                        <p className="text-zinc-500 text-xs">DPS (Saniye Başına)</p>
                        <p className="text-lg font-bold text-red-600">
                            {formatCompact(localStats.damage * localStats.hitsPerSecond)}
                        </p>
                    </div>
                    <div className="bg-white p-3 rounded-lg">
                        <p className="text-zinc-500 text-xs">Toplam Döngü Süresi</p>
                        <p className="text-lg font-bold text-blue-600">
                            ~{localStats.findTime}+ sn
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN WIDGET
// ============================================================================
export default function CharacterWidget({ id, isSelected, onClick, onHide }) {
    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group bg-white rounded-3xl shadow-sm border border-zinc-200 cursor-pointer overflow-hidden ${isSelected
                    ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-4xl z-50 shadow-2xl"
                    : "relative h-64 hover:-translate-y-1 hover:shadow-lg hover:border-red-200 transition-all duration-300"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {!isSelected && (
                <>
                    <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => {
                            e.stopPropagation();
                            onHide && onHide();
                        }}
                        className="absolute top-4 right-4 z-20 p-2 bg-white/80 backdrop-blur-sm shadow-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-zinc-400 hover:text-red-500 hover:bg-red-50"
                    >
                        <EyeOff className="w-4 h-4" />
                    </motion.button>
                    <div className="w-full h-full p-6 relative">
                        <Sword className="absolute -bottom-4 -right-4 w-32 h-32 text-red-50 opacity-50 rotate-12 pointer-events-none" />
                        <CharacterSummaryView />
                    </div>
                </>
            )}

            {isSelected && (
                <div className="flex flex-col h-full bg-zinc-50/50">
                    <div className="flex items-center justify-between p-8 border-b border-zinc-200 bg-white">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-red-50 rounded-2xl">
                                <Sword className="w-8 h-8 text-red-600" />
                            </div>
                            <div>
                                <motion.h2 layoutId={`title-${id}`} className="text-2xl font-bold text-zinc-800">
                                    Karakterim
                                </motion.h2>
                                <p className="text-zinc-500">Savaş istatistiklerinizi yönetin</p>
                            </div>
                        </div>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                        >
                            <X className="w-6 h-6 text-zinc-500" />
                        </button>
                    </div>
                    <div className="flex-1 p-8 overflow-y-auto">
                        <CharacterDetailView />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
