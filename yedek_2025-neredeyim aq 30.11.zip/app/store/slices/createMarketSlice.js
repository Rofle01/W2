import { initialMarketItems } from "../../data/initialData";

export const createMarketSlice = (set, get) => ({
    marketItems: initialMarketItems,

    addMarketItem: (item) =>
        set((state) => {
            state.marketItems.push({
                id: crypto.randomUUID(),
                originalId: null,
                name: item.name,
                price: item.price,
                category: item.category || "genel",
                isSystemItem: false,
                icon: item.icon || "Circle",
            });
        }),

    registerItems: (newItems) =>
        set((state) => {
            if (!Array.isArray(newItems) || newItems.length === 0) return;

            newItems.forEach(newItem => {
                // Prevent duplicates
                const exists = state.marketItems.some(i => i.id === newItem.id);
                if (!exists) {
                    state.marketItems.push(newItem);
                }
            });
        }),

    updateItemPrice: (id, newPrice) =>
        set((state) => {
            const item = state.marketItems.find((i) => i.id === id);
            if (item) {
                item.price = parseFloat(newPrice) || 0;
            }
        }),

    removeMarketItem: (id) =>
        set((state) => {
            const index = state.marketItems.findIndex((i) => i.id === id);
            if (index !== -1) {
                const item = state.marketItems[index];
                if (item.isSystemItem) {
                    console.warn("Sistem eşyaları silinemez!");
                    return;
                }
                state.marketItems.splice(index, 1);
            }
        }),

    importMarketData: (data) =>
        set((state) => {
            // Validation
            if (!Array.isArray(data)) {
                console.error("İçe aktarılan veri bir dizi olmalıdır.");
                return;
            }

            if (data.length === 0) {
                console.warn("İçe aktarılan veri boş.");
                return;
            }

            // Replace market items with imported data
            state.marketItems = data.map((item) => ({
                id: item.id || crypto.randomUUID(),
                originalId: item.originalId || null,
                name: item.name || "İsimsiz Eşya",
                price: parseFloat(item.price) || 0,
                category: item.category || "genel",
                isSystemItem: item.isSystemItem || false,
                icon: item.icon || "Circle",
            }));
        }),

    syncImportedItems: (importedItems) => {
        let idMap = {};

        set((state) => {
            importedItems.forEach((item) => {
                const itemNameLower = item.originalName.toLowerCase();

                // Check if item already exists in market (case-insensitive)
                const existingItem = state.marketItems.find(
                    (marketItem) => marketItem.name.toLowerCase() === itemNameLower
                );

                if (existingItem) {
                    // Item exists - map temp ID to existing ID
                    idMap[item.tempId] = existingItem.id;
                } else {
                    // Item doesn't exist - create new market item
                    const newId = crypto.randomUUID();
                    const newItem = {
                        id: newId,
                        originalId: null,
                        name: item.originalName,
                        price: 0,
                        category: 'ithal',
                        isSystemItem: false,
                        icon: item.icon || 'Circle',
                    };

                    state.marketItems.push(newItem);
                    idMap[item.tempId] = newId;
                }
            });
        });

        return idMap;
    },
});
