/**
 * ============================================================================
 * INITIAL DATA - Profile-Based Dynamic System
 * ============================================================================
 * 
 * Bu dosya sadece ilk açılışta kullanılan örnek verileri içerir.
 * Kullanıcı isterse tüm verileri silebilir ve kendi verilerini oluşturabilir.
 */

/**
 * Item Registry (Katalog)
 * Sadece item tanımları - FİYAT YOK!
 */
export const initialItemRegistry = [
  {
    id: "5f8a2c1d-3e4b-4a9f-8c7d-1a2b3c4d5e6f",
    originalId: "yefsun",
    name: "Efsun Nesnesi (Yeşil)",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "7b9c3d2e-4f5a-6b8c-9d7e-2a3b4c5d6e7f",
    originalId: "yart",
    name: "Arttırma Kağıdı (Yeşil)",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "9d1e4f3a-5b6c-7d8e-9f1a-3b4c5d6e7f8a",
    originalId: "efsun",
    name: "Efsun Nesnesi",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "1a2b3c4d-5e6f-7a8b-9c1d-4e5f6a7b8c9d",
    originalId: "art",
    name: "Arttırma Kağıdı",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "3c4d5e6f-7a8b-9c1d-2e3f-5a6b7c8d9e1f",
    originalId: "tas",
    name: "Ruh Taşı",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b",
    originalId: "cor",
    name: "Cor Draconis",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "7a8b9c1d-2e3f-4a5b-6c7d-8e9f1a2b3c4d",
    originalId: "munzevi",
    name: "Münzevi Tavsiyesi",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "9c1d2e3f-4a5b-6c7d-8e9f-1a2b3c4d5e6f",
    originalId: "zen",
    name: "Zen Fasulyesi",
    category: "genel",
    icon: "Circle",
  },
  {
    id: "2e3f4a5b-6c7d-8e9f-1a2b-3c4d5e6f7a8b",
    originalId: "enerji",
    name: "Enerji Parçası",
    category: "genel",
    icon: "Circle",
  },
];

/**
 * Default Market Profile
 * Örnek bir fiyat listesi
 */
export const initialMarketProfile = {
  id: "default-profile",
  name: "Varsayılan Fiyatlar",
  prices: {
    "5f8a2c1d-3e4b-4a9f-8c7d-1a2b3c4d5e6f": 3000000,  // Efsun Nesnesi (Yeşil)
    "7b9c3d2e-4f5a-6b8c-9d7e-2a3b4c5d6e7f": 1500000,  // Arttırma Kağıdı (Yeşil)
    "9d1e4f3a-5b6c-7d8e-9f1a-3b4c5d6e7f8a": 6000000,  // Efsun Nesnesi
    "1a2b3c4d-5e6f-7a8b-9c1d-4e5f6a7b8c9d": 800000,   // Arttırma Kağıdı
    "3c4d5e6f-7a8b-9c1d-2e3f-5a6b7c8d9e1f": 5000000,  // Ruh Taşı
    "5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b": 25000000, // Cor Draconis
    "7a8b9c1d-2e3f-4a5b-6c7d-8e9f1a2b3c4d": 40000000, // Münzevi Tavsiyesi
    "9c1d2e3f-4a5b-6c7d-8e9f-1a2b3c4d5e6f": 80000000, // Zen Fasulyesi
    "2e3f4a5b-6c7d-8e9f-1a2b-3c4d5e6f7a8b": 450000,   // Enerji Parçası
  },
};

/**
 * Metin Listesi
 * Modern şemaya dönüştürülmüş metin verisi
 */
export const initialMetinList = [
  {
    id: "metin-1",
    name: "Metin Taşı (Lv.40)",
    hp: 10000,
    drops: [
      { itemId: "yefsun", count: 1, chance: 15 },
      { itemId: "yart", count: 1, chance: 10 },
      { itemId: "enerji", count: 2, chance: 25 },
    ],
  },
  {
    id: "metin-2",
    name: "Metin Taşı (Lv.50)",
    hp: 15000,
    drops: [
      { itemId: "yefsun", count: 1, chance: 18 },
      { itemId: "yart", count: 1, chance: 12 },
      { itemId: "tas", count: 1, chance: 8 },
      { itemId: "enerji", count: 3, chance: 30 },
    ],
  },
  {
    id: "metin-3",
    name: "Metin Taşı (Lv.60)",
    hp: 22000,
    drops: [
      { itemId: "efsun", count: 1, chance: 12 },
      { itemId: "art", count: 1, chance: 8 },
      { itemId: "tas", count: 1, chance: 10 },
      { itemId: "enerji", count: 4, chance: 35 },
    ],
  },
  {
    id: "metin-4",
    name: "Metin Taşı (Lv.70)",
    hp: 30000,
    drops: [
      { itemId: "efsun", count: 1, chance: 15 },
      { itemId: "art", count: 1, chance: 10 },
      { itemId: "tas", count: 2, chance: 12 },
      { itemId: "cor", count: 1, chance: 5 },
      { itemId: "enerji", count: 5, chance: 40 },
    ],
  },
  {
    id: "metin-5",
    name: "Metin Taşı (Lv.80)",
    hp: 45000,
    drops: [
      { itemId: "efsun", count: 2, chance: 18 },
      { itemId: "art", count: 2, chance: 12 },
      { itemId: "tas", count: 3, chance: 15 },
      { itemId: "cor", count: 1, chance: 8 },
      { itemId: "munzevi", count: 1, chance: 3 },
      { itemId: "enerji", count: 6, chance: 45 },
    ],
  },
  {
    id: "metin-6",
    name: "Metin Taşı (Lv.90)",
    hp: 65000,
    drops: [
      { itemId: "efsun", count: 3, chance: 20 },
      { itemId: "art", count: 3, chance: 15 },
      { itemId: "tas", count: 4, chance: 18 },
      { itemId: "cor", count: 2, chance: 10 },
      { itemId: "munzevi", count: 1, chance: 5 },
      { itemId: "zen", count: 1, chance: 2 },
      { itemId: "enerji", count: 8, chance: 50 },
    ],
  },
];

/**
 * Legacy Compatibility
 * Eski kodların çalışması için geçici wrapper
 * @deprecated Use initialItemRegistry and initialMarketProfile instead
 */
export const initialMarketItems = initialItemRegistry.map(item => ({
  ...item,
  price: initialMarketProfile.prices[item.id] || 0,
  isSystemItem: true,
}));
