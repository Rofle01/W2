"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import { X, EyeOff, TrendingUp, Award, Calculator } from "lucide-react";
import useWidgetStore from "../../store/useWidgetStore";
import {
    calculateAllMetins,
    getBestMetin,
    formatCurrency,
    formatCompactCurrency,
    formatTime,
} from "../../lib/calculator";

// ============================================================================
// SUMMARY VIEW COMPONENT
// ============================================================================
function AnalysisSummaryView() {
    const marketItems = useWidgetStore((state) => state.marketItems);
    const metinList = useWidgetStore((state) => state.metinList);
    const userStats = useWidgetStore((state) => state.userStats);

    const bestMetin = useMemo(() => {
        const calculations = calculateAllMetins(metinList, marketItems, userStats);
        return getBestMetin(calculations);
    }, [metinList, marketItems, userStats]);

    if (!bestMetin) {
        return (
            <div className="flex items-center justify-center h-full text-zinc-400">
                <p>Veri bekleniyor...</p>
            </div>
        );
    }

    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden px-4">
            {/* Best Metin Badge */}
            <div className="flex items-center gap-2 mb-3">
                <Award className="w-6 h-6 text-green-600" />
                <span className="text-xs font-semibold text-green-700 uppercase tracking-wide">
                    En Karlı Metin
                </span>
            </div>

            {/* Metin Name */}
            <h3 className="text-2xl font-bold text-zinc-800 mb-4 text-center">
                {bestMetin.metinName}
            </h3>

            {/* Split Stats */}
            <div className="grid grid-cols-2 gap-6 w-full max-w-xs">
                {/* Left: Drop Value */}
                <div className="flex flex-col items-center border-r border-zinc-200 pr-4">
                    <span className="text-xs text-zinc-500 mb-1">Metin Başı</span>
                    <span className="text-xl font-bold text-green-600">
                        {formatCompactCurrency(bestMetin.dropValuePerMetin)}
                    </span>
                    <span className="text-xs text-zinc-400">Yang</span>
                </div>

                {/* Right: Metins Per Hour */}
                <div className="flex flex-col items-center pl-4">
                    <span className="text-xs text-zinc-500 mb-1">Saatte</span>
                    <span className="text-xl font-bold text-blue-600">
                        {bestMetin.metinsPerHour.toFixed(1)}
                    </span>
                    <span className="text-xs text-zinc-400">Adet</span>
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW COMPONENT
// ============================================================================
function AnalysisDetailView() {
    const marketItems = useWidgetStore((state) => state.marketItems);
    const metinList = useWidgetStore((state) => state.metinList);
    const userStats = useWidgetStore((state) => state.userStats);

    const calculations = useMemo(() => {
        return calculateAllMetins(metinList, marketItems, userStats);
    }, [metinList, marketItems, userStats]);

    const bestMetin = getBestMetin(calculations);
    const totalHourlyProfit = useMemo(() => {
        return calculations.reduce((sum, calc) => sum + calc.hourlyProfit, 0);
    }, [calculations]);

    return (
        <div className="space-y-6 h-full flex flex-col">
            {/* Top Summary Banner */}
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-200 shadow-sm">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-green-700 mb-1 flex items-center gap-2">
                            <Award className="w-4 h-4" />
                            En Karlı Seçim
                        </p>
                        <h3 className="text-2xl font-bold text-green-900 mb-1">
                            {bestMetin?.metinName || "Hesaplanıyor..."}
                        </h3>
                        <p className="text-sm text-green-700">
                            Saatlik Tahmini Kazanç
                        </p>
                    </div>
                    <div className="text-right">
                        <p className="text-4xl font-bold text-green-600">
                            {formatCompactCurrency(bestMetin?.hourlyProfit || 0)}
                        </p>
                        <p className="text-sm text-green-700">Yang / Saat</p>
                    </div>
                </div>
            </div>

            {/* Stats Cards Row */}
            <div className="grid grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-xl border border-zinc-200">
                    <p className="text-xs text-zinc-500 mb-1">Kesim Süresi</p>
                    <p className="text-2xl font-bold text-zinc-800">
                        {formatTime(bestMetin?.killTime || 0)}
                    </p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-zinc-200">
                    <p className="text-xs text-zinc-500 mb-1">Döngü Süresi</p>
                    <p className="text-2xl font-bold text-zinc-800">
                        {formatTime(bestMetin?.cycleTime || 0)}
                    </p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-zinc-200">
                    <p className="text-xs text-zinc-500 mb-1">Saatlik Adet</p>
                    <p className="text-2xl font-bold text-blue-600">
                        {(bestMetin?.metinsPerHour || 0).toFixed(1)}
                    </p>
                </div>
            </div>

            {/* Detailed Table */}
            <div className="flex-1 overflow-hidden flex flex-col">
                <h4 className="text-lg font-semibold text-zinc-800 mb-3 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    Karlılık Sıralaması
                </h4>

                <div className="flex-1 overflow-auto rounded-xl border border-zinc-200">
                    <table className="w-full">
                        <thead className="bg-zinc-100 sticky top-0">
                            <tr>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase tracking-wider">
                                    Sıra
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase tracking-wider">
                                    Metin Adı
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase tracking-wider">
                                    Kesim Süresi
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase tracking-wider">
                                    Saatlik Adet
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase tracking-wider">
                                    Metin Değeri
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase tracking-wider">
                                    Saatlik Kazanç
                                </th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-zinc-200">
                            {calculations.map((calc, index) => (
                                <tr
                                    key={calc.metinId}
                                    className={`hover:bg-zinc-50 transition-colors ${index === 0 ? "bg-green-50" : ""
                                        }`}
                                >
                                    <td className="px-4 py-3">
                                        {index === 0 ? (
                                            <div className="flex items-center gap-1">
                                                <Award className="w-4 h-4 text-green-600" />
                                                <span className="font-bold text-green-700">1</span>
                                            </div>
                                        ) : (
                                            <span className="text-zinc-500">{index + 1}</span>
                                        )}
                                    </td>
                                    <td className="px-4 py-3">
                                        <span
                                            className={`font-semibold ${index === 0 ? "text-green-800" : "text-zinc-800"
                                                }`}
                                        >
                                            {calc.metinName}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3 text-zinc-600">
                                        {formatTime(calc.killTime)}
                                    </td>
                                    <td className="px-4 py-3 text-blue-600 font-semibold">
                                        {calc.metinsPerHour.toFixed(1)}
                                    </td>
                                    <td className="px-4 py-3 text-zinc-700">
                                        {formatCurrency(calc.dropValuePerMetin)} Yang
                                    </td>
                                    <td className="px-4 py-3">
                                        <span
                                            className={`font-bold ${index === 0 ? "text-green-600 text-lg" : "text-zinc-800"
                                                }`}
                                        >
                                            {formatCurrency(calc.hourlyProfit)} Yang
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Footer Summary */}
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200 flex items-center justify-between">
                <span className="text-sm text-zinc-600">
                    Toplam {calculations.length} metin analiz edildi
                </span>
                <div className="text-right">
                    <p className="text-xs text-zinc-500">
                        En iyi seçim ile saatte:
                    </p>
                    <p className="text-xl font-bold text-green-600">
                        {formatCurrency(bestMetin?.hourlyProfit || 0)} Yang
                    </p>
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN ANALYSIS WIDGET COMPONENT
// ============================================================================
export default function AnalysisWidget({ id, isSelected, onClick, onHide }) {
    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group bg-white rounded-3xl shadow-sm border border-zinc-200 cursor-pointer overflow-hidden ${isSelected
                    ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-7xl z-50 shadow-2xl"
                    : "relative h-64 hover:-translate-y-1 hover:shadow-lg hover:border-green-200 transition-all duration-300"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {/* ============================================================================
         SUMMARY VIEW (Collapsed)
         ============================================================================ */}
            {!isSelected && (
                <>
                    {/* Hide Button */}
                    <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => {
                            e.stopPropagation();
                            onHide && onHide();
                        }}
                        className="absolute top-4 right-4 z-20 p-2 bg-white/80 backdrop-blur-sm shadow-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-zinc-400 hover:text-red-500 hover:bg-red-50"
                    >
                        <EyeOff className="w-4 h-4" />
                    </motion.button>

                    {/* Content */}
                    <div className="w-full h-full p-6 relative">
                        {/* Decorative Background Icon */}
                        <Calculator className="absolute -bottom-4 -right-4 w-32 h-32 text-green-50 opacity-50 rotate-12 pointer-events-none" />

                        {/* Summary Component */}
                        <AnalysisSummaryView />
                    </div>
                </>
            )}

            {/* ============================================================================
         DETAIL VIEW (Expanded)
         ============================================================================ */}
            {isSelected && (
                <div className="flex flex-col h-full bg-zinc-50/50">
                    {/* Header */}
                    <div className="flex items-center justify-between p-8 border-b border-zinc-200 bg-white">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-green-50 rounded-2xl">
                                <Calculator className="w-8 h-8 text-green-600" />
                            </div>
                            <div>
                                <motion.h2
                                    layoutId={`title-${id}`}
                                    className="text-2xl font-bold text-zinc-800"
                                >
                                    Analiz & Simülasyon
                                </motion.h2>
                                <p className="text-zinc-500">
                                    Karlılık analizi ve en iyi farming stratejisi
                                </p>
                            </div>
                        </div>

                        {/* Close Button */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                        >
                            <X className="w-6 h-6 text-zinc-500" />
                        </button>
                    </div>

                    {/* Content */}
                    <div className="flex-1 p-8 overflow-hidden">
                        <AnalysisDetailView />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
