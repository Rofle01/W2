"use client";

import { useState, useCallback, useMemo } from "react";
import {
    Calculator,
    Loader2,
    Settings,
    ChevronDown,
    Gem,
    Sparkles,
    Percent,
    Package,
    Layers,
    Target,
    ToggleLeft,
    ToggleRight,
    Trash2,
    Coins,
    TrendingUp
} from "lucide-react";
import { usePersistentState } from "../../../hooks/usePersistentState";
import { useWorker } from "../../../hooks/useWorker";
import SmartInput from "../../ui/SmartInput";

// ============================================================================
// CONSTANTS
// ============================================================================

const ELEMENTS = {
    diamond: { name: 'Elmas', color: 'cyan-200', bgColor: 'bg-cyan-500/20', borderColor: 'border-cyan-500/30', textColor: 'text-cyan-300' },
    ruby: { name: 'Yakut', color: 'rose-500', bgColor: 'bg-rose-500/20', borderColor: 'border-rose-500/30', textColor: 'text-rose-300' },
    jade: { name: 'Yeşim', color: 'emerald-500', bgColor: 'bg-emerald-500/20', borderColor: 'border-emerald-500/30', textColor: 'text-emerald-300' },
    sapphire: { name: 'Safir', color: 'blue-500', bgColor: 'bg-blue-500/20', borderColor: 'border-blue-500/30', textColor: 'text-blue-300' },
    garnet: { name: 'Garnet', color: 'orange-500', bgColor: 'bg-orange-500/20', borderColor: 'border-orange-500/30', textColor: 'text-orange-300' },
    onyx: { name: 'Oniks', color: 'zinc-400', bgColor: 'bg-zinc-700/50', borderColor: 'border-zinc-500/30', textColor: 'text-zinc-300' },
    amethyst: { name: 'Ametist', color: 'purple-500', bgColor: 'bg-purple-500/20', borderColor: 'border-purple-500/30', textColor: 'text-purple-300' }
};

const CLASS_LEVELS = {
    rough: { name: 'İşlenmemiş', shortName: 'Rough' },
    cut: { name: 'Yontulmuş', shortName: 'Cut' },
    rare: { name: 'Nadir', shortName: 'Rare' },
    antique: { name: 'Antika', shortName: 'Antique' },
    legendary: { name: 'Efsanevi', shortName: 'Legend' },
    mythic: { name: 'Mitsi', shortName: 'Mythic' }
};

const CLARITY_LEVELS = {
    matte: { name: 'Mat', shortName: 'Mat' },
    clear: { name: 'Berrak', shortName: 'Clear' },
    brilliant: { name: 'Parlak', shortName: 'Brill' },
    excellent: { name: 'Mükemmel', shortName: 'Exc' },
    flawless: { name: 'Kusursuz', shortName: 'Flaw' }
};

const TARGET_CLASS_OPTIONS = [
    { value: 'antique', label: 'Antika' },
    { value: 'legendary', label: 'Efsanevi' },
    { value: 'mythic', label: 'Mitsi' }
];

const COR_OUTPUT_OPTIONS = [
    { value: 'rough', label: 'İşlenmemiş (Rough)' },
    { value: 'cut', label: 'Yontulmuş (Cut)' },
    { value: 'rare', label: 'Nadir (Rare)' },
    { value: 'antique', label: 'Antika (Antique)' },
    { value: 'legendary', label: 'Efsanevi (Legendary)' },
    { value: 'mythic', label: 'Mitsi (Mythic)' }
];

const DEFAULT_CONFIG = {
    activeElements: ['diamond', 'ruby', 'jade', 'sapphire', 'garnet', 'onyx'],
    corOutput: 'rough',
    targetClass: 'mythic',
    upgradeClarity: false,
    requirements: {
        classUpgrade: 2,
        clarityUpgrade: 2
    },
    rates: {
        class: 50,
        clarity: 70
    }
};

const DEFAULT_INPUT = {
    corCount: 1000,
    corPrice: 0,
    simCount: 100
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const formatNumber = (num) => {
    if (num === undefined || num === null || isNaN(num)) return "0";
    if (num >= 1) return num.toFixed(1);
    if (num >= 0.01) return num.toFixed(2);
    if (num > 0) return num.toFixed(3);
    return "0";
};

const formatCurrency = (value) => {
    if (value === undefined || value === null || isNaN(value)) return "0";
    if (value >= 1000000000) return `${(value / 1000000000).toFixed(2)}B`;
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return Math.round(value).toLocaleString("tr-TR");
};

// ============================================================================
// ELEMENT RESULT CARD - REVISED
// ============================================================================

function ElementResultCard({ element, summary, config }) {
    const elementInfo = ELEMENTS[element];
    if (!elementInfo) return null;

    const targetClassInfo = CLASS_LEVELS[config.targetClass];
    const targetTotal = summary?.targetClassTotal?.[element] || 0;
    const clarityBreakdown = summary?.targetClassByClarity?.[element] || {};
    const leftovers = summary?.leftoversByClass?.[element] || {};

    // Skip if no stones at all
    if (targetTotal < 0.001 && Object.keys(leftovers).length === 0) return null;

    return (
        <div className={`p-4 rounded-xl border ${elementInfo.borderColor} ${elementInfo.bgColor}`}>
            {/* Header */}
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                    <Gem className={`w-5 h-5 ${elementInfo.textColor}`} />
                    <h4 className={`font-semibold ${elementInfo.textColor}`}>
                        {targetClassInfo?.name} {elementInfo.name}
                    </h4>
                </div>
                <span className="text-lg font-bold text-white font-mono">
                    {formatNumber(targetTotal)}
                </span>
            </div>

            {/* Clarity Breakdown (only if upgradeClarity is enabled) */}
            {config.upgradeClarity && Object.keys(clarityBreakdown).length > 0 && (
                <div className="space-y-1 mb-3 pl-2 border-l-2 border-white/10">
                    {Object.entries(clarityBreakdown).map(([clarity, count]) => (
                        <div key={clarity} className="flex justify-between items-center text-xs">
                            <span className="text-zinc-400">{CLARITY_LEVELS[clarity]?.name}</span>
                            <span className="text-white font-mono">{formatNumber(count)}</span>
                        </div>
                    ))}
                </div>
            )}

            {/* Leftovers */}
            {Object.keys(leftovers).length > 0 && (
                <div className="pt-2 border-t border-white/10">
                    <div className="flex items-center gap-1 text-xs text-zinc-500 mb-1">
                        <Trash2 className="w-3 h-3" />
                        <span>Artıklar</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {Object.entries(leftovers).map(([classLevel, count]) => (
                            <span key={classLevel} className="text-xs text-zinc-500">
                                {formatNumber(count)} {CLASS_LEVELS[classLevel]?.shortName}
                            </span>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

// ============================================================================
// MAIN PANEL
// ============================================================================

export default function AlchemyPanel() {
    // Persistent state
    const [config, setConfig] = usePersistentState("alchemy-config-v2", DEFAULT_CONFIG);
    const [input, setInput] = usePersistentState("alchemy-input-v2", DEFAULT_INPUT);

    // Worker
    const { run, status, result, progress, isRunning, reset } = useWorker("/workers/alchemy.worker.js");

    // UI state
    const [showAdvanced, setShowAdvanced] = useState(false);

    // Handlers
    const handleInputChange = useCallback((field, value) => {
        setInput(prev => ({ ...prev, [field]: value }));
    }, [setInput]);

    const handleConfigChange = useCallback((field, value) => {
        setConfig(prev => ({ ...prev, [field]: value }));
    }, [setConfig]);

    const handleRequirementChange = useCallback((field, value) => {
        setConfig(prev => ({
            ...prev,
            requirements: { ...prev.requirements, [field]: value }
        }));
    }, [setConfig]);

    const handleRateChange = useCallback((field, value) => {
        setConfig(prev => ({
            ...prev,
            rates: { ...prev.rates, [field]: value }
        }));
    }, [setConfig]);

    const toggleElement = useCallback((element) => {
        setConfig(prev => {
            const current = prev.activeElements || [];
            if (current.includes(element)) {
                return { ...prev, activeElements: current.filter(e => e !== element) };
            } else {
                return { ...prev, activeElements: [...current, element] };
            }
        });
    }, [setConfig]);

    const toggleClarity = useCallback(() => {
        setConfig(prev => ({ ...prev, upgradeClarity: !prev.upgradeClarity }));
    }, [setConfig]);

    const handleSimulate = useCallback(() => {
        run({
            action: "run_simulation",
            corCount: input.corCount,
            corPrice: input.corPrice,
            simCount: input.simCount,
            config: config
        });
    }, [run, input, config]);

    return (
        <div className="h-full flex flex-col overflow-hidden">
            {/* Header */}
            <header className="flex-shrink-0 p-6 border-b border-zinc-800 bg-zinc-950/80">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-purple-900/30 rounded-xl border border-purple-500/30">
                            <Gem className="w-6 h-6 text-purple-400" />
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-white">Ejderha Simyası</h2>
                            <p className="text-xs text-zinc-500">Dragon Soul Alchemy Simülasyonu</p>
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <div className="flex-1 overflow-auto p-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                    {/* Left Column - Input & Settings */}
                    <div className="space-y-4">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                            <Package className="w-4 h-4" />
                            Hızlı İşlem
                        </h3>

                        {/* Cor Count */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Cor Draconis Sayısı
                            </label>
                            <div className="flex items-center gap-2">
                                <Gem className="w-4 h-4 text-purple-500" />
                                <SmartInput
                                    value={input.corCount}
                                    onChange={(val) => handleInputChange("corCount", val)}
                                    min={1}
                                    className="flex-1 px-3 py-2 text-lg font-mono font-semibold text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500/50"
                                    placeholder="1000"
                                />
                            </div>
                        </div>

                        {/* Cor Price - GÖREV 2 */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Cor Draconis Fiyatı (Yang)
                            </label>
                            <div className="flex items-center gap-2">
                                <Coins className="w-4 h-4 text-yellow-500" />
                                <SmartInput
                                    value={input.corPrice}
                                    onChange={(val) => handleInputChange("corPrice", val)}
                                    min={0}
                                    className="flex-1 px-3 py-2 text-lg font-mono font-semibold text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500/30 focus:border-yellow-500/50"
                                    placeholder="0"
                                />
                            </div>
                            <p className="text-xs text-zinc-600 mt-2">
                                Maliyet hesabı için (opsiyonel): {formatCurrency(input.corPrice)} Yang
                            </p>
                        </div>

                        {/* PRODUCTION STRATEGY - NEW SECTION */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800 space-y-4">
                            <h4 className="text-xs font-semibold text-zinc-300 flex items-center gap-2">
                                <Target className="w-4 h-4 text-violet-400" />
                                Üretim Stratejisi
                            </h4>

                            {/* Target Class */}
                            <div>
                                <label className="block text-xs text-zinc-500 mb-1.5">
                                    Hedef Sınıf (Hangi seviyeye kadar?)
                                </label>
                                <select
                                    value={config.targetClass}
                                    onChange={(e) => handleConfigChange("targetClass", e.target.value)}
                                    className="w-full px-3 py-2 text-sm text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500/30"
                                >
                                    {TARGET_CLASS_OPTIONS.map(opt => (
                                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Clarity Toggle */}
                            <div
                                onClick={toggleClarity}
                                className={`
                                    flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-all
                                    ${config.upgradeClarity
                                        ? 'bg-violet-500/20 border-violet-500/40'
                                        : 'bg-zinc-900 border-zinc-700 hover:border-zinc-600'
                                    }
                                `}
                            >
                                <div className="flex items-center gap-2">
                                    <Sparkles className={`w-4 h-4 ${config.upgradeClarity ? 'text-violet-400' : 'text-zinc-500'}`} />
                                    <span className={`text-sm ${config.upgradeClarity ? 'text-white' : 'text-zinc-400'}`}>
                                        Saflık Yükselt
                                    </span>
                                </div>
                                {config.upgradeClarity ? (
                                    <ToggleRight className="w-6 h-6 text-violet-400" />
                                ) : (
                                    <ToggleLeft className="w-6 h-6 text-zinc-600" />
                                )}
                            </div>
                            {config.upgradeClarity && (
                                <p className="text-xs text-violet-300/70 -mt-2 pl-1">
                                    Hedef sınıftaki taşların saflığı yükseltilecek
                                </p>
                            )}
                        </div>

                        {/* Simulation Count */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Simülasyon Sayısı: <span className="text-white font-mono">{input.simCount}</span>
                            </label>
                            <input
                                type="range"
                                min={10}
                                max={500}
                                step={10}
                                value={input.simCount}
                                onChange={(e) => handleInputChange("simCount", parseInt(e.target.value))}
                                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                            />
                        </div>

                        {/* Advanced Settings Accordion */}
                        <details
                            className="bg-zinc-900/50 rounded-xl border border-zinc-800 group"
                            open={showAdvanced}
                            onToggle={(e) => setShowAdvanced(e.target.open)}
                        >
                            <summary className="p-4 cursor-pointer list-none flex items-center justify-between hover:bg-zinc-800/30 transition-colors rounded-xl">
                                <div className="flex items-center gap-2">
                                    <Settings className="w-4 h-4 text-zinc-500" />
                                    <span className="text-xs font-medium text-zinc-400">Gelişmiş Sunucu Ayarları</span>
                                </div>
                                <ChevronDown className="w-4 h-4 text-zinc-500 transition-transform group-open:rotate-180" />
                            </summary>
                            <div className="p-4 pt-0 space-y-4">

                                {/* Active Elements */}
                                <div>
                                    <label className="block text-xs text-zinc-500 mb-2">Aktif Elementler</label>
                                    <div className="flex flex-wrap gap-2">
                                        {Object.entries(ELEMENTS).map(([key, info]) => (
                                            <button
                                                key={key}
                                                onClick={() => toggleElement(key)}
                                                className={`
                                                    px-3 py-1.5 text-xs rounded-lg border transition-all
                                                    ${config.activeElements?.includes(key)
                                                        ? `${info.bgColor} ${info.borderColor} text-white`
                                                        : 'bg-zinc-900 border-zinc-700 text-zinc-500 hover:text-zinc-300'
                                                    }
                                                `}
                                            >
                                                {info.name}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Cor Output */}
                                <div>
                                    <label className="block text-xs text-zinc-500 mb-2">Cor İçeriği (Ne atıyor?)</label>
                                    <select
                                        value={config.corOutput}
                                        onChange={(e) => handleConfigChange("corOutput", e.target.value)}
                                        className="w-full px-3 py-2 text-sm text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500/30"
                                    >
                                        {COR_OUTPUT_OPTIONS.map(opt => (
                                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                                        ))}
                                    </select>
                                </div>

                                {/* Requirements */}
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-xs text-zinc-500 mb-1">Sınıf Birleştirme</label>
                                        <SmartInput
                                            value={config.requirements?.classUpgrade ?? 2}
                                            onChange={(val) => handleRequirementChange("classUpgrade", val)}
                                            min={2}
                                            max={10}
                                            className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs text-zinc-500 mb-1">Saflık Birleştirme</label>
                                        <SmartInput
                                            value={config.requirements?.clarityUpgrade ?? 2}
                                            onChange={(val) => handleRequirementChange("clarityUpgrade", val)}
                                            min={2}
                                            max={10}
                                            className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                                        />
                                    </div>
                                </div>

                                {/* Rates */}
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-xs text-zinc-500 mb-1">Sınıf Şansı %</label>
                                        <div className="flex items-center gap-2">
                                            <SmartInput
                                                value={config.rates?.class ?? 50}
                                                onChange={(val) => handleRateChange("class", val)}
                                                min={1}
                                                max={100}
                                                className="flex-1 px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                                            />
                                            <Percent className="w-4 h-4 text-zinc-600" />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-xs text-zinc-500 mb-1">Saflık Şansı %</label>
                                        <div className="flex items-center gap-2">
                                            <SmartInput
                                                value={config.rates?.clarity ?? 70}
                                                onChange={(val) => handleRateChange("clarity", val)}
                                                min={1}
                                                max={100}
                                                className="flex-1 px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                                            />
                                            <Percent className="w-4 h-4 text-zinc-600" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </details>

                        {/* Simulate Button */}
                        <button
                            onClick={handleSimulate}
                            disabled={isRunning}
                            className={`
                                w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all duration-200
                                ${isRunning
                                    ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                                    : "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-lg shadow-purple-900/30"
                                }
                            `}
                        >
                            {isRunning ? (
                                <>
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                    Simüle Ediliyor... {progress}%
                                </>
                            ) : (
                                <>
                                    <Calculator className="w-5 h-5" />
                                    Simülasyonu Başlat
                                </>
                            )}
                        </button>

                        {/* Progress Bar */}
                        {isRunning && (
                            <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                                    style={{ width: `${progress}%` }}
                                />
                            </div>
                        )}
                    </div>

                    {/* Right Column - Results (The Treasury) */}
                    <div className="lg:col-span-2">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2 mb-4">
                            <Layers className="w-4 h-4" />
                            Hazine (Sonuçlar)
                        </h3>

                        {result ? (
                            <div className="space-y-4">
                                {/* Summary Card */}
                                <div className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 p-4 rounded-xl border border-purple-500/30">
                                    <div className="flex items-center justify-between flex-wrap gap-4">
                                        <div>
                                            <p className="text-xs text-purple-300">Simülasyon Özeti</p>
                                            <p className="text-lg font-bold text-white">
                                                {result.corCount?.toLocaleString()} Cor → {CLASS_LEVELS[result.config?.targetClass]?.name || 'Mitsi'}
                                            </p>
                                        </div>
                                        <div className="flex gap-4 text-right">
                                            <div>
                                                <p className="text-xs text-zinc-400">Deneme</p>
                                                <p className="text-sm font-mono text-purple-300">{result.simCount}x</p>
                                            </div>
                                            <div>
                                                <p className="text-xs text-zinc-400">Saflık</p>
                                                <p className="text-sm font-mono text-purple-300">
                                                    {result.config?.upgradeClarity ? 'Açık' : 'Kapalı'}
                                                </p>
                                            </div>
                                            <div>
                                                <p className="text-xs text-zinc-400">Süre</p>
                                                <p className="text-sm font-mono text-purple-300">{result.duration}ms</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Element Result Cards */}
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                    {result.config?.activeElements?.map(element => (
                                        <ElementResultCard
                                            key={element}
                                            element={element}
                                            summary={result.summary}
                                            config={result.config}
                                        />
                                    ))}
                                </div>

                                {/* MALİYET ANALİZİ - GÖREV 2 */}
                                {result.financials && result.financials.totalCost > 0 && (
                                    <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                                        <h4 className="text-sm font-semibold text-zinc-400 mb-3 flex items-center gap-2">
                                            <TrendingUp className="w-4 h-4 text-yellow-500" />
                                            Maliyet Analizi
                                        </h4>
                                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                            <div className="bg-zinc-800/50 p-3 rounded-lg">
                                                <p className="text-xs text-zinc-500">Toplam Harcanan</p>
                                                <p className="text-lg font-bold text-yellow-400 font-mono">
                                                    {formatCurrency(result.financials.totalCost)}
                                                </p>
                                                <p className="text-xs text-zinc-600">Yang</p>
                                            </div>
                                            <div className="bg-zinc-800/50 p-3 rounded-lg">
                                                <p className="text-xs text-zinc-500">{CLASS_LEVELS[result.config?.targetClass]?.name} Başına</p>
                                                <p className="text-lg font-bold text-purple-400 font-mono">
                                                    {formatCurrency(result.financials.costPerTargetStone)}
                                                </p>
                                                <p className="text-xs text-zinc-600">Yang / Adet</p>
                                            </div>
                                            {result.config?.upgradeClarity && result.financials.costPerFlawless > 0 && (
                                                <div className="bg-zinc-800/50 p-3 rounded-lg">
                                                    <p className="text-xs text-zinc-500">Kusursuz Başına</p>
                                                    <p className="text-lg font-bold text-pink-400 font-mono">
                                                        {formatCurrency(result.financials.costPerFlawless)}
                                                    </p>
                                                    <p className="text-xs text-zinc-600">Yang / Adet</p>
                                                </div>
                                            )}
                                            <div className="bg-zinc-800/50 p-3 rounded-lg">
                                                <p className="text-xs text-zinc-500">Toplam Hedef Taş</p>
                                                <p className="text-lg font-bold text-white font-mono">
                                                    {formatNumber(result.financials.totalTargetStones)}
                                                </p>
                                                <p className="text-xs text-zinc-600">Adet (Ortalama)</p>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-64 text-zinc-600 bg-zinc-900/30 rounded-xl border border-zinc-800">
                                <Gem className="w-12 h-12 mb-3 opacity-20" />
                                <p className="text-sm">Simülasyon sonuçları burada görünecek</p>
                                <p className="text-xs text-zinc-700 mt-1">
                                    Parametreleri ayarlayın ve "Başlat" butonuna tıklayın
                                </p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
