/**
 * ============================================================================
 * INITIAL DATA - Transform edilmiş Legacy Veriler
 * ============================================================================
 * 
 * Bu dosya, eski sistemden gelen statik verileri modern şemaya dönüştürülmüş
 * haliyle içerir. Veriler dönüştürme fonksiyonlarından geçirilerek hazırlanmıştır.
 */

/**
 * Piyasa Eşya Listesi
 * Modern şemaya dönüştürülmüş item verisi
 */
export const initialMarketItems = [
  {
    id: "5f8a2c1d-3e4b-4a9f-8c7d-1a2b3c4d5e6f",
    originalId: "yefsun",
    name: "Efsun Nesnesi (Yeşil)",
    price: 3000000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "7b9c3d2e-4f5a-6b8c-9d7e-2a3b4c5d6e7f",
    originalId: "yart",
    name: "Arttırma Kağıdı (Yeşil)",
    price: 1500000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "9d1e4f3a-5b6c-7d8e-9f1a-3b4c5d6e7f8a",
    originalId: "efsun",
    name: "Efsun Nesnesi",
    price: 6000000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "1a2b3c4d-5e6f-7a8b-9c1d-4e5f6a7b8c9d",
    originalId: "art",
    name: "Arttırma Kağıdı",
    price: 800000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "3c4d5e6f-7a8b-9c1d-2e3f-5a6b7c8d9e1f",
    originalId: "tas",
    name: "Ruh Taşı",
    price: 5000000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b",
    originalId: "cor",
    name: "Cor Draconis",
    price: 25000000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "7a8b9c1d-2e3f-4a5b-6c7d-8e9f1a2b3c4d",
    originalId: "munzevi",
    name: "Münzevi Tavsiyesi",
    price: 40000000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "9c1d2e3f-4a5b-6c7d-8e9f-1a2b3c4d5e6f",
    originalId: "zen",
    name: "Zen Fasulyesi",
    price: 80000000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
  {
    id: "2e3f4a5b-6c7d-8e9f-1a2b-3c4d5e6f7a8b",
    originalId: "enerji",
    name: "Enerji Parçası",
    price: 450000,
    category: "genel",
    isSystemItem: true,
    icon: "Circle",
  },
];

/**
 * Metin Listesi
 * Modern şemaya dönüştürülmüş metin verisi
 */
export const initialMetinList = [
  {
    id: "metin-ruh-4a5b6c7d-8e9f-1a2b-3c4d-5e6f7a8b9c1d",
    name: "Ruh Metni",
    hp: 119700,
    drops: [
      {
        id: "drop-1a2b3c4d-5e6f-7a8b-9c1d-2e3f4a5b6c7d",
        itemId: "yefsun",
        count: 4,
        chance: 100,
      },
      {
        id: "drop-2b3c4d5e-6f7a-8b9c-1d2e-3f4a5b6c7d8e",
        itemId: "yart",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-3c4d5e6f-7a8b-9c1d-2e3f-4a5b6c7d8e9f",
        itemId: "munzevi",
        count: 1,
        chance: 25,
      },
      {
        id: "drop-4d5e6f7a-8b9c-1d2e-3f4a-5b6c7d8e9f1a",
        itemId: "zen",
        count: 1,
        chance: 15,
      },
    ],
  },
  {
    id: "metin-golge-5b6c7d8e-9f1a-2b3c-4d5e-6f7a8b9c1d2e",
    name: "Gölge Metni",
    hp: 142350,
    drops: [
      {
        id: "drop-5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b",
        itemId: "yefsun",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-6f7a8b9c-1d2e-3f4a-5b6c-7d8e9f1a2b3c",
        itemId: "yart",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-7a8b9c1d-2e3f-4a5b-6c7d-8e9f1a2b3c4d",
        itemId: "efsun",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-8b9c1d2e-3f4a-5b6c-7d8e-9f1a2b3c4d5e",
        itemId: "art",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-9c1d2e3f-4a5b-6c7d-8e9f-1a2b3c4d5e6f",
        itemId: "munzevi",
        count: 1,
        chance: 25,
      },
    ],
  },
  {
    id: "metin-seytan-6c7d8e9f-1a2b-3c4d-5e6f-7a8b9c1d2e3f",
    name: "Şeytan Metni",
    hp: 195900,
    drops: [
      {
        id: "drop-1a2b3c4d-5e6f-7a8b-9c1d-2e3f4a5b6c7d",
        itemId: "yefsun",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-2b3c4d5e-6f7a-8b9c-1d2e-3f4a5b6c7d8e",
        itemId: "yart",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-3c4d5e6f-7a8b-9c1d-2e3f-4a5b6c7d8e9f",
        itemId: "efsun",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-4d5e6f7a-8b9c-1d2e-3f4a-5b6c7d8e9f1a",
        itemId: "art",
        count: 1,
        chance: 100,
      },
      {
        id: "drop-5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b",
        itemId: "cor",
        count: 1,
        chance: 10,
      },
      {
        id: "drop-6f7a8b9c-1d2e-3f4a-5b6c-7d8e9f1a2b3c",
        itemId: "munzevi",
        count: 1,
        chance: 25,
      },
    ],
  },
  {
    id: "metin-olum-7d8e9f1a-2b3c-4d5e-6f7a-8b9c1d2e3f4a",
    name: "Ölüm Metni",
    hp: 260250,
    drops: [
      {
        id: "drop-7a8b9c1d-2e3f-4a5b-6c7d-8e9f1a2b3c4d",
        itemId: "yefsun",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-8b9c1d2e-3f4a-5b6c-7d8e-9f1a2b3c4d5e",
        itemId: "yart",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-9c1d2e3f-4a5b-6c7d-8e9f-1a2b3c4d5e6f",
        itemId: "efsun",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-1a2b3c4d-5e6f-7a8b-9c1d-2e3f4a5b6c7d",
        itemId: "art",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-2b3c4d5e-6f7a-8b9c-1d2e-3f4a5b6c7d8e",
        itemId: "cor",
        count: 1,
        chance: 20,
      },
      {
        id: "drop-3c4d5e6f-7a8b-9c1d-2e3f-4a5b6c7d8e9f",
        itemId: "munzevi",
        count: 1,
        chance: 60,
      },
      {
        id: "drop-4d5e6f7a-8b9c-1d2e-3f4a-5b6c7d8e9f1a",
        itemId: "zen",
        count: 1,
        chance: 15,
      },
    ],
  },
  {
    id: "metin-katil-8e9f1a2b-3c4d-5e6f-7a8b-9c1d2e3f4a5b",
    name: "Katil Metni",
    hp: 296550,
    drops: [
      {
        id: "drop-5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b",
        itemId: "yefsun",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-6f7a8b9c-1d2e-3f4a-5b6c-7d8e9f1a2b3c",
        itemId: "yart",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-7a8b9c1d-2e3f-4a5b-6c7d-8e9f1a2b3c4d",
        itemId: "efsun",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-8b9c1d2e-3f4a-5b6c-7d8e-9f1a2b3c4d5e",
        itemId: "art",
        count: 2,
        chance: 100,
      },
      {
        id: "drop-9c1d2e3f-4a5b-6c7d-8e9f-1a2b3c4d5e6f",
        itemId: "cor",
        count: 1,
        chance: 10,
      },
      {
        id: "drop-1a2b3c4d-5e6f-7a8b-9c1d-2e3f4a5b6c7d",
        itemId: "munzevi",
        count: 1,
        chance: 25,
      },
      {
        id: "drop-2b3c4d5e-6f7a-8b9c-1d2e-3f4a5b6c7d8e",
        itemId: "zen",
        count: 1,
        chance: 15,
      },
    ],
  },
  {
    id: "metin-buyulu-9f1a2b3c-4d5e-6f7a-8b9c-1d2e3f4a5b6c",
    name: "Büyülü Metin",
    hp: 1500000,
    drops: [
      {
        id: "drop-3c4d5e6f-7a8b-9c1d-2e3f-4a5b6c7d8e9f",
        itemId: "efsun",
        count: 9,
        chance: 100,
      },
      {
        id: "drop-4d5e6f7a-8b9c-1d2e-3f4a-5b6c7d8e9f1a",
        itemId: "cor",
        count: 1,
        chance: 50,
      },
      {
        id: "drop-5e6f7a8b-9c1d-2e3f-4a5b-6c7d8e9f1a2b",
        itemId: "zen",
        count: 1,
        chance: 15,
      },
    ],
  },
];
