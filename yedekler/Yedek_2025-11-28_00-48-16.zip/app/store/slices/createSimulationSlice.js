import { initialMetinList } from "../../data/initialData";

export const createSimulationSlice = (set, get) => ({
    metinList: initialMetinList,
    userStats: {
        damage: 3000,
        hitsPerSecond: 2.5,
        findTime: 10,
    },

    updateUserStats: (newStats) =>
        set((state) => {
            state.userStats = { ...state.userStats, ...newStats };
        }),

    updateMetinHp: (metinId, newHp) =>
        set((state) => {
            const metin = state.metinList.find((m) => m.id === metinId);
            if (metin) {
                metin.hp = parseFloat(newHp) || 0;
            }
        }),

    addMetinDrop: (metinId, drop) =>
        set((state) => {
            const metin = state.metinList.find((m) => m.id === metinId);
            if (metin) {
                metin.drops.push({
                    id: crypto.randomUUID(),
                    itemId: drop.itemId,
                    count: drop.count || 1,
                    chance: drop.chance || 10,
                });
            }
        }),

    removeMetinDrop: (metinId, dropId) =>
        set((state) => {
            const metin = state.metinList.find((m) => m.id === metinId);
            if (metin) {
                const index = metin.drops.findIndex((d) => d.id === dropId);
                if (index !== -1) {
                    metin.drops.splice(index, 1);
                }
            }
        }),

    updateMetinDrop: (metinId, dropId, updates) =>
        set((state) => {
            const metin = state.metinList.find((m) => m.id === metinId);
            if (metin) {
                const drop = metin.drops.find((d) => d.id === dropId);
                if (drop) {
                    Object.assign(drop, updates);
                }
            }
        }),

    // Placeholder for future logic
    calculateIncome: (metinId) => {
        // Logic handled in components via services for now
        return null;
    }
});
