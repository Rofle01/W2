/**
 * Dragon Soul Alchemy Simulation Worker - Revised
 * 
 * Ejderha Taşı Simyası Monte Carlo Simülasyonu
 * 
 * YENİ MANTIK:
 * 1. Cor Açılımı -> Ham taşlar
 * 2. Sınıf Yükseltme -> Hedef sınıfa kadar (targetClass)
 * 3. Saflık Yükseltme (Opsiyonel) -> Sadece hedef sınıftaki taşlar
 */

// ============================================================================
// CONSTANTS
// ============================================================================

const SAFETY_LIMIT = 100_000;

// Element definitions
const ELEMENTS = {
    diamond: { name: 'Elmas', color: 'cyan' },
    ruby: { name: 'Yakut', color: 'rose' },
    jade: { name: 'Yeşim', color: 'emerald' },
    sapphire: { name: 'Safir', color: 'blue' },
    garnet: { name: 'Garnet', color: 'orange' },
    onyx: { name: 'Oniks', color: 'zinc' },
    amethyst: { name: 'Ametist', color: 'purple' }
};

// Stone class levels (ascending order)
const CLASS_LEVELS = ['rough', 'cut', 'rare', 'antique', 'legendary', 'mythic'];

// Stone clarity levels (ascending order) - EKLENDİ: excellent, flawless
const CLARITY_LEVELS = ['matte', 'clear', 'brilliant', 'excellent', 'flawless'];

// Default configuration
const DEFAULT_CONFIG = {
    activeElements: ['diamond', 'ruby', 'jade', 'sapphire', 'garnet', 'onyx'],
    corOutput: 'rough',
    targetClass: 'mythic',       // Hedef sınıf (antique, legendary, mythic)
    upgradeClarity: false,       // Saflık yükseltmesi yapılsın mı?
    requirements: {
        classUpgrade: 2,
        clarityUpgrade: 2
    },
    rates: {
        class: 50,
        clarity: 70
    }
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get random element from active elements
 */
function getRandomElement(activeElements) {
    const idx = Math.floor(Math.random() * activeElements.length);
    return activeElements[idx];
}

/**
 * Initialize empty inventory for all elements
 */
function createEmptyInventory(activeElements) {
    const inventory = {};
    activeElements.forEach(element => {
        inventory[element] = {};
        CLASS_LEVELS.forEach(classLevel => {
            inventory[element][classLevel] = {};
            CLARITY_LEVELS.forEach(clarity => {
                inventory[element][classLevel][clarity] = 0;
            });
        });
    });
    return inventory;
}

/**
 * Get class level index
 */
function getClassIndex(classLevel) {
    return CLASS_LEVELS.indexOf(classLevel);
}

/**
 * Get clarity level index
 */
function getClarityIndex(clarity) {
    return CLARITY_LEVELS.indexOf(clarity);
}

/**
 * Simulate opening Cor Draconis and getting stones
 */
function simulateCorOpening(corCount, config) {
    const inventory = createEmptyInventory(config.activeElements);
    const outputLevel = config.corOutput || 'rough';
    const startClarity = 'matte'; // Stones start at matte clarity

    for (let i = 0; i < corCount; i++) {
        const element = getRandomElement(config.activeElements);
        inventory[element][outputLevel][startClarity]++;
    }

    return inventory;
}

// ============================================================================
// NEW CLASS UPGRADE FUNCTION
// ============================================================================

/**
 * Upgrade stones to target class only
 * Taşları hedef sınıfa kadar yükselt, hedefe ulaşanları BIRAK
 */
function upgradeClassOnly(inventory, config) {
    const { classUpgrade } = config.requirements;
    const classRate = config.rates.class / 100;
    const targetClassIndex = getClassIndex(config.targetClass);

    // For each element
    Object.keys(inventory).forEach(element => {
        // Start from lowest class, go up to one below target
        for (let classIdx = 0; classIdx < targetClassIndex; classIdx++) {
            const currentClass = CLASS_LEVELS[classIdx];
            const nextClass = CLASS_LEVELS[classIdx + 1];

            // For each clarity level
            CLARITY_LEVELS.forEach(clarity => {
                let safetyCounter = 0;

                // Keep upgrading while we have enough stones
                while (inventory[element][currentClass][clarity] >= classUpgrade && safetyCounter < SAFETY_LIMIT) {
                    safetyCounter++;

                    // Use stones for upgrade attempt
                    inventory[element][currentClass][clarity] -= classUpgrade;

                    if (Math.random() < classRate) {
                        // Success - move to next class (same clarity)
                        inventory[element][nextClass][clarity]++;
                    } else {
                        // Failed - return 1 stone (standard Metin2 behavior)
                        inventory[element][currentClass][clarity]++;
                    }
                }
            });
        }
    });

    return inventory;
}

// ============================================================================
// NEW CLARITY UPGRADE FUNCTION
// ============================================================================

/**
 * Upgrade clarity ONLY for stones at target class
 * Sadece hedef sınıftaki taşların saflığını yükselt
 */
function upgradeClarityOnly(inventory, config) {
    const { clarityUpgrade } = config.requirements;
    const clarityRate = config.rates.clarity / 100;
    const targetClass = config.targetClass;

    // Only process target class
    Object.keys(inventory).forEach(element => {
        // For each clarity level (except the highest)
        for (let clarityIdx = 0; clarityIdx < CLARITY_LEVELS.length - 1; clarityIdx++) {
            const currentClarity = CLARITY_LEVELS[clarityIdx];
            const nextClarity = CLARITY_LEVELS[clarityIdx + 1];

            let safetyCounter = 0;

            // Keep upgrading while we have enough stones at target class
            while (inventory[element][targetClass][currentClarity] >= clarityUpgrade && safetyCounter < SAFETY_LIMIT) {
                safetyCounter++;

                // Use stones for upgrade attempt
                inventory[element][targetClass][currentClarity] -= clarityUpgrade;

                if (Math.random() < clarityRate) {
                    // Success - move to next clarity
                    inventory[element][targetClass][nextClarity]++;
                } else {
                    // Failed - return 1 stone with same clarity
                    inventory[element][targetClass][currentClarity]++;
                }
            }
        }
    });

    return inventory;
}

// ============================================================================
// INVENTORY UTILITIES
// ============================================================================

/**
 * Sum two inventories
 */
function sumInventories(inv1, inv2, activeElements) {
    const result = createEmptyInventory(activeElements);

    activeElements.forEach(element => {
        CLASS_LEVELS.forEach(classLevel => {
            CLARITY_LEVELS.forEach(clarity => {
                result[element][classLevel][clarity] =
                    (inv1[element]?.[classLevel]?.[clarity] || 0) +
                    (inv2[element]?.[classLevel]?.[clarity] || 0);
            });
        });
    });

    return result;
}

/**
 * Divide inventory counts by a number (for averaging)
 */
function averageInventory(inventory, divisor, activeElements) {
    const result = createEmptyInventory(activeElements);

    activeElements.forEach(element => {
        CLASS_LEVELS.forEach(classLevel => {
            CLARITY_LEVELS.forEach(clarity => {
                result[element][classLevel][clarity] =
                    (inventory[element][classLevel][clarity] || 0) / divisor;
            });
        });
    });

    return result;
}

/**
 * Calculate summary statistics
 */
function calculateSummary(inventory, config) {
    const summary = {
        targetClassTotal: {},
        targetClassByClarity: {},
        leftoversByClass: {}
    };

    const targetClass = config.targetClass;
    const targetClassIndex = getClassIndex(targetClass);

    config.activeElements.forEach(element => {
        // Count target class total
        let targetTotal = 0;
        const clarityBreakdown = {};

        CLARITY_LEVELS.forEach(clarity => {
            const count = inventory[element][targetClass][clarity] || 0;
            targetTotal += count;
            if (count > 0.001) {
                clarityBreakdown[clarity] = count;
            }
        });

        summary.targetClassTotal[element] = targetTotal;
        summary.targetClassByClarity[element] = clarityBreakdown;

        // Count leftovers (classes below target)
        const leftovers = {};
        for (let i = 0; i < targetClassIndex; i++) {
            const classLevel = CLASS_LEVELS[i];
            let classTotal = 0;
            CLARITY_LEVELS.forEach(clarity => {
                classTotal += inventory[element][classLevel][clarity] || 0;
            });
            if (classTotal > 0.001) {
                leftovers[classLevel] = classTotal;
            }
        }

        if (Object.keys(leftovers).length > 0) {
            summary.leftoversByClass[element] = leftovers;
        }
    });

    return summary;
}

/**
 * Calculate financial metrics
 */
function calculateFinancials(summary, corCount, corPrice, config) {
    const totalCost = corCount * corPrice;

    // Calculate total target class stones across all elements
    let totalTargetStones = 0;
    let totalFlawlessStones = 0;

    Object.values(summary.targetClassTotal).forEach(count => {
        totalTargetStones += count;
    });

    // Calculate flawless count if clarity upgrade is enabled
    if (config.upgradeClarity) {
        Object.values(summary.targetClassByClarity).forEach(clarityBreakdown => {
            totalFlawlessStones += clarityBreakdown.flawless || 0;
        });
    }

    return {
        totalCost,
        costPerTargetStone: totalTargetStones > 0 ? Math.round(totalCost / totalTargetStones) : 0,
        costPerFlawless: totalFlawlessStones > 0 ? Math.round(totalCost / totalFlawlessStones) : 0,
        totalTargetStones: parseFloat(totalTargetStones.toFixed(2)),
        totalFlawlessStones: parseFloat(totalFlawlessStones.toFixed(2))
    };
}

// ============================================================================
// MAIN SIMULATION
// ============================================================================

/**
 * Run Monte Carlo simulation with new strategy
 */
function runSimulation(corCount, simCount, config, corPrice) {
    const updateInterval = Math.max(1, Math.floor(simCount / 20));

    let totalInventory = createEmptyInventory(config.activeElements);

    for (let sim = 0; sim < simCount; sim++) {
        // Step 1: Open Cor and get initial stones
        let inventory = simulateCorOpening(corCount, config);

        // Step 2: Upgrade to target class
        inventory = upgradeClassOnly(inventory, config);

        // Step 3: If clarity upgrade enabled, do it
        if (config.upgradeClarity) {
            inventory = upgradeClarityOnly(inventory, config);
        }

        // Accumulate results
        totalInventory = sumInventories(totalInventory, inventory, config.activeElements);

        // Progress update
        if ((sim + 1) % updateInterval === 0) {
            self.postMessage({
                type: 'progress',
                progress: Math.round(((sim + 1) / simCount) * 100)
            });
        }
    }

    // Calculate averages
    const averageResults = averageInventory(totalInventory, simCount, config.activeElements);

    // Calculate summary
    const summary = calculateSummary(averageResults, config);

    // Calculate financials (GÖREV 2)
    const financials = calculateFinancials(summary, corCount, corPrice || 0, config);

    return {
        averageInventory: averageResults,
        summary,
        financials,
        corCount,
        corPrice: corPrice || 0,
        simCount,
        config: {
            activeElements: config.activeElements,
            corOutput: config.corOutput,
            targetClass: config.targetClass,
            upgradeClarity: config.upgradeClarity,
            requirements: config.requirements,
            rates: config.rates
        }
    };
}

// ============================================================================
// MESSAGE HANDLER
// ============================================================================

self.onmessage = (e) => {
    const { action, corCount, corPrice, simCount, config } = e.data;

    if (action === 'run_simulation') {
        try {
            // Merge with defaults
            const actualConfig = {
                ...DEFAULT_CONFIG,
                ...config,
                requirements: { ...DEFAULT_CONFIG.requirements, ...config?.requirements },
                rates: { ...DEFAULT_CONFIG.rates, ...config?.rates }
            };

            console.log('[Alchemy Worker] Starting simulation:', {
                corCount,
                corPrice,
                simCount,
                config: actualConfig
            });

            const startTime = performance.now();
            const result = runSimulation(
                corCount || 100,
                simCount || 100,
                actualConfig,
                corPrice || 0
            );
            const endTime = performance.now();

            self.postMessage({
                type: 'complete',
                ...result,
                duration: (endTime - startTime).toFixed(2)
            });
        } catch (error) {
            self.postMessage({
                type: 'error',
                message: error.message || 'Simulation failed'
            });
        }
    }
};
