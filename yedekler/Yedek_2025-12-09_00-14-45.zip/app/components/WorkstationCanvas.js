"use client";

import { useMemo } from "react";
import useWidgetStore from "../store/useWidgetStore";
import { getWidgetComponent } from "./WidgetRegistry";
import WindowFrame from "./WindowFrame";
import { AnimatePresence } from "framer-motion";

// Helper for Titles
const WIDGET_TITLES = {
    "money-input": "KASA YÖNETİMİ",
    "note-taker": "HIZLI NOTLAR",
    "market": "PAZAR ANALİZİ",
    "analysis": "GETİRİ HESAPLAMA",
    "crafting": "SİMYA DÖNÜŞÜM",
    "boss": "BOSS TAKİP SİSTEMİ",
    "supply": "ARZ / TALEP",
    "progression": "HASAR GÜNLÜĞÜ",
    "character": "KARAKTERLER"
};

export default function WorkstationCanvas() {
    const activeWorkspaceId = useWidgetStore((state) => state.activeWorkspaceId);
    const workspaces = useWidgetStore((state) => state.workspaces);

    const activeWorkspace = useMemo(() =>
        workspaces.find((w) => w.id === activeWorkspaceId),
        [workspaces, activeWorkspaceId]
    );

    if (!activeWorkspace) return null;

    return (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="relative w-full h-full pointer-events-auto">
                <AnimatePresence>
                    {activeWorkspace.widgets.map((widget) => {
                        if (!widget.isVisible) return null;

                        const WidgetComponent = getWidgetComponent(widget.type);
                        if (!WidgetComponent) return null;

                        // Fallback layout
                        const safeLayout = widget.layout || {
                            x: 100, y: 100, w: 500, h: 400, zIndex: 10, isMinimized: false, isMaximized: false
                        };

                        return (
                            <WindowFrame
                                key={widget.id}
                                id={widget.id}
                                title={WIDGET_TITLES[widget.type] || widget.type}
                                layout={safeLayout}
                            >
                                <WidgetComponent
                                    id={widget.id}
                                    data={widget.data}
                                // Cleanup: No longer passing isSelected or onHide 
                                // because WindowFrame handles these. 
                                // Passing logic for internal usage if necessary.
                                />
                            </WindowFrame>
                        );
                    })}
                </AnimatePresence>
            </div>
        </div>
    );
}
