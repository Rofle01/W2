import { initialItemRegistry, initialMarketProfile } from "../../data/initialData";

/**
 * ============================================================================
 * MARKET SLICE - Profile-Based Dynamic System
 * ============================================================================
 * 
 * Bu slice, item tanımlarını (registry) ve fiyat profillerini yönetir.
 * Tüm veriler dinamik ve kullanıcı tarafından yönetilebilir.
 */

export const createMarketSlice = (set, get) => ({
    // ========================================================================
    // STATE
    // ========================================================================

    /**
     * Item Registry (Katalog)
     * Tüm item tanımları - sadece isim, kategori, ikon
     */
    itemRegistry: initialItemRegistry || [],

    /**
     * Market Profiles (Fiyat Listeleri)
     * Her profil farklı bir fiyat senaryosu
     */
    marketProfiles: [initialMarketProfile],

    // ========================================================================
    // ITEM REGISTRY ACTIONS
    // ========================================================================

    /**
     * Register a single item to the catalog
     * @param {Object} item - Item definition (no price)
     */
    registerItem: (item) =>
        set((state) => {
            // Check if item already exists
            const exists = state.itemRegistry.some(i => i.id === item.id);
            if (exists) {
                console.warn(`Item ${item.id} already exists in registry`);
                return;
            }

            state.itemRegistry.push({
                id: item.id || crypto.randomUUID(),
                originalId: item.originalId || null,
                name: item.name,
                category: item.category || "genel",
                icon: item.icon || "Circle",
            });
        }),

    /**
     * Register multiple items to the catalog
     * @param {Array} items - Array of item definitions
     */
    registerItems: (items) =>
        set((state) => {
            if (!Array.isArray(items) || items.length === 0) return;

            items.forEach(item => {
                // Prevent duplicates
                const exists = state.itemRegistry.some(i => i.id === item.id);
                if (!exists) {
                    state.itemRegistry.push({
                        id: item.id || crypto.randomUUID(),
                        originalId: item.originalId || null,
                        name: item.name,
                        category: item.category || "genel",
                        icon: item.icon || "Circle",
                    });
                }
            });
        }),

    /**
     * Unregister (delete) an item from the catalog
     * CRITICAL: This will remove the item completely
     * @param {string} id - Item ID to remove
     */
    unregisterItem: (id) =>
        set((state) => {
            const index = state.itemRegistry.findIndex(i => i.id === id);
            if (index !== -1) {
                state.itemRegistry.splice(index, 1);

                // Also remove from all market profiles
                state.marketProfiles.forEach(profile => {
                    delete profile.prices[id];
                });
            }
        }),

    /**
     * Import item registry from external source (CSV/Excel)
     * @param {Array} items - Array of item definitions
     */
    importItemRegistry: (items) =>
        set((state) => {
            if (!Array.isArray(items)) {
                console.error("Imported data must be an array");
                return;
            }

            // Replace entire registry
            state.itemRegistry = items.map(item => ({
                id: item.id || crypto.randomUUID(),
                originalId: item.originalId || null,
                name: item.name || "İsimsiz Eşya",
                category: item.category || "genel",
                icon: item.icon || "Circle",
            }));
        }),

    // ========================================================================
    // MARKET PROFILE ACTIONS
    // ========================================================================

    /**
     * Create a new market profile
     * @param {string} name - Profile name
     * @param {Object} prices - Optional initial prices { itemId: price }
     * @returns {string} New profile ID
     */
    createMarketProfile: (name, prices = {}) => {
        const newProfile = {
            id: crypto.randomUUID(),
            name: name || "Yeni Profil",
            prices: { ...prices }, // Use provided prices or empty map
        };

        set((state) => {
            state.marketProfiles.push(newProfile);
        });

        return newProfile.id;
    },

    /**
     * Delete a market profile
     * @param {string} profileId - Profile ID to delete
     */
    deleteMarketProfile: (profileId) =>
        set((state) => {
            if (state.marketProfiles.length <= 1) {
                console.warn("Cannot delete the last profile");
                return;
            }

            const index = state.marketProfiles.findIndex(p => p.id === profileId);
            if (index !== -1) {
                state.marketProfiles.splice(index, 1);
            }
        }),

    /**
     * Rename a market profile
     * @param {string} profileId - Profile ID
     * @param {string} newName - New profile name
     */
    renameMarketProfile: (profileId, newName) =>
        set((state) => {
            const profile = state.marketProfiles.find(p => p.id === profileId);
            if (profile) {
                profile.name = newName;
            }
        }),

    /**
     * Update a price in a specific profile
     * @param {string} profileId - Profile ID
     * @param {string} itemId - Item ID
     * @param {number} price - New price
     */
    updatePriceInProfile: (profileId, itemId, price) =>
        set((state) => {
            const profile = state.marketProfiles.find(p => p.id === profileId);
            if (profile) {
                profile.prices[itemId] = parseFloat(price) || 0;
            }
        }),

    /**
     * Remove a price from a profile
     * @param {string} profileId - Profile ID
     * @param {string} itemId - Item ID
     */
    removePriceFromProfile: (profileId, itemId) =>
        set((state) => {
            const profile = state.marketProfiles.find(p => p.id === profileId);
            if (profile) {
                delete profile.prices[itemId];
            }
        }),

    /**
     * Duplicate a market profile
     * @param {string} profileId - Profile ID to duplicate
     * @returns {string} New profile ID
     */
    duplicateMarketProfile: (profileId) => {
        const state = get();
        const sourceProfile = state.marketProfiles.find(p => p.id === profileId);

        if (!sourceProfile) {
            console.error(`Profile ${profileId} not found`);
            return null;
        }

        const newProfile = {
            id: crypto.randomUUID(),
            name: `${sourceProfile.name} (Kopya)`,
            prices: { ...sourceProfile.prices }, // Deep copy prices
        };

        set((state) => {
            state.marketProfiles.push(newProfile);
        });

        return newProfile.id;
    },

    /**
     * Import prices to a profile from external source
     * @param {string} profileId - Profile ID
     * @param {Object} prices - Price map { itemId: price }
     * @param {boolean} merge - If true, merge with existing prices. If false, replace.
     */
    importPricesToProfile: (profileId, prices, merge = true) =>
        set((state) => {
            const profile = state.marketProfiles.find(p => p.id === profileId);
            if (profile) {
                if (merge) {
                    profile.prices = { ...profile.prices, ...prices };
                } else {
                    profile.prices = { ...prices };
                }
            }
        }),
});
