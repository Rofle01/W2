"use client";

import { Target, Link as LinkIcon } from "lucide-react";
import SmartInput from "../../../ui/SmartInput";

// ============================================================================
// CONSTANTS
// ============================================================================

const MATERIAL_OPTIONS = [
    { value: 'ritual_stone', label: 'Ritüel Taşı' },
    { value: 'magic_stone', label: 'Büyülü Metal' },
    { value: 'blessing_scroll', label: 'Kutsama Kağıdı' },
    { value: 'blacksmith_book', label: 'El Kitabı' }
];

const DEFAULT_STRATEGY = {
    0: { baseChance: 90, pityLimit: 5, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    1: { baseChance: 85, pityLimit: 5, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    2: { baseChance: 80, pityLimit: 6, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    3: { baseChance: 75, pityLimit: 6, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    4: { baseChance: 70, pityLimit: 7, priorityList: ['blessing_scroll'], upgradeCost: 100000 },
    5: { baseChance: 60, pityLimit: 8, priorityList: ['blessing_scroll', 'magic_stone'], upgradeCost: 200000 },
    6: { baseChance: 50, pityLimit: 10, priorityList: ['magic_stone', 'blessing_scroll'], upgradeCost: 300000 },
    7: { baseChance: 40, pityLimit: 12, priorityList: ['ritual_stone', 'magic_stone'], upgradeCost: 400000 },
    8: { baseChance: 30, pityLimit: 15, priorityList: ['ritual_stone', 'magic_stone', 'blessing_scroll'], upgradeCost: 500000 }
};

// ============================================================================
// SUB-COMPONENT: StrategyRow
// ============================================================================

function StrategyRow({ level, strategy, onChange, showPityLimit, onOpenMaterials }) {
    // Grid columns: Level, Şans %, [Pity Limit], Maliyet, Priority 1-3, Materials
    const gridCols = showPityLimit
        ? 'grid-cols-[40px_1fr_1fr_1fr_1fr_1fr_1fr_40px]'
        : 'grid-cols-[40px_1fr_1fr_1fr_1fr_1fr_40px]';

    // Count assigned materials
    const materialCount = strategy.requiredMaterials?.length || 0;

    return (
        <div className={`grid ${gridCols} gap-2 items-center py-2 border-b border-zinc-800/50`}>
            {/* Level Label */}
            <div className="text-sm text-zinc-400 font-mono">
                +{level}
            </div>

            {/* Base Chance */}
            <div>
                <SmartInput
                    value={strategy.baseChance}
                    onChange={(val) => onChange(level, 'baseChance', val)}
                    min={1}
                    max={100}
                    className="w-full px-2 py-1 text-xs font-mono text-white bg-zinc-950 border border-zinc-700 rounded"
                />
            </div>

            {/* Pity Limit - Conditionally Rendered */}
            {showPityLimit && (
                <div>
                    <SmartInput
                        value={strategy.pityLimit !== undefined ? strategy.pityLimit : 10}
                        onChange={(val) => onChange(level, 'pityLimit', val)}
                        min={0}
                        max={100}
                        placeholder="Limit"
                        className="w-full px-2 py-1 text-xs font-mono text-orange-400 bg-zinc-950 border border-zinc-700 rounded border-orange-500/30"
                    />
                </div>
            )}

            {/* Upgrade Cost (Yang) */}
            <div>
                <SmartInput
                    value={strategy.upgradeCost !== undefined ? strategy.upgradeCost : 0}
                    onChange={(val) => onChange(level, 'upgradeCost', val)}
                    min={0}
                    className="w-full px-2 py-1 text-xs font-mono text-yellow-400 bg-zinc-950 border border-zinc-700 rounded border-yellow-500/30"
                    placeholder="0"
                />
            </div>

            {/* Priority 1 */}
            <select
                value={strategy.priorityList[0] || 'blessing_scroll'}
                onChange={(e) => {
                    const newList = [...strategy.priorityList];
                    newList[0] = e.target.value;
                    onChange(level, 'priorityList', newList);
                }}
                className="px-2 py-1 text-xs text-white bg-zinc-950 border border-zinc-700 rounded"
            >
                {MATERIAL_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
            </select>

            {/* Priority 2 */}
            <select
                value={strategy.priorityList[1] || ''}
                onChange={(e) => {
                    const newList = [...strategy.priorityList];
                    newList[1] = e.target.value;
                    onChange(level, 'priorityList', newList.filter(Boolean));
                }}
                className="px-2 py-1 text-xs text-white bg-zinc-950 border border-zinc-700 rounded"
            >
                <option value="">-</option>
                {MATERIAL_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
            </select>

            {/* Priority 3 */}
            <select
                value={strategy.priorityList[2] || ''}
                onChange={(e) => {
                    const newList = [...strategy.priorityList];
                    newList[2] = e.target.value;
                    onChange(level, 'priorityList', newList.filter(Boolean));
                }}
                className="px-2 py-1 text-xs text-white bg-zinc-950 border border-zinc-700 rounded"
            >
                <option value="">-</option>
                {MATERIAL_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
            </select>

            {/* Extra Materials Button */}
            <button
                onClick={() => onOpenMaterials(level)}
                className={`flex items-center justify-center p-1.5 rounded-lg border transition-all ${materialCount > 0
                    ? 'bg-blue-500/20 border-blue-500/50 text-blue-400 hover:bg-blue-500/30'
                    : 'bg-zinc-900 border-zinc-700 text-zinc-500 hover:text-zinc-300'
                    }`}
                title="Ekstra Materyaller"
            >
                <LinkIcon className="w-3.5 h-3.5" />
                {materialCount > 0 && (
                    <span className="ml-1 text-[10px] font-bold">{materialCount}</span>
                )}
            </button>
        </div>
    );
}

// ============================================================================
// MAIN COMPONENT: StrategyTable
// ============================================================================

export default function StrategyTable({
    levelRange,
    strategy,
    config,
    onStrategyChange,
    onOpenMaterials
}) {
    const showPityLimit = config.pitySystem === 'hard';
    const gridCols = showPityLimit
        ? 'grid-cols-[40px_1fr_1fr_1fr_1fr_1fr_1fr_40px]'
        : 'grid-cols-[40px_1fr_1fr_1fr_1fr_1fr_40px]';

    return (
        <div className="space-y-4">
            <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Strateji Tablosu
            </h3>

            <div className="bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden">
                {/* Table Header */}
                <div className={`grid ${gridCols} gap-2 px-3 py-2 bg-zinc-800/50 text-xs text-zinc-500 font-medium`}>
                    <div>Lvl</div>
                    <div>Şans %</div>
                    {showPityLimit && <div className="text-orange-400">Pity</div>}
                    <div className="text-yellow-400">Maliyet</div>
                    <div>Öncelik 1</div>
                    <div>Öncelik 2</div>
                    <div>Öncelik 3</div>
                    <div>Ek</div>
                </div>

                {/* Table Rows */}
                <div className="px-3 max-h-80 overflow-y-auto">
                    {levelRange.map(level => (
                        <StrategyRow
                            key={level}
                            level={level}
                            strategy={strategy[level] || DEFAULT_STRATEGY[level] || {
                                baseChance: 30,
                                pityLimit: 10,
                                priorityList: ['blessing_scroll'],
                                upgradeCost: 0
                            }}
                            onChange={onStrategyChange}
                            showPityLimit={showPityLimit}
                            onOpenMaterials={onOpenMaterials}
                        />
                    ))}
                </div>
            </div>

            {/* Strategy Tips */}
            <div className="bg-zinc-800/30 p-3 rounded-lg border border-zinc-700/50">
                <p className="text-xs text-zinc-500">
                    💡 Her seviye için kullanılacak materyallerin öncelik sırasını belirleyin.
                    İlk materyal bittiğinde otomatik olarak bir sonrakine geçilir.
                </p>
            </div>
        </div>
    );
}

// Export constants for use in other components
export { MATERIAL_OPTIONS, DEFAULT_STRATEGY };
