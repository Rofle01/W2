"use client";

import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { X, EyeOff, Coins, Plus, Trash2, Search, Filter, Download, Upload, FileSpreadsheet, FileJson, CheckCircle } from "lucide-react";
import * as LucideIcons from "lucide-react";
import useWidgetStore from "../../store/useWidgetStore";
import { exportToFile, parseImportFile } from "../../lib/excelUtils";

// Helper: Format currency
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('tr-TR', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
};

// Helper: Format compact number
const formatCompactNumber = (number) => {
    if (!number) return "0";
    return new Intl.NumberFormat('tr-TR', {
        notation: "compact",
        maximumFractionDigits: 1
    }).format(number);
};

// ============================================================================
// SUMMARY VIEW COMPONENT
// ============================================================================
function MarketSummaryView() {
    const marketItems = useWidgetStore((state) => state.marketItems);

    const stats = useMemo(() => {
        const totalItems = marketItems.length;
        const totalValue = marketItems.reduce((sum, item) => sum + item.price, 0);
        return { totalItems, totalValue };
    }, [marketItems]);

    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden">
            <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-white/10 backdrop-blur-sm rounded-lg border border-white/10">
                    <Coins className="w-8 h-8 text-amber-400" />
                </div>
            </div>
            <span className="text-3xl font-bold text-white whitespace-nowrap">
                {stats.totalItems} Eşya
            </span>
            <span className="text-sm text-white/60 mt-1">
                Toplam: {formatCompactNumber(stats.totalValue)} Yang
            </span>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW COMPONENT
// ============================================================================
function MarketDetailView() {
    const marketItems = useWidgetStore((state) => state.marketItems);
    const updateItemPrice = useWidgetStore((state) => state.updateItemPrice);
    const removeMarketItem = useWidgetStore((state) => state.removeMarketItem);
    const addMarketItem = useWidgetStore((state) => state.addMarketItem);
    const importMarketData = useWidgetStore((state) => state.importMarketData);

    const [selectedCategory, setSelectedCategory] = useState("Tümü");
    const [searchQuery, setSearchQuery] = useState("");
    const [showAddForm, setShowAddForm] = useState(false);
    const [showDataModal, setShowDataModal] = useState(false);
    const [dataModalTab, setDataModalTab] = useState("export"); // "export" or "import"
    const [successMessage, setSuccessMessage] = useState("");
    const [isDragging, setIsDragging] = useState(false);
    const [newItem, setNewItem] = useState({
        name: "",
        price: "",
        category: "genel",
        icon: "Circle"
    });

    // Get unique categories
    const categories = useMemo(() => {
        const cats = ["Tümü", ...new Set(marketItems.map(item => item.category))];
        return cats;
    }, [marketItems]);

    // Filter items
    const filteredItems = useMemo(() => {
        return marketItems.filter(item => {
            const matchesCategory = selectedCategory === "Tümü" || item.category === selectedCategory;
            const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [marketItems, selectedCategory, searchQuery]);

    // Calculate total value
    const totalValue = useMemo(() => {
        return filteredItems.reduce((sum, item) => sum + item.price, 0);
    }, [filteredItems]);

    // Handle price update
    const handlePriceUpdate = (id, newPrice) => {
        const price = parseFloat(newPrice);
        if (!isNaN(price) && price >= 0) {
            updateItemPrice(id, price);
        }
    };

    // Handle delete
    const handleDelete = (id) => {
        if (confirm("Bu eşyayı silmek istediğinizden emin misiniz?")) {
            removeMarketItem(id);
        }
    };

    // Handle add new item
    const handleAddItem = (e) => {
        e.preventDefault();
        if (newItem.name && newItem.price) {
            addMarketItem({
                name: newItem.name,
                price: parseFloat(newItem.price) || 0,
                category: newItem.category,
                icon: newItem.icon
            });
            setNewItem({ name: "", price: "", category: "genel", icon: "Circle" });
            setShowAddForm(false);
        }
    };

    // Handle export
    const handleExport = async (format) => {
        const result = await exportToFile(marketItems, `piyasa-verileri-${Date.now()}`, format);
        if (result.success) {
            setSuccessMessage(`${format.toUpperCase()} dosyası başarıyla indirildi!`);
            setTimeout(() => setSuccessMessage(""), 3000);
        }
    };

    // Handle import
    const handleImport = async (file) => {
        const result = await parseImportFile(file);
        if (result.success) {
            importMarketData(result.data);
            setSuccessMessage(result.message);
            setTimeout(() => setSuccessMessage(""), 3000);
            setShowDataModal(false);
        } else {
            alert(result.message);
        }
    };

    // Handle file input change
    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) handleImport(file);
    };

    // Handle drag and drop
    const handleDragOver = (e) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = () => {
        setIsDragging(false);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setIsDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file) handleImport(file);
    };

    const iconOptions = [
        "Circle", "Star", "Diamond", "Gem", "Crown", "Shield", "Sword",
        "Zap", "Heart", "Sparkles", "Award", "Package", "Gift"
    ];

    return (
        <div className="space-y-6 h-full flex flex-col">
            {/* Success Message */}
            {successMessage && (
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="bg-green-600/90 backdrop-blur-sm text-white px-4 py-3 rounded-lg flex items-center gap-2 border border-green-500/30"
                >
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">{successMessage}</span>
                </motion.div>
            )}

            {/* Header Stats */}
            <div className="bg-white/10 backdrop-blur-xl p-4 rounded-xl border border-white/20">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-white/70">Toplam Piyasa Değeri</p>
                        <p className="text-2xl font-bold text-amber-400">
                            {formatCurrency(totalValue)} Yang
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        <button
                            onClick={() => setShowDataModal(true)}
                            className="p-2 bg-blue-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-blue-600 transition-colors border border-blue-500/30"
                            title="Veri İşlemleri"
                        >
                            <Download className="w-5 h-5" />
                        </button>
                        <div className="text-right">
                            <p className="text-sm text-white/70">Gösterilen</p>
                            <p className="text-2xl font-bold text-white">
                                {filteredItems.length} / {marketItems.length}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Search and Filter */}
            <div className="space-y-3">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Eşya ara..."
                        className="w-full pl-10 pr-4 py-2 font-medium text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:bg-black/40 placeholder:text-white/40 backdrop-blur-sm"
                    />
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                    <Filter className="w-4 h-4 text-white/60" />
                    {categories.map((cat) => (
                        <button
                            key={cat}
                            onClick={() => setSelectedCategory(cat)}
                            className={`px-3 py-1 rounded-lg text-sm font-medium transition-all backdrop-blur-sm ${selectedCategory === cat
                                ? "bg-amber-500 text-white shadow-md"
                                : "bg-white/10 text-white/70 hover:bg-white/20 border border-white/10"
                                }`}
                        >
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </button>
                    ))}
                </div>

                <button
                    onClick={() => setShowAddForm(!showAddForm)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-green-600 transition-colors font-medium border border-green-500/30"
                >
                    <Plus className="w-5 h-5" />
                    Yeni Eşya Ekle
                </button>
            </div>

            {/* Add Form */}
            {showAddForm && (
                <motion.form
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    onSubmit={handleAddItem}
                    className="bg-white/10 backdrop-blur-xl p-4 rounded-xl border border-white/20 space-y-3"
                >
                    <h3 className="font-semibold text-white mb-2">Yeni Eşya Bilgileri</h3>
                    <div className="grid grid-cols-2 gap-3">
                        <input
                            type="text"
                            value={newItem.name}
                            onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                            className="px-3 py-2 font-medium text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:bg-black/40 placeholder:text-white/40"
                            placeholder="Eşya adı"
                            required
                        />
                        <input
                            type="number"
                            value={newItem.price}
                            onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
                            className="px-3 py-2 font-semibold text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:bg-black/40 placeholder:text-white/40"
                            placeholder="Fiyat"
                            required
                            min="0"
                        />
                        <input
                            type="text"
                            value={newItem.category}
                            onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                            className="px-3 py-2 font-medium text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:bg-black/40 placeholder:text-white/40"
                            placeholder="Kategori"
                        />
                        <select
                            value={newItem.icon}
                            onChange={(e) => setNewItem({ ...newItem, icon: e.target.value })}
                            className="px-3 py-2 font-medium text-white bg-black/30 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500/50"
                        >
                            {iconOptions.map((icon) => (
                                <option key={icon} value={icon} className="bg-zinc-900">{icon}</option>
                            ))}
                        </select>
                    </div>
                    <div className="flex gap-2">
                        <button
                            type="submit"
                            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                        >
                            Ekle
                        </button>
                        <button
                            type="button"
                            onClick={() => setShowAddForm(false)}
                            className="px-4 py-2 bg-white/10 text-white/80 rounded-lg hover:bg-white/20 transition-colors text-sm font-medium border border-white/10"
                        >
                            İptal
                        </button>
                    </div>
                </motion.form>
            )}

            {/* Data Import/Export Modal */}
            {showDataModal && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
                    {/* Backdrop */}
                    <div
                        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        onClick={() => setShowDataModal(false)}
                    />

                    {/* Modal */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="relative bg-black/40 backdrop-blur-xl border border-white/20 rounded-2xl p-6 max-w-md w-full shadow-2xl"
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-xl font-bold text-white">Veri İşlemleri</h3>
                            <button
                                onClick={() => setShowDataModal(false)}
                                className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                            >
                                <X className="w-5 h-5 text-white/70" />
                            </button>
                        </div>

                        {/* Tabs */}
                        <div className="flex gap-2 mb-4">
                            <button
                                onClick={() => setDataModalTab("export")}
                                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-all ${dataModalTab === "export"
                                        ? "bg-blue-600 text-white"
                                        : "bg-white/10 text-white/70 hover:bg-white/20"
                                    }`}
                            >
                                <Download className="w-4 h-4 inline mr-2" />
                                İndir
                            </button>
                            <button
                                onClick={() => setDataModalTab("import")}
                                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-all ${dataModalTab === "import"
                                        ? "bg-blue-600 text-white"
                                        : "bg-white/10 text-white/70 hover:bg-white/20"
                                    }`}
                            >
                                <Upload className="w-4 h-4 inline mr-2" />
                                Yükle
                            </button>
                        </div>

                        {/* Export Tab */}
                        {dataModalTab === "export" && (
                            <div className="space-y-3">
                                <p className="text-sm text-white/70 mb-3">
                                    Piyasa verilerinizi Excel veya JSON formatında indirin.
                                </p>
                                <button
                                    onClick={() => handleExport("excel")}
                                    className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-green-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-green-600 transition-colors font-medium border border-green-500/30"
                                >
                                    <FileSpreadsheet className="w-5 h-5" />
                                    Excel (.xlsx) İndir
                                </button>
                                <button
                                    onClick={() => handleExport("json")}
                                    className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-purple-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-purple-600 transition-colors font-medium border border-purple-500/30"
                                >
                                    <FileJson className="w-5 h-5" />
                                    JSON İndir
                                </button>
                            </div>
                        )}

                        {/* Import Tab */}
                        {dataModalTab === "import" && (
                            <div className="space-y-3">
                                <p className="text-sm text-white/70 mb-3">
                                    Excel (.xlsx) veya JSON dosyası yükleyin.
                                </p>
                                <div
                                    onDragOver={handleDragOver}
                                    onDragLeave={handleDragLeave}
                                    onDrop={handleDrop}
                                    className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${isDragging
                                            ? "border-blue-500 bg-blue-500/10"
                                            : "border-white/20 bg-white/5 hover:bg-white/10"
                                        }`}
                                >
                                    <Upload className="w-12 h-12 text-white/50 mx-auto mb-3" />
                                    <p className="text-white/70 mb-2">Dosyayı buraya sürükleyin</p>
                                    <p className="text-white/50 text-sm mb-4">veya</p>
                                    <label className="inline-block px-4 py-2 bg-blue-600/80 backdrop-blur-sm text-white rounded-lg hover:bg-blue-600 transition-colors cursor-pointer font-medium border border-blue-500/30">
                                        Dosya Seç
                                        <input
                                            type="file"
                                            accept=".xlsx,.xls,.json,.csv"
                                            onChange={handleFileChange}
                                            className="hidden"
                                        />
                                    </label>
                                    <p className="text-white/40 text-xs mt-3">
                                        Desteklenen formatlar: .xlsx, .xls, .json, .csv
                                    </p>
                                </div>
                            </div>
                        )}
                    </motion.div>
                </div>
            )}

            {/* Items Table */}
            <div className="flex-1 overflow-auto rounded-xl border border-white/10 backdrop-blur-sm">
                <table className="w-full">
                    <thead className="bg-white/10 sticky top-0 backdrop-blur-xl">
                        <tr>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-white/80 uppercase">İkon</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-white/80 uppercase">Eşya Adı</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-white/80 uppercase">Kategori</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-white/80 uppercase">Fiyat</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-white/80 uppercase">İşlem</th>
                        </tr>
                    </thead>
                    <tbody className="bg-black/20 divide-y divide-white/10">
                        {filteredItems.length === 0 ? (
                            <tr>
                                <td colSpan="5" className="px-4 py-8 text-center text-white/60">
                                    Eşya bulunamadı
                                </td>
                            </tr>
                        ) : (
                            filteredItems.map((item) => {
                                const ItemIcon = LucideIcons[item.icon] || LucideIcons.Circle;
                                return (
                                    <tr key={item.id} className="hover:bg-white/10 transition-colors group">
                                        <td className="px-4 py-3">
                                            <div className="p-2 bg-white/5 rounded-lg w-fit group-hover:bg-amber-500/20 transition-colors border border-white/10">
                                                <ItemIcon className="w-5 h-5 text-white/70 group-hover:text-amber-400" />
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <p className="text-sm font-medium text-white">{item.name}</p>
                                            {item.originalId && (
                                                <p className="text-xs text-white/50">ID: {item.originalId}</p>
                                            )}
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className="px-2 py-1 bg-white/10 text-white/80 rounded text-xs font-medium border border-white/10">
                                                {item.category}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <input
                                                type="number"
                                                value={item.price}
                                                onChange={(e) => handlePriceUpdate(item.id, e.target.value)}
                                                className="w-32 px-2 py-1 text-sm font-semibold text-white bg-black/30 border border-white/10 rounded focus:outline-none focus:ring-2 focus:ring-amber-500/50 placeholder:text-white/40"
                                                min="0"
                                            />
                                        </td>
                                        <td className="px-4 py-3">
                                            {!item.isSystemItem ? (
                                                <button
                                                    onClick={() => handleDelete(item.id)}
                                                    className="p-2 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors border border-transparent hover:border-red-500/30"
                                                    title="Sil"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            ) : (
                                                <span className="text-xs text-white/50 px-2">Sistem</span>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>

            {/* Footer */}
            <div className="bg-white/5 backdrop-blur-sm p-3 rounded-lg border border-white/10 flex items-center justify-between text-sm">
                <span className="text-white/70">
                    Toplam <strong className="text-white">{filteredItems.length}</strong> eşya gösteriliyor
                </span>
                <span className="text-white/70">
                    Değer: <strong className="text-amber-400">{formatCurrency(totalValue)}</strong> Yang
                </span>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN WIDGET
// ============================================================================
export default function MarketWidget({ id, isSelected, onClick, onHide }) {
    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group rounded-3xl shadow-2xl cursor-pointer overflow-hidden backdrop-blur-xl border border-white/10 ${isSelected
                ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-6xl z-[100] bg-black/80"
                : "relative h-64 hover:-translate-y-1 hover:border-amber-400/50 transition-all duration-300 bg-white/5 hover:bg-white/10"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {/* Hide Button */}
            <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => {
                    e.stopPropagation();
                    onHide && onHide();
                }}
                className="absolute top-4 right-4 z-20 p-2 bg-white/10 backdrop-blur-sm shadow-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-white/60 hover:text-red-400 hover:bg-red-500/20 border border-white/20"
            >
                <EyeOff className="w-4 h-4" />
            </motion.button>

            {/* Summary View */}
            {!isSelected && (
                <div className="w-full h-full p-6 relative">
                    <Coins className="absolute -bottom-4 -right-4 w-32 h-32 text-white/5 opacity-50 rotate-12 pointer-events-none" />
                    <MarketSummaryView />
                </div>
            )}

            {/* Detail View */}
            {isSelected && (
                <div className="flex flex-col h-full bg-black/20">
                    <div className="flex items-center justify-between p-8 border-b border-white/20 bg-white/5 backdrop-blur-xl">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                                <Coins className="w-8 h-8 text-amber-400" />
                            </div>
                            <div>
                                <motion.h2 layoutId={`title-${id}`} className="text-2xl font-bold text-white">
                                    Piyasa Fiyatları
                                </motion.h2>
                                <p className="text-white/60">Eşya fiyatlarını görüntüle ve yönet</p>
                            </div>
                        </div>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-white/10 rounded-full transition-colors backdrop-blur-sm border border-white/10 hover:border-white/20"
                        >
                            <X className="w-6 h-6 text-white/80" />
                        </button>
                    </div>
                    <div className="flex-1 p-8 overflow-hidden">
                        <MarketDetailView />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
