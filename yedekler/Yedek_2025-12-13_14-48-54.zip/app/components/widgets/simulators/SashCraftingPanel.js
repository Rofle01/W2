"use client";

import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import {
    Calculator,
    Loader2,
    TrendingUp,
    History,
    RotateCcw,
    Trash2,
    ChevronDown,
    Sparkles,
    Coins,
    Target,
    BarChart3,
    Layers,
    Settings,
    Percent
} from "lucide-react";
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    Area,
    AreaChart
} from "recharts";

import { usePersistentState } from "../../../hooks/usePersistentState";
import { useWorker } from "../../../hooks/useWorker";
import SmartInput from "../../ui/SmartInput";

// ============================================================================
// CONSTANTS
// ============================================================================

const TARGET_GRADES = [
    { value: 18, label: "%18 Emiş" },
    { value: 20, label: "%20 Emiş" },
    { value: 25, label: "%25 Emiş" },
    { value: 30, label: "%30 Emiş" }
];

const DEFAULT_CONFIG = {
    clothPrice: 1000000,
    clothCount: 40,
    targetGrade: 25,
    simCount: 5000,
    rates: {
        grade1: 90,   // 1 -> 5 geçme şansı
        grade2: 80,   // 5 -> 10 geçme şansı
        grade3: 70,   // 10 -> Hakim geçme şansı
        upgrade: 50   // Hakim emiş arttırma şansı
    }
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const formatCurrency = (value) => {
    if (value === undefined || value === null || isNaN(value)) return "0";
    if (value >= 1000000000) return `${(value / 1000000000).toFixed(2)}B`;
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return Math.round(value).toLocaleString("tr-TR");
};

const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleString("tr-TR", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    });
};

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

// Result Card
function ResultCard({ title, value, subtitle, icon: Icon, color = "violet" }) {
    const colorClasses = {
        violet: "from-violet-500/20 to-violet-500/5 border-violet-500/30 text-violet-400",
        green: "from-green-500/20 to-green-500/5 border-green-500/30 text-green-400",
        red: "from-red-500/20 to-red-500/5 border-red-500/30 text-red-400",
        blue: "from-blue-500/20 to-blue-500/5 border-blue-500/30 text-blue-400"
    };

    return (
        <div className={`
            bg-gradient-to-br ${colorClasses[color]} 
            rounded-xl border p-4
        `}>
            <div className="flex items-center gap-2 mb-2">
                {Icon && <Icon className="w-4 h-4" />}
                <span className="text-xs font-medium text-zinc-400">{title}</span>
            </div>
            <p className="text-2xl font-bold text-white font-mono">{value}</p>
            {subtitle && (
                <p className="text-xs text-zinc-500 mt-1">{subtitle}</p>
            )}
        </div>
    );
}

// History Item
function HistoryItem({ item, onRestore, onDelete }) {
    return (
        <div className="flex items-center gap-3 p-3 bg-zinc-900/50 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-colors group">
            <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-semibold text-white">
                        {formatCurrency(item.result.avgCost)}
                    </span>
                    <span className="text-xs text-zinc-500">Won</span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-zinc-500">{formatDate(item.date)}</span>
                    <span className="text-xs text-zinc-600">•</span>
                    <span className="text-xs text-zinc-500">%{item.config.targetGrade}</span>
                </div>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                    onClick={() => onRestore(item)}
                    className="p-1.5 rounded-md bg-violet-500/10 text-violet-400 hover:bg-violet-500/20 transition-colors"
                    title="Geri Yükle"
                >
                    <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                    onClick={() => onDelete(item.id)}
                    className="p-1.5 rounded-md bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors"
                    title="Sil"
                >
                    <Trash2 className="w-3.5 h-3.5" />
                </button>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function SashCraftingPanel() {
    // Persistent State
    const [config, setConfig] = usePersistentState("sash-simulator-config", DEFAULT_CONFIG);
    const [history, setHistory] = usePersistentState("sash-simulator-history", []);

    // Worker Hook
    const { run, status, result, progress, isRunning } = useWorker("/workers/sash.worker.js");

    // Local State
    const [showHistory, setShowHistory] = useState(true);

    // Ref to track last processed result (prevents duplicate entries in StrictMode)
    const lastResultRef = useRef(null);

    // Chart Data (history'den oluştur)
    const chartData = useMemo(() => {
        return history.map((item, index) => ({
            name: `#${index + 1}`,
            cost: item.result.avgCost,
            min: item.result.minCost,
            max: item.result.maxCost
        })).slice(-20); // Son 20 kayıt
    }, [history]);

    // Handlers
    const handleConfigChange = useCallback((field, value) => {
        setConfig(prev => ({ ...prev, [field]: value }));
    }, [setConfig]);

    // Rate değişikliği handlerı (nested object için)
    const handleRateChange = useCallback((rateKey, value) => {
        setConfig(prev => ({
            ...prev,
            rates: {
                ...prev.rates,
                [rateKey]: value
            }
        }));
    }, [setConfig]);

    const handleSimulate = useCallback(() => {
        run({
            action: "run_simulation",
            clothPrice: config.clothPrice,
            clothCount: config.clothCount,
            targetGrade: config.targetGrade,
            simCount: config.simCount,
            rates: config.rates
        });
    }, [run, config]);

    // Effect: Sonuç geldiğinde history'e ekle (with deduplication)
    useEffect(() => {
        if (status === "complete" && result && result.duration) {
            // Use duration as a unique identifier for this result
            const resultKey = `${result.avgCost}-${result.duration}`;

            if (lastResultRef.current !== resultKey) {
                lastResultRef.current = resultKey;

                const newEntry = {
                    id: Date.now(),
                    date: Date.now(),
                    config: { ...config },
                    result: { ...result }
                };
                setHistory(prev => [newEntry, ...prev].slice(0, 50)); // Max 50 kayıt
            }
        }
    }, [status, result, config, setHistory]);

    const handleRestore = useCallback((item) => {
        setConfig(item.config);
    }, [setConfig]);

    const handleDeleteHistory = useCallback((id) => {
        setHistory(prev => prev.filter(item => item.id !== id));
    }, [setHistory]);

    const handleClearHistory = useCallback(() => {
        setHistory([]);
    }, [setHistory]);

    return (
        <div className="h-full flex flex-col overflow-hidden">
            {/* Header */}
            <header className="px-6 py-4 border-b border-zinc-800 bg-zinc-900/30 shrink-0">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-violet-500/10 rounded-lg border border-violet-500/20">
                            <Sparkles className="w-5 h-5 text-violet-400" />
                        </div>
                        <div>
                            <h1 className="text-lg font-semibold text-white">
                                Kuşak Maliyet Simülasyonu
                            </h1>
                            <p className="text-xs text-zinc-500">
                                Monte Carlo yöntemiyle ortalama maliyet hesaplama
                            </p>
                        </div>
                    </div>
                    <button
                        onClick={() => setShowHistory(!showHistory)}
                        className={`
                            flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors
                            ${showHistory
                                ? "bg-violet-500/20 text-violet-400 border border-violet-500/30"
                                : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:bg-zinc-700"
                            }
                        `}
                    >
                        <History className="w-4 h-4" />
                        Geçmiş
                    </button>
                </div>
            </header>

            {/* Main Content */}
            <div className="flex-1 overflow-auto p-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Left Column - Inputs */}
                    <div className="space-y-4">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Parametreler
                        </h3>

                        {/* Kumaş Fiyatı */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Kumaş Fiyatı (Won)
                            </label>
                            <div className="flex items-center gap-2">
                                <Coins className="w-4 h-4 text-yellow-500" />
                                <SmartInput
                                    value={config.clothPrice}
                                    onChange={(val) => handleConfigChange("clothPrice", val)}
                                    min={0}
                                    step={100000}
                                    className="flex-1 px-3 py-2 text-lg font-mono font-semibold text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500/30 focus:border-violet-500/50"
                                    placeholder="1000000"
                                />
                            </div>
                            <p className="text-xs text-zinc-600 mt-2">
                                Formatlı: {formatCurrency(config.clothPrice)} Won
                            </p>
                        </div>

                        {/* Gereken Kumaş Adedi */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Gereken Kumaş (Adet)
                            </label>
                            <div className="flex items-center gap-2">
                                <Layers className="w-4 h-4 text-orange-500" />
                                <SmartInput
                                    value={config.clothCount}
                                    onChange={(val) => handleConfigChange("clothCount", val)}
                                    min={1}
                                    max={100}
                                    step={1}
                                    className="flex-1 px-3 py-2 text-lg font-mono font-semibold text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500/50"
                                    placeholder="40"
                                />
                            </div>
                            <p className="text-xs text-zinc-600 mt-2">
                                1 adet %1 kuşak için kaç kumaş lazım? (PvP: 1, Normal: 40)
                            </p>
                        </div>

                        {/* Hedef Emiş */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Hedef Emiş Oranı
                            </label>
                            <div className="relative">
                                <select
                                    value={config.targetGrade}
                                    onChange={(e) => handleConfigChange("targetGrade", parseInt(e.target.value))}
                                    className="w-full px-3 py-2.5 text-white bg-zinc-950 border border-zinc-700 rounded-lg appearance-none focus:outline-none focus:ring-2 focus:ring-violet-500/30 focus:border-violet-500/50 cursor-pointer"
                                >
                                    {TARGET_GRADES.map(grade => (
                                        <option key={grade.value} value={grade.value}>
                                            {grade.label}
                                        </option>
                                    ))}
                                </select>
                                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 pointer-events-none" />
                            </div>
                        </div>

                        {/* Simülasyon Sayısı */}
                        <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Simülasyon Sayısı: <span className="text-white font-mono">{config.simCount.toLocaleString()}</span>
                            </label>
                            <input
                                type="range"
                                min={1000}
                                max={50000}
                                step={1000}
                                value={config.simCount}
                                onChange={(e) => handleConfigChange("simCount", parseInt(e.target.value))}
                                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-violet-500"
                            />
                            <div className="flex justify-between text-xs text-zinc-600 mt-1">
                                <span>1K</span>
                                <span>25K</span>
                                <span>50K</span>
                            </div>
                        </div>

                        {/* Gelişmiş Ayarlar - Accordion */}
                        <details className="bg-zinc-900/50 rounded-xl border border-zinc-800 group">
                            <summary className="p-4 cursor-pointer list-none flex items-center justify-between hover:bg-zinc-800/30 transition-colors rounded-xl">
                                <div className="flex items-center gap-2">
                                    <Settings className="w-4 h-4 text-zinc-500" />
                                    <span className="text-xs font-medium text-zinc-400">Şans Oranları (%)</span>
                                </div>
                                <ChevronDown className="w-4 h-4 text-zinc-500 transition-transform group-open:rotate-180" />
                            </summary>
                            <div className="p-4 pt-0 space-y-3">
                                {/* 1 -> 5 Oranı */}
                                <div className="flex items-center gap-3">
                                    <div className="flex-1">
                                        <label className="block text-xs text-zinc-500 mb-1">1 ➝ 5</label>
                                        <SmartInput
                                            value={config.rates?.grade1 ?? 90}
                                            onChange={(val) => handleRateChange("grade1", val)}
                                            min={1}
                                            max={100}
                                            step={1}
                                            className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-violet-500/30"
                                        />
                                    </div>
                                    <Percent className="w-4 h-4 text-zinc-600" />
                                </div>
                                {/* 5 -> 10 Oranı */}
                                <div className="flex items-center gap-3">
                                    <div className="flex-1">
                                        <label className="block text-xs text-zinc-500 mb-1">5 ➝ 10</label>
                                        <SmartInput
                                            value={config.rates?.grade2 ?? 80}
                                            onChange={(val) => handleRateChange("grade2", val)}
                                            min={1}
                                            max={100}
                                            step={1}
                                            className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-violet-500/30"
                                        />
                                    </div>
                                    <Percent className="w-4 h-4 text-zinc-600" />
                                </div>
                                {/* 10 -> Hakim Oranı */}
                                <div className="flex items-center gap-3">
                                    <div className="flex-1">
                                        <label className="block text-xs text-zinc-500 mb-1">10 ➝ Hakim</label>
                                        <SmartInput
                                            value={config.rates?.grade3 ?? 70}
                                            onChange={(val) => handleRateChange("grade3", val)}
                                            min={1}
                                            max={100}
                                            step={1}
                                            className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-violet-500/30"
                                        />
                                    </div>
                                    <Percent className="w-4 h-4 text-zinc-600" />
                                </div>
                                {/* Upgrade Oranı */}
                                <div className="flex items-center gap-3">
                                    <div className="flex-1">
                                        <label className="block text-xs text-zinc-500 mb-1">Emiş Upgrade</label>
                                        <SmartInput
                                            value={config.rates?.upgrade ?? 50}
                                            onChange={(val) => handleRateChange("upgrade", val)}
                                            min={1}
                                            max={100}
                                            step={1}
                                            className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-violet-500/30"
                                        />
                                    </div>
                                    <Percent className="w-4 h-4 text-zinc-600" />
                                </div>
                            </div>
                        </details>

                        {/* Hesapla Button */}
                        <button
                            onClick={handleSimulate}
                            disabled={isRunning}
                            className={`
                                w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all duration-200
                                ${isRunning
                                    ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                                    : "bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white shadow-lg shadow-violet-900/30"
                                }
                            `}
                        >
                            {isRunning ? (
                                <>
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                    Hesaplanıyor... {progress}%
                                </>
                            ) : (
                                <>
                                    <Calculator className="w-5 h-5" />
                                    Simülasyonu Başlat
                                </>
                            )}
                        </button>

                        {/* Progress Bar */}
                        {isRunning && (
                            <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-gradient-to-r from-violet-500 to-purple-500 transition-all duration-300"
                                    style={{ width: `${progress}%` }}
                                />
                            </div>
                        )}
                    </div>

                    {/* Right Column - Results */}
                    <div className="lg:col-span-2 space-y-4">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                            <BarChart3 className="w-4 h-4" />
                            Sonuçlar
                        </h3>

                        {/* Result Cards */}
                        {result ? (
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <ResultCard
                                    title="Ortalama Maliyet"
                                    value={formatCurrency(result.avgCost)}
                                    subtitle="Won"
                                    icon={TrendingUp}
                                    color="violet"
                                />
                                <ResultCard
                                    title="Minimum"
                                    value={formatCurrency(result.minCost)}
                                    subtitle="En iyi senaryo"
                                    icon={TrendingUp}
                                    color="green"
                                />
                                <ResultCard
                                    title="Maksimum"
                                    value={formatCurrency(result.maxCost)}
                                    subtitle="En kötü senaryo"
                                    icon={TrendingUp}
                                    color="red"
                                />
                                <ResultCard
                                    title="Ort. Kumaş"
                                    value={result.totalClothUsed?.toLocaleString() || "0"}
                                    subtitle="Adet kullanım"
                                    icon={Sparkles}
                                    color="blue"
                                />
                            </div>
                        ) : (
                            <div className="bg-zinc-900/30 rounded-xl border border-zinc-800 p-8 text-center">
                                <Calculator className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
                                <p className="text-zinc-500">
                                    Simülasyonu başlatmak için parametreleri ayarlayın ve
                                    <br />
                                    <span className="text-violet-400">"Simülasyonu Başlat"</span> butonuna tıklayın.
                                </p>
                            </div>
                        )}

                        {/* Chart + History Section */}
                        {showHistory && history.length > 0 && (
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-6">
                                {/* Chart */}
                                <div className="bg-zinc-900/50 rounded-xl border border-zinc-800 p-4">
                                    <h4 className="text-sm font-semibold text-zinc-400 mb-4">
                                        Maliyet Trendi
                                    </h4>
                                    <div className="h-48">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <AreaChart data={chartData}>
                                                <defs>
                                                    <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                                                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                                                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                                                    </linearGradient>
                                                </defs>
                                                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                                                <XAxis
                                                    dataKey="name"
                                                    tick={{ fill: '#71717a', fontSize: 10 }}
                                                    axisLine={{ stroke: '#3f3f46' }}
                                                />
                                                <YAxis
                                                    tick={{ fill: '#71717a', fontSize: 10 }}
                                                    axisLine={{ stroke: '#3f3f46' }}
                                                    tickFormatter={formatCurrency}
                                                />
                                                <Tooltip
                                                    contentStyle={{
                                                        backgroundColor: '#18181b',
                                                        border: '1px solid #3f3f46',
                                                        borderRadius: '8px',
                                                        fontSize: '12px'
                                                    }}
                                                    formatter={(value) => [formatCurrency(value) + " Won", "Maliyet"]}
                                                />
                                                <Area
                                                    type="monotone"
                                                    dataKey="cost"
                                                    stroke="#8b5cf6"
                                                    strokeWidth={2}
                                                    fillOpacity={1}
                                                    fill="url(#colorCost)"
                                                />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>

                                {/* History List */}
                                <div className="bg-zinc-900/50 rounded-xl border border-zinc-800 p-4 flex flex-col">
                                    <div className="flex items-center justify-between mb-3">
                                        <h4 className="text-sm font-semibold text-zinc-400">
                                            Geçmiş ({history.length})
                                        </h4>
                                        {history.length > 0 && (
                                            <button
                                                onClick={handleClearHistory}
                                                className="text-xs text-red-400 hover:text-red-300 transition-colors"
                                            >
                                                Tümünü Sil
                                            </button>
                                        )}
                                    </div>
                                    <div className="flex-1 overflow-y-auto space-y-2 max-h-48 custom-scrollbar">
                                        {history.slice(0, 10).map(item => (
                                            <HistoryItem
                                                key={item.id}
                                                item={item}
                                                onRestore={handleRestore}
                                                onDelete={handleDeleteHistory}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Empty History State */}
                        {showHistory && history.length === 0 && (
                            <div className="bg-zinc-900/30 rounded-xl border border-zinc-800 p-6 text-center mt-4">
                                <History className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
                                <p className="text-sm text-zinc-500">
                                    Henüz simülasyon geçmişi yok.
                                </p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
