"use client";

import { useState, useRef, useEffect } from "react";
import { motion, useDragControls } from "framer-motion";
import { X, Minus, Square, Maximize2, Minimize2 } from "lucide-react";
import useWidgetStore from "../store/useWidgetStore";

// Resize positions
const RESIZE_HANDLES = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

export default function WindowFrame({ id, title, children, layout }) {
    const { x, y, w, h, zIndex, isMinimized, isMaximized } = layout;

    const updateWidgetLayout = useWidgetStore((state) => state.updateWidgetLayout);
    const bringToFront = useWidgetStore((state) => state.bringToFront);
    const toggleMinimize = useWidgetStore((state) => state.toggleMinimize);
    const toggleMaximize = useWidgetStore((state) => state.toggleMaximize);
    const closeWidget = useWidgetStore((state) => state.closeWidget);

    const dragControls = useDragControls();
    const containerRef = useRef(null);
    const [isResizing, setIsResizing] = useState(false);

    // Bring to front on interaction immediately
    const handleFocus = (e) => {
        // We only bring to front; strict separation
        bringToFront(id);
    };

    // Drag End Payload
    const handleDragEnd = (event, info) => {
        if (!isMaximized) {
            updateWidgetLayout(id, {
                x: x + info.offset.x,
                y: y + info.offset.y
            });
        }
    };

    // Resize Logic (Manually managed for performance & reliability)
    const handleResizeStart = (e, direction) => {
        e.preventDefault();
        e.stopPropagation();
        setIsResizing(true);
        bringToFront(id);

        const startX = e.clientX;
        const startY = e.clientY;
        const startW = w;
        const startH = h;
        const startPosX = x;
        const startPosY = y;

        const onMouseMove = (moveEvent) => {
            const deltaX = moveEvent.clientX - startX;
            const deltaY = moveEvent.clientY - startY;

            let newW = startW;
            let newH = startH;
            let newX = startPosX;
            let newY = startPosY;

            if (direction.includes("e")) newW = startW + deltaX;
            if (direction.includes("w")) {
                newW = startW - deltaX;
                newX = startPosX + deltaX;
            }
            if (direction.includes("s")) newH = startH + deltaY;
            if (direction.includes("n")) {
                newH = startH - deltaY;
                newY = startPosY + deltaY;
            }

            // Constraints
            if (newW < 320) {
                newW = 320;
                if (direction.includes("w")) newX = startPosX + (startW - 320);
            }
            if (newH < 240) {
                newH = 240;
                if (direction.includes("n")) newY = startPosY + (startH - 240);
            }

            updateWidgetLayout(id, { x: newX, y: newY, w: newW, h: newH });
        };

        const onMouseUp = () => {
            setIsResizing(false);
            document.removeEventListener("mousemove", onMouseMove);
            document.removeEventListener("mouseup", onMouseUp);
        };

        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
    };

    if (isMinimized) return null;

    return (
        <motion.div
            ref={containerRef}
            initial={false}
            // Drag Logic
            drag={!isMaximized}
            dragControls={dragControls}
            dragListener={false} // Crucial: Only drag via controls
            dragMomentum={false} // Disable momentum for precise OS feel
            dragElastic={0}      // No elastic bounce
            onDragEnd={handleDragEnd}
            onPointerDown={handleFocus} // Catch clicks to bring front

            // Layout props
            style={{
                position: "absolute",
                x: isMaximized ? 0 : x,
                y: isMaximized ? 0 : y,
                width: isMaximized ? "100vw" : w,
                height: isMaximized ? "100vh" : h,
                zIndex: zIndex,
            }}

            // CSS Styling
            className={`
        flex flex-col 
        bg-black/80 backdrop-blur-xl border border-white/10 shadow-2xl
        transition-shadow duration-200
        ${isMaximized ? "fixed top-0 left-0 rounded-none border-0" : "rounded-xl"}
        ${isResizing ? "select-none" : ""} 
      `}
        >

            {/* 1. HEADER BAR (Draggable Area) */}
            <div
                className="
          h-10 shrink-0 flex items-center justify-between px-4 
          bg-white/5 border-b border-white/10 
          cursor-default select-none
        "
                onPointerDown={(e) => {
                    // Start drag manually ONLY here
                    if (!isMaximized) dragControls.start(e);
                    handleFocus(e);
                }}
                onDoubleClick={(e) => {
                    e.stopPropagation();
                    toggleMaximize(id);
                }}
            >
                {/* Title & Icon Area */}
                <div className="flex items-center gap-3 overflow-hidden">
                    {/* Window Controls - Stop Propagation is Key */}
                    <div className="flex gap-1.5 z-50">
                        <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onClick={(e) => { e.stopPropagation(); closeWidget(id); }}
                            className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-400 flex items-center justify-center group"
                        >
                            <X className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100" />
                        </button>
                        <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onClick={(e) => { e.stopPropagation(); toggleMinimize(id); }}
                            className="w-3 h-3 rounded-full bg-yellow-500 hover:bg-yellow-400 flex items-center justify-center group"
                        >
                            <Minus className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100" />
                        </button>
                        <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onClick={(e) => { e.stopPropagation(); toggleMaximize(id); }}
                            className="w-3 h-3 rounded-full bg-green-500 hover:bg-green-400 flex items-center justify-center group"
                        >
                            {isMaximized ?
                                <Minimize2 className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100" /> :
                                <Maximize2 className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100" />
                            }
                        </button>
                    </div>

                    <span className="text-xs font-mono font-medium text-white/50 tracking-wider truncate pointer-events-none">
                        {title.toUpperCase()}
                    </span>
                </div>

                {/* Decoration / Status */}
                <div className="flex gap-1 opacity-20 pointer-events-none">
                    <div className="w-1 h-1 rounded-full bg-cyan-500" />
                    <div className="w-1 h-1 rounded-full bg-purple-500" />
                </div>
            </div>

            {/* 2. CONTENT AREA (Scrollable) */}
            <div
                className="flex-1 overflow-auto relative custom-scrollbar flex flex-col"
                onPointerDown={(e) => {
                    // Allow clicking content to bring to front, but prevent drag
                    e.stopPropagation();
                    handleFocus(e);
                }}
            >
                {/* Render Widget */}
                <div className="min-h-full">
                    {children}
                </div>
            </div>

            {/* 3. RESIZE HANDLES (Overlay) */}
            {!isMaximized && RESIZE_HANDLES.map((handle) => (
                <div
                    key={handle}
                    onPointerDown={(e) => handleResizeStart(e, handle)}
                    className={`
                absolute z-50
                ${handle === "n" ? "top-0 left-0 right-0 h-1 cursor-ns-resize" : ""}
                ${handle === "s" ? "bottom-0 left-0 right-0 h-1 cursor-ns-resize" : ""}
                ${handle === "e" ? "top-0 right-0 bottom-0 w-1 cursor-ew-resize" : ""}
                ${handle === "w" ? "top-0 left-0 bottom-0 w-1 cursor-ew-resize" : ""}
                ${handle === "ne" ? "top-0 right-0 w-4 h-4 cursor-nesw-resize z-[60]" : ""}
                ${handle === "nw" ? "top-0 left-0 w-4 h-4 cursor-nwse-resize z-[60]" : ""}
                ${handle === "se" ? "bottom-0 right-0 w-4 h-4 cursor-nwse-resize z-[60]" : ""}
                ${handle === "sw" ? "bottom-0 left-0 w-4 h-4 cursor-nesw-resize z-[60]" : ""}
            `}
                />
            ))}
        </motion.div>
    );
}
