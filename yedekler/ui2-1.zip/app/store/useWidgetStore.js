"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";

// ============================================================================
// A. Widget Registry (Sabit Katalog)
// ============================================================================
const WIDGET_REGISTRY = {
  "money-input": {
    title: "Miktar Girin",
    icon: "TrendingUp",
    defaultData: { amount: "" },
  },
  "note-taker": {
    title: "Not Alın",
    icon: "Wallet",
    defaultData: { notes: "" },
  },
  "percentage-calc": {
    title: "Yüzde Hesapla",
    icon: "PieChart",
    defaultData: { percentage: "" },
  },
  "value-tracker": {
    title: "Değer Takip",
    icon: "BarChart3",
    defaultData: { value: "" },
  },
  "currency-converter": {
    title: "Para Birimi",
    icon: "DollarSign",
    defaultData: { currency: "" },
  },
  "metric-monitor": {
    title: "Metrik İzleyici",
    icon: "Activity",
    defaultData: { metric: "" },
  },
  "market-prices": {
    title: "Piyasa Fiyatları",
    icon: "Coins",
    defaultData: {},
    description: "Eşya fiyatlarını görüntüle ve düzenle"
  },
  "character-stats": {
    title: "Karakterim",
    icon: "Sword",
    defaultData: {},
    description: "Karakter istatistiklerini yönet"
  },
  "analysis-tool": {
    title: "Analiz & Simülasyon",
    icon: "Calculator",
    defaultData: {},
    description: "Karlılık analizi ve farming stratejisi"
  },
  "metin-settings": {
    title: "Metin Ayarları",
    icon: "Settings",
    defaultData: {},
    description: "Metin HP ve drop ayarlarını düzenle"
  },
};

// ============================================================================
// LEGACY DATA TRANSFORMATION
// ============================================================================

/**
 * Eski sistemdeki item verilerini modern şemaya dönüştürür
 * @param {Array} legacyItems - Eski format item listesi
 * @returns {Array} Modern şemaya dönüştürülmüş item listesi
 */
const transformLegacyItems = (legacyItems) => {
  return legacyItems.map((item) => ({
    id: crypto.randomUUID(), // Yeni benzersiz ID
    originalId: item.id, // Eski ID'yi referans olarak sakla
    name: item.name,
    price: item.price,
    category: "genel", // Varsayılan kategori
    isSystemItem: true, // Sistem verisi, silinemez
    icon: "Circle", // Varsayılan ikon
  }));
};

/**
 * Eski sistemdeki metin verilerini modern şemaya dönüştürür
 * @param {Array} legacyMetins - Eski format metin listesi
 * @returns {Array} Modern şemaya dönüştürülmüş metin listesi
 */
const transformLegacyMetins = (legacyMetins) => {
  return legacyMetins.map((metin) => ({
    id: crypto.randomUUID(),
    name: metin.name,
    hp: metin.hp,
    drops: metin.drops.map((drop) => ({
      ...drop,
      id: crypto.randomUUID(), // Her drop için benzersiz ID
    })),
  }));
};

// ============================================================================
// INITIAL DATA (from _eski_drop/src/data/initialData.js)
// ============================================================================

const legacyItems = [
  { id: "yefsun", name: "Efsun Nesnesi (Yeşil)", price: 3000000 },
  { id: "yart", name: "Arttırma Kağıdı (Yeşil)", price: 1500000 },
  { id: "efsun", name: "Efsun Nesnesi", price: 6000000 },
  { id: "art", name: "Arttırma Kağıdı", price: 800000 },
  { id: "tas", name: "Ruh Taşı", price: 5000000 },
  { id: "cor", name: "Cor Draconis", price: 25000000 },
  { id: "munzevi", name: "Münzevi Tavsiyesi", price: 40000000 },
  { id: "zen", name: "Zen Fasulyesi", price: 80000000 },
  { id: "enerji", name: "Enerji Parçası", price: 450000 },
];

const legacyMetins = [
  {
    name: "Ruh Metni",
    hp: 119700,
    drops: [
      { itemId: "yefsun", count: 4, chance: 100 },
      { itemId: "yart", count: 2, chance: 100 },
      { itemId: "munzevi", count: 1, chance: 25 },
      { itemId: "zen", count: 1, chance: 15 },
    ],
  },
  {
    name: "Gölge Metni",
    hp: 142350,
    drops: [
      { itemId: "yefsun", count: 1, chance: 100 },
      { itemId: "yart", count: 1, chance: 100 },
      { itemId: "efsun", count: 1, chance: 100 },
      { itemId: "art", count: 1, chance: 100 },
      { itemId: "munzevi", count: 1, chance: 25 },
    ],
  },
  {
    name: "Şeytan Metni",
    hp: 195900,
    drops: [
      { itemId: "yefsun", count: 1, chance: 100 },
      { itemId: "yart", count: 1, chance: 100 },
      { itemId: "efsun", count: 1, chance: 100 },
      { itemId: "art", count: 1, chance: 100 },
      { itemId: "cor", count: 1, chance: 10 },
      { itemId: "munzevi", count: 1, chance: 25 },
    ],
  },
  {
    name: "Ölüm Metni",
    hp: 260250,
    drops: [
      { itemId: "yefsun", count: 2, chance: 100 },
      { itemId: "yart", count: 2, chance: 100 },
      { itemId: "efsun", count: 2, chance: 100 },
      { itemId: "art", count: 2, chance: 100 },
      { itemId: "cor", count: 1, chance: 20 },
      { itemId: "munzevi", count: 1, chance: 60 },
      { itemId: "zen", count: 1, chance: 15 },
    ],
  },
  {
    name: "Katil Metni",
    hp: 296550,
    drops: [
      { itemId: "yefsun", count: 2, chance: 100 },
      { itemId: "yart", count: 2, chance: 100 },
      { itemId: "efsun", count: 2, chance: 100 },
      { itemId: "art", count: 2, chance: 100 },
      { itemId: "cor", count: 1, chance: 10 },
      { itemId: "munzevi", count: 1, chance: 25 },
      { itemId: "zen", count: 1, chance: 15 },
    ],
  },
  {
    name: "Büyülü Metin",
    hp: 1500000,
    drops: [
      { itemId: "efsun", count: 9, chance: 100 },
      { itemId: "cor", count: 1, chance: 50 },
      { itemId: "zen", count: 1, chance: 15 },
    ],
  },
];

// Veriyi dönüştür
const initialMarketItems = transformLegacyItems(legacyItems);
const initialMetinList = transformLegacyMetins(legacyMetins);

// ============================================================================
// B. Store State (Dinamik Veri)
// ============================================================================
const useWidgetStore = create(
  persist(
    immer((set, get) => ({
      // Aktif workspace ID'si
      activeWorkspaceId: "default-workspace",

      // Çalışma alanları listesi
      workspaces: [
        {
          id: "default-workspace",
          name: "Ana Panel",
          widgets: [
            {
              id: crypto.randomUUID(),
              type: "money-input",
              isVisible: true,
              data: { amount: "" },
            },
            {
              id: crypto.randomUUID(),
              type: "note-taker",
              isVisible: true,
              data: { notes: "" },
            },
          ],
        },
      ],

      // Pazar eşya listesi (Modernize edilmiş)
      marketItems: initialMarketItems,

      // Metin listesi
      metinList: initialMetinList,

      // Kullanıcı istatistikleri
      userStats: {
        damage: 3000, // Vuruş başına hasar
        hitsPerSecond: 2.5, // Saniye başına vuruş
        findTime: 10, // Metin bulma süresi (saniye)
      },

      // ============================================================================
      // C. Actions (Fonksiyonlar) - Immer Kullanarak
      // ============================================================================

      /**
       * 1. Yeni bir çalışma alanı oluşturur
       * @param {string} name - Workspace adı
       */
      addWorkspace: (name) =>
        set((state) => {
          const newWorkspace = {
            id: crypto.randomUUID(),
            name: name || "Yeni Panel",
            widgets: [],
          };
          state.workspaces.push(newWorkspace);
          // Yeni workspace'i aktif yap
          state.activeWorkspaceId = newWorkspace.id;
        }),

      /**
       * 2. Aktif sekmeyi değiştirir
       * @param {string} id - Workspace ID
       */
      switchWorkspace: (id) =>
        set((state) => {
          const workspace = state.workspaces.find((ws) => ws.id === id);
          if (workspace) {
            state.activeWorkspaceId = id;
          }
        }),

      /**
       * 3. Aktif workspace'e yeni widget ekler
       * @param {string} type - Widget tipi (WIDGET_REGISTRY'den)
       */
      addWidget: (type) =>
        set((state) => {
          // Registry'de bu tip var mı kontrol et
          if (!WIDGET_REGISTRY[type]) {
            console.error(`Widget tipi "${type}" registry'de bulunamadı!`);
            return;
          }

          // Aktif workspace'i bul
          const activeWorkspace = state.workspaces.find(
            (ws) => ws.id === state.activeWorkspaceId
          );

          if (!activeWorkspace) {
            console.error("Aktif workspace bulunamadı!");
            return;
          }

          // Registry'den default data'yı kopyala
          const defaultData = { ...WIDGET_REGISTRY[type].defaultData };

          // Yeni widget oluştur
          const newWidget = {
            id: crypto.randomUUID(),
            type,
            isVisible: true,
            data: defaultData,
          };

          // Workspace'e ekle
          activeWorkspace.widgets.push(newWidget);
        }),

      /**
       * 4. Aktif workspace'ten widget siler
       * @param {string} widgetId - Silinecek widget ID
       */
      removeWidget: (widgetId) =>
        set((state) => {
          const activeWorkspace = state.workspaces.find(
            (ws) => ws.id === state.activeWorkspaceId
          );

          if (!activeWorkspace) {
            console.error("Aktif workspace bulunamadı!");
            return;
          }

          // Widget'ı diziden çıkar
          const widgetIndex = activeWorkspace.widgets.findIndex(
            (w) => w.id === widgetId
          );

          if (widgetIndex !== -1) {
            activeWorkspace.widgets.splice(widgetIndex, 1);
          }
        }),

      /**
       * 5. Widget'ın data objesini günceller (merge eder)
       * @param {string} widgetId - Güncellenecek widget ID
       * @param {object} partialData - Merge edilecek data
       */
      updateWidgetData: (widgetId, partialData) =>
        set((state) => {
          const activeWorkspace = state.workspaces.find(
            (ws) => ws.id === state.activeWorkspaceId
          );

          if (!activeWorkspace) {
            console.error("Aktif workspace bulunamadı!");
            return;
          }

          const widget = activeWorkspace.widgets.find((w) => w.id === widgetId);

          if (widget) {
            // Mevcut data ile yeni data'yı merge et
            widget.data = { ...widget.data, ...partialData };
          }
        }),

      /**
       * 6. Widget'ın görünürlüğünü toggle eder (Gizle/Göster)
       * @param {string} widgetId - Toggle edilecek widget ID
       */
      toggleWidgetVisibility: (widgetId) =>
        set((state) => {
          const activeWorkspace = state.workspaces.find(
            (ws) => ws.id === state.activeWorkspaceId
          );

          if (!activeWorkspace) {
            console.error("Aktif workspace bulunamadı!");
            return;
          }

          const widget = activeWorkspace.widgets.find((w) => w.id === widgetId);

          if (widget) {
            widget.isVisible = !widget.isVisible;
          }
        }),

      /**
       * Workspace siler
       * @param {string} workspaceId - Silinecek workspace ID
       */
      removeWorkspace: (workspaceId) =>
        set((state) => {
          // En az bir workspace kalmalı
          if (state.workspaces.length <= 1) {
            console.warn("Son workspace silinemez!");
            return;
          }

          // Silinecek workspace'in index'ini bul
          const workspaceIndex = state.workspaces.findIndex(
            (ws) => ws.id === workspaceId
          );

          if (workspaceIndex === -1) {
            console.error("Workspace bulunamadı!");
            return;
          }

          // Eğer silinen workspace aktifse, başka birine geç
          if (state.activeWorkspaceId === workspaceId) {
            // Bir sonraki veya bir önceki workspace'e geç
            const newActiveIndex =
              workspaceIndex === state.workspaces.length - 1
                ? workspaceIndex - 1
                : workspaceIndex + 1;
            state.activeWorkspaceId = state.workspaces[newActiveIndex].id;
          }

          // Workspace'i sil
          state.workspaces.splice(workspaceIndex, 1);
        }),

      /**
       * Workspace adını günceller
       * @param {string} workspaceId - Güncellenecek workspace ID
       * @param {string} newName - Yeni isim
       */
      renameWorkspace: (workspaceId, newName) =>
        set((state) => {
          const workspace = state.workspaces.find((ws) => ws.id === workspaceId);
          if (workspace) {
            workspace.name = newName;
          }
        }),

      // ============================================================================
      // MARKET PRICES ACTIONS
      // ============================================================================

      /**
       * Pazara yeni eşya ekler
       * @param {Object} item - Eklenecek eşya
       */
      addMarketItem: (item) =>
        set((state) => {
          const newItem = {
            id: crypto.randomUUID(),
            originalId: null, // Kullanıcı tarafından eklenen
            name: item.name,
            price: item.price,
            category: item.category || "genel",
            isSystemItem: false, // Kullanıcı ekleyebilir, silebilir
            icon: item.icon || "Circle",
          };

          state.marketItems.push(newItem);
        }),

      /**
       * Eşya fiyatını günceller
       * @param {string} id - Güncellenecek eşya ID'si
       * @param {number} newPrice - Yeni fiyat
       */
      updateItemPrice: (id, newPrice) =>
        set((state) => {
          const item = state.marketItems.find((item) => item.id === id);
          if (item) {
            item.price = parseFloat(newPrice) || 0;
          }
        }),

      /**
       * Pazardan eşya siler (sadece kullanıcı eşyaları)
       * @param {string} id - Silinecek eşya ID'si
       */
      removeMarketItem: (id) =>
        set((state) => {
          const item = state.marketItems.find((item) => item.id === id);

          // Sistem eşyalarını silme
          if (item && item.isSystemItem) {
            console.warn(
              "Sistem eşyaları silinemez! Sadece kullanıcı eşyalarını silebilirsiniz."
            );
            return;
          }

          const index = state.marketItems.findIndex((item) => item.id === id);
          if (index !== -1) {
            state.marketItems.splice(index, 1);
          }
        }),

      /**
       * Kullanıcı istatistiklerini günceller
       * @param {Object} newStats - Yeni istatistikler (partial update)
       */
      updateUserStats: (newStats) =>
        set((state) => {
          state.userStats = {
            ...state.userStats,
            ...newStats,
          };
        }),

      /**
       * Belirli bir metin için gelir hesaplar
       * @param {string} metinId - Hesaplanacak metin ID'si
       * @returns {Object} Hesaplama sonuçları
       */
      calculateIncome: (metinId) => {
        const state = get();
        const metin = state.metinList.find((m) => m.id === metinId);

        if (!metin) {
          console.error(`Metin bulunamadı: ${metinId}`);
          return null;
        }

        // TODO: Gelir hesaplama algoritması buraya eklenecek
        return {
          metinName: metin.name,
          totalDropValue: 0,
          killTime: 0,
          cycleTime: 0,
          hourlyProfit: 0,
        };
      },

      // ============================================================================
      // METIN MANAGEMENT ACTIONS
      // ============================================================================

      /**
       * Metin HP'sini günceller
       * @param {string} metinId - Güncellenecek metin ID'si
       * @param {number} newHp - Yeni HP değeri
       */
      updateMetinHp: (metinId, newHp) =>
        set((state) => {
          const metin = state.metinList.find((m) => m.id === metinId);
          if (metin) {
            metin.hp = parseFloat(newHp) || 0;
          }
        }),

      /**
       * Metin'e drop ekler
       * @param {string} metinId - Metin ID'si
       * @param {Object} drop - Eklenecek drop
       */
      addMetinDrop: (metinId, drop) =>
        set((state) => {
          const metin = state.metinList.find((m) => m.id === metinId);
          if (metin) {
            const newDrop = {
              id: crypto.randomUUID(),
              itemId: drop.itemId,
              count: drop.count || 1,
              chance: drop.chance || 10,
            };
            metin.drops.push(newDrop);
          }
        }),

      /**
       * Metin'den drop siler
       * @param {string} metinId - Metin ID'si
       * @param {string} dropId - Silinecek drop ID'si
       */
      removeMetinDrop: (metinId, dropId) =>
        set((state) => {
          const metin = state.metinList.find((m) => m.id === metinId);
          if (metin) {
            const index = metin.drops.findIndex((d) => d.id === dropId);
            if (index !== -1) {
              metin.drops.splice(index, 1);
            }
          }
        }),

      /**
       * Metin drop verilerini günceller
       * @param {string} metinId - Metin ID'si
       * @param {string} dropId - Drop ID'si
       * @param {Object} updates - Güncellenecek alanlar
       */
      updateMetinDrop: (metinId, dropId, updates) =>
        set((state) => {
          const metin = state.metinList.find((m) => m.id === metinId);
          if (metin) {
            const drop = metin.drops.find((d) => d.id === dropId);
            if (drop) {
              Object.assign(drop, updates);
            }
          }
        }),
    })),
    {
      name: "widget-storage", // LocalStorage key
      version: 1,
    }
  )
);

// ============================================================================
// D. Helper Hook - Widget Definition
// ============================================================================
/**
 * Verilen widget tipine göre Registry'den ikon ve başlık bilgisini döndürür
 * @param {string} type - Widget tipi
 * @returns {object} { title, icon, defaultData } veya null
 */
export const useWidgetDefinition = (type) => {
  return WIDGET_REGISTRY[type] || null;
};

// ============================================================================
// E. Selector Hooks (Performans için)
// ============================================================================
/**
 * Aktif workspace'i döndürür
 */
export const useActiveWorkspace = () => {
  return useWidgetStore((state) => {
    const activeId = state.activeWorkspaceId;
    return state.workspaces.find((ws) => ws.id === activeId);
  });
};

/**
 * Aktif workspace'teki görünür widget'ları döndürür
 */
export const useVisibleWidgets = () => {
  return useWidgetStore((state) => {
    const activeWorkspace = state.workspaces.find(
      (ws) => ws.id === state.activeWorkspaceId
    );
    return activeWorkspace?.widgets.filter((w) => w.isVisible) || [];
  });
};

/**
 * Aktif workspace'teki gizli widget'ları döndürür
 */
export const useHiddenWidgets = () => {
  return useWidgetStore((state) => {
    const activeWorkspace = state.workspaces.find(
      (ws) => ws.id === state.activeWorkspaceId
    );
    return activeWorkspace?.widgets.filter((w) => !w.isVisible) || [];
  });
};

/**
 * Tüm workspace'leri döndürür
 */
export const useWorkspaces = () => {
  return useWidgetStore((state) => state.workspaces);
};

/**
 * Aktif workspace ID'sini döndürür
 */
export const useActiveWorkspaceId = () => {
  return useWidgetStore((state) => state.activeWorkspaceId);
};

// ============================================================================
// F. Widget Registry Export (Bileşenlerde kullanım için)
// ============================================================================
export { WIDGET_REGISTRY };

// Default export
export default useWidgetStore;
