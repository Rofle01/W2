"use client";

import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { X, EyeOff, Coins, Plus, Trash2, Search, Filter } from "lucide-react";
import * as LucideIcons from "lucide-react";
import useWidgetStore from "../../store/useWidgetStore";

// Helper: Format currency
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('tr-TR', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
};

// Helper: Format compact number
const formatCompactNumber = (number) => {
    if (!number) return "0";
    return new Intl.NumberFormat('tr-TR', {
        notation: "compact",
        maximumFractionDigits: 1
    }).format(number);
};

// ============================================================================
// SUMMARY VIEW COMPONENT
// ============================================================================
function MarketSummaryView() {
    const marketItems = useWidgetStore((state) => state.marketItems);

    const stats = useMemo(() => {
        const totalItems = marketItems.length;
        const totalValue = marketItems.reduce((sum, item) => sum + item.price, 0);
        return { totalItems, totalValue };
    }, [marketItems]);

    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden">
            <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-amber-50 rounded-lg">
                    <Coins className="w-8 h-8 text-amber-600" />
                </div>
            </div>
            <span className="text-3xl font-bold text-zinc-800 whitespace-nowrap">
                {stats.totalItems} Eşya
            </span>
            <span className="text-sm text-zinc-500 mt-1">
                Toplam: {formatCompactNumber(stats.totalValue)} Yang
            </span>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW COMPONENT
// ============================================================================
function MarketDetailView() {
    const marketItems = useWidgetStore((state) => state.marketItems);
    const updateItemPrice = useWidgetStore((state) => state.updateItemPrice);
    const removeMarketItem = useWidgetStore((state) => state.removeMarketItem);
    const addMarketItem = useWidgetStore((state) => state.addMarketItem);

    const [selectedCategory, setSelectedCategory] = useState("Tümü");
    const [searchQuery, setSearchQuery] = useState("");
    const [showAddForm, setShowAddForm] = useState(false);
    const [newItem, setNewItem] = useState({
        name: "",
        price: "",
        category: "genel",
        icon: "Circle"
    });

    // Get unique categories
    const categories = useMemo(() => {
        const cats = ["Tümü", ...new Set(marketItems.map(item => item.category))];
        return cats;
    }, [marketItems]);

    // Filter items
    const filteredItems = useMemo(() => {
        return marketItems.filter(item => {
            const matchesCategory = selectedCategory === "Tümü" || item.category === selectedCategory;
            const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [marketItems, selectedCategory, searchQuery]);

    // Calculate total value
    const totalValue = useMemo(() => {
        return filteredItems.reduce((sum, item) => sum + item.price, 0);
    }, [filteredItems]);

    // Handle price update
    const handlePriceUpdate = (id, newPrice) => {
        const price = parseFloat(newPrice);
        if (!isNaN(price) && price >= 0) {
            updateItemPrice(id, price);
        }
    };

    // Handle delete
    const handleDelete = (id) => {
        if (confirm("Bu eşyayı silmek istediğinizden emin misiniz?")) {
            removeMarketItem(id);
        }
    };

    // Handle add new item
    const handleAddItem = (e) => {
        e.preventDefault();
        if (newItem.name && newItem.price) {
            addMarketItem({
                name: newItem.name,
                price: parseFloat(newItem.price) || 0,
                category: newItem.category,
                icon: newItem.icon
            });
            setNewItem({ name: "", price: "", category: "genel", icon: "Circle" });
            setShowAddForm(false);
        }
    };

    const iconOptions = [
        "Circle", "Star", "Diamond", "Gem", "Crown", "Shield", "Sword",
        "Zap", "Heart", "Sparkles", "Award", "Package", "Gift"
    ];

    return (
        <div className="space-y-6 h-full flex flex-col">
            {/* Header Stats */}
            <div className="bg-gradient-to-r from-amber-50 to-yellow-50 p-4 rounded-xl border border-amber-200">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-zinc-600">Toplam Piyasa Değeri</p>
                        <p className="text-2xl font-bold text-amber-700">
                            {formatCurrency(totalValue)} Yang
                        </p>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-zinc-600">Gösterilen</p>
                        <p className="text-2xl font-bold text-zinc-800">
                            {filteredItems.length} / {marketItems.length}
                        </p>
                    </div>
                </div>
            </div>

            {/* Search and Filter */}
            <div className="space-y-3">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Eşya ara..."
                        className="w-full pl-10 pr-4 py-2 font-medium text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 placeholder:text-zinc-400"
                    />
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                    <Filter className="w-4 h-4 text-zinc-500" />
                    {categories.map((cat) => (
                        <button
                            key={cat}
                            onClick={() => setSelectedCategory(cat)}
                            className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${selectedCategory === cat
                                    ? "bg-amber-600 text-white shadow-md"
                                    : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200"
                                }`}
                        >
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </button>
                    ))}
                </div>

                <button
                    onClick={() => setShowAddForm(!showAddForm)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                    <Plus className="w-5 h-5" />
                    Yeni Eşya Ekle
                </button>
            </div>

            {/* Add Form */}
            {showAddForm && (
                <motion.form
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    onSubmit={handleAddItem}
                    className="bg-green-50 p-4 rounded-xl border border-green-200 space-y-3"
                >
                    <h3 className="font-semibold text-green-800 mb-2">Yeni Eşya Bilgileri</h3>
                    <div className="grid grid-cols-2 gap-3">
                        <input
                            type="text"
                            value={newItem.name}
                            onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                            className="px-3 py-2 font-medium text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 placeholder:text-zinc-400"
                            placeholder="Eşya adı"
                            required
                        />
                        <input
                            type="number"
                            value={newItem.price}
                            onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
                            className="px-3 py-2 font-semibold text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 placeholder:text-zinc-400"
                            placeholder="Fiyat"
                            required
                            min="0"
                        />
                        <input
                            type="text"
                            value={newItem.category}
                            onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                            className="px-3 py-2 font-medium text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 placeholder:text-zinc-400"
                            placeholder="Kategori"
                        />
                        <select
                            value={newItem.icon}
                            onChange={(e) => setNewItem({ ...newItem, icon: e.target.value })}
                            className="px-3 py-2 font-medium text-zinc-900 bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        >
                            {iconOptions.map((icon) => (
                                <option key={icon} value={icon}>{icon}</option>
                            ))}
                        </select>
                    </div>
                    <div className="flex gap-2">
                        <button
                            type="submit"
                            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                        >
                            Ekle
                        </button>
                        <button
                            type="button"
                            onClick={() => setShowAddForm(false)}
                            className="px-4 py-2 bg-zinc-200 text-zinc-700 rounded-lg hover:bg-zinc-300 transition-colors text-sm font-medium"
                        >
                            İptal
                        </button>
                    </div>
                </motion.form>
            )}

            {/* Items Table */}
            <div className="flex-1 overflow-auto rounded-xl border border-zinc-200">
                <table className="w-full">
                    <thead className="bg-zinc-100 sticky top-0">
                        <tr>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase">İkon</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase">Eşya Adı</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase">Kategori</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase">Fiyat</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-700 uppercase">İşlem</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-zinc-200">
                        {filteredItems.length === 0 ? (
                            <tr>
                                <td colSpan="5" className="px-4 py-8 text-center text-zinc-500">
                                    Eşya bulunamadı
                                </td>
                            </tr>
                        ) : (
                            filteredItems.map((item) => {
                                const ItemIcon = LucideIcons[item.icon] || LucideIcons.Circle;
                                return (
                                    <tr key={item.id} className="hover:bg-zinc-50 transition-colors group">
                                        <td className="px-4 py-3">
                                            <div className="p-2 bg-zinc-100 rounded-lg w-fit group-hover:bg-amber-100 transition-colors">
                                                <ItemIcon className="w-5 h-5 text-zinc-600 group-hover:text-amber-600" />
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <p className="text-sm font-medium text-zinc-800">{item.name}</p>
                                            {item.originalId && (
                                                <p className="text-xs text-zinc-400">ID: {item.originalId}</p>
                                            )}
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className="px-2 py-1 bg-zinc-100 text-zinc-700 rounded text-xs font-medium">
                                                {item.category}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <input
                                                type="number"
                                                value={item.price}
                                                onChange={(e) => handlePriceUpdate(item.id, e.target.value)}
                                                className="w-32 px-2 py-1 text-sm font-semibold text-zinc-900 bg-white border border-zinc-300 rounded focus:outline-none focus:ring-2 focus:ring-amber-500 placeholder:text-zinc-400"
                                                min="0"
                                            />
                                        </td>
                                        <td className="px-4 py-3">
                                            {!item.isSystemItem ? (
                                                <button
                                                    onClick={() => handleDelete(item.id)}
                                                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                                    title="Sil"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            ) : (
                                                <span className="text-xs text-zinc-400 px-2">Sistem</span>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>

            {/* Footer */}
            <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 flex items-center justify-between text-sm">
                <span className="text-zinc-600">
                    Toplam <strong>{filteredItems.length}</strong> eşya gösteriliyor
                </span>
                <span className="text-zinc-600">
                    Değer: <strong className="text-amber-700">{formatCurrency(totalValue)}</strong> Yang
                </span>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN WIDGET
// ============================================================================
export default function MarketWidget({ id, isSelected, onClick, onHide }) {
    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group bg-white rounded-3xl shadow-sm border border-zinc-200 cursor-pointer overflow-hidden ${isSelected
                    ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-6xl z-50 shadow-2xl"
                    : "relative h-64 hover:-translate-y-1 hover:shadow-lg hover:border-amber-200 transition-all duration-300"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {!isSelected && (
                <>
                    <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => {
                            e.stopPropagation();
                            onHide && onHide();
                        }}
                        className="absolute top-4 right-4 z-20 p-2 bg-white/80 backdrop-blur-sm shadow-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-zinc-400 hover:text-red-500 hover:bg-red-50"
                    >
                        <EyeOff className="w-4 h-4" />
                    </motion.button>
                    <div className="w-full h-full p-6 relative">
                        <Coins className="absolute -bottom-4 -right-4 w-32 h-32 text-amber-50 opacity-50 rotate-12 pointer-events-none" />
                        <MarketSummaryView />
                    </div>
                </>
            )}

            {isSelected && (
                <div className="flex flex-col h-full bg-zinc-50/50">
                    <div className="flex items-center justify-between p-8 border-b border-zinc-200 bg-white">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-amber-50 rounded-2xl">
                                <Coins className="w-8 h-8 text-amber-600" />
                            </div>
                            <div>
                                <motion.h2 layoutId={`title-${id}`} className="text-2xl font-bold text-zinc-800">
                                    Piyasa Fiyatları
                                </motion.h2>
                                <p className="text-zinc-500">Eşya fiyatlarını görüntüle ve yönet</p>
                            </div>
                        </div>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                        >
                            <X className="w-6 h-6 text-zinc-500" />
                        </button>
                    </div>
                    <div className="flex-1 p-8 overflow-hidden">
                        <MarketDetailView />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
