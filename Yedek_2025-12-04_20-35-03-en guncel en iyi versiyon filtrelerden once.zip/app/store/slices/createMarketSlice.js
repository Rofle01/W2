import { MASTER_REGISTRY, INITIAL_SERVERS } from "../../data/initialData";

export const createMarketSlice = (set, get) => ({
    // --- STATE ---
    masterRegistry: MASTER_REGISTRY.items, // Global Katalog
    serverProfiles: INITIAL_SERVERS,       // Sunucu Listesi
    activeServerId: INITIAL_SERVERS[0]?.id || "server_marmara", // Seçili Sunucu

    // --- ACTIONS ---

    // 1. Sunucu Yönetimi
    setActiveServer: (serverId) => set((state) => {
        const exists = state.serverProfiles.some(p => p.id === serverId);
        if (exists) state.activeServerId = serverId;
    }),

    addServerProfile: (name) => set((state) => {
        state.serverProfiles.push({
            id: `server_${Date.now()}`,
            name: name,
            currency: "Won",
            prices: {},
            multipliers: { drop: 1.0 }
        });
    }),

    // 2. Fiyat Yönetimi (Sadece Aktif Sunucuya Yazar)
    updatePrice: (itemId, newPrice) => set((state) => {
        const activeProfile = state.serverProfiles.find(p => p.id === state.activeServerId);
        if (activeProfile) {
            activeProfile.prices[itemId] = parseFloat(newPrice) || 0;
        }
    }),

    // Toplu Fiyat Güncelleme (Import işlemleri için performans optimizasyonu)
    batchUpdatePrices: (priceMap) => set((state) => {
        const activeProfile = state.serverProfiles.find(p => p.id === state.activeServerId);
        if (activeProfile) {
            // priceMap: { "71084": 5000000, "27992": 15000000 }
            // Mevcut fiyatlarla yeni fiyatları birleştir
            activeProfile.prices = {
                ...activeProfile.prices,
                ...priceMap
            };
        }
    }),

    // 3. Katalog Yönetimi (Yeni Item Ekleme)
    registerItem: (item) => set((state) => {
        const generatedId = item.id || item.name.toLowerCase().trim().replace(/\s+/g, '_');
        const exists = state.masterRegistry.some(i => i.id === generatedId);

        if (!exists) {
            state.masterRegistry.push({
                id: generatedId,
                name: item.name,
                category: item.category || "genel",
                icon: item.icon || "Circle",
                isSystemItem: false
            });
        }
    }),

    // YENİ EKLENECEK FONKSİYON: Toplu Item Kaydı
    registerItems: (items) => set((state) => {
        items.forEach(item => {
            // ID yoksa isimden ID üret
            const generatedId = item.id || item.name.toLowerCase().trim().replace(/\s+/g, '_');

            // Zaten var mı kontrol et
            const exists = state.masterRegistry.some(i => i.id === generatedId);

            if (!exists) {
                state.masterRegistry.push({
                    id: generatedId,
                    name: item.name,
                    category: item.category || "genel",
                    icon: item.icon || "Circle",
                    isSystemItem: false
                });
            }
        });
    }),
});
