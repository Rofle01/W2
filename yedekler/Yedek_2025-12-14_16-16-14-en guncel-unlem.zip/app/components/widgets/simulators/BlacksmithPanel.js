"use client";

import { useState, useCallback, useMemo } from "react";
import {
    Calculator,
    Loader2,
    Settings,
    ChevronDown,
    Hammer,
    Sparkles,
    Percent,
    Package,
    Layers,
    Target,
    TrendingUp,
    AlertTriangle,
    CheckCircle2,
    XCircle,
    Coins,
    BarChart3
} from "lucide-react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    Cell
} from "recharts";
import { usePersistentState } from "../../../hooks/usePersistentState";
import { useWorker } from "../../../hooks/useWorker";
import SmartInput from "../../ui/SmartInput";

// ============================================================================
// CONSTANTS
// ============================================================================

const MATERIALS = {
    blessing_scroll: { name: 'Kutsama Kağıdı', color: 'text-yellow-400', price: 1000000 },
    magic_stone: { name: 'Büyülü Metal', color: 'text-blue-400', price: 5000000 },
    ritual_stone: { name: 'Ritüel Taşı', color: 'text-purple-400', price: 15000000 },
    blacksmith_book: { name: 'Demirci El Kitabı', color: 'text-orange-400', price: 50000000 }
};

const MATERIAL_OPTIONS = [
    { value: 'ritual_stone', label: 'Ritüel Taşı' },
    { value: 'magic_stone', label: 'Büyülü Metal' },
    { value: 'blessing_scroll', label: 'Kutsama Kağıdı' },
    { value: 'blacksmith_book', label: 'El Kitabı' }
];

const DEFAULT_CONFIG = {
    calcMode: 'additive',      // 'additive' or 'multiplicative'
    pitySystem: 'none',        // 'none', 'incremental', 'hard'
    fallbackToRaw: false       // If no materials, use raw (destroy on fail)
};

const DEFAULT_INVENTORY = {
    blessing_scroll: 50,
    magic_stone: 10,
    ritual_stone: 5,
    blacksmith_book: 2
};

const DEFAULT_PRICES = {
    blessing_scroll: 1000000,
    magic_stone: 5000000,
    ritual_stone: 15000000,
    blacksmith_book: 50000000
};

// Default strategies for each level (Refine Table)
// Each level: { baseChance, pityLimit, priorityList, upgradeCost }
const DEFAULT_STRATEGY = {
    0: { baseChance: 90, pityLimit: 5, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    1: { baseChance: 85, pityLimit: 5, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    2: { baseChance: 80, pityLimit: 6, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    3: { baseChance: 75, pityLimit: 6, priorityList: ['blessing_scroll'], upgradeCost: 0 },
    4: { baseChance: 70, pityLimit: 7, priorityList: ['blessing_scroll'], upgradeCost: 100000 },
    5: { baseChance: 60, pityLimit: 8, priorityList: ['blessing_scroll', 'magic_stone'], upgradeCost: 200000 },
    6: { baseChance: 50, pityLimit: 10, priorityList: ['magic_stone', 'blessing_scroll'], upgradeCost: 300000 },
    7: { baseChance: 40, pityLimit: 12, priorityList: ['ritual_stone', 'magic_stone'], upgradeCost: 400000 },
    8: { baseChance: 30, pityLimit: 15, priorityList: ['ritual_stone', 'magic_stone', 'blessing_scroll'], upgradeCost: 500000 }
};

const DEFAULT_INPUT = {
    startLevel: 0,
    targetLevel: 9,
    simCount: 1000
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const formatCurrency = (value) => {
    if (value === undefined || value === null || isNaN(value)) return "0";
    if (value >= 1000000000) return `${(value / 1000000000).toFixed(2)}B`;
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return Math.round(value).toLocaleString("tr-TR");
};

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

function ResultCard({ title, value, subtitle, icon: Icon, color = "zinc" }) {
    const colorClasses = {
        zinc: "from-zinc-800/50 to-zinc-900/50 border-zinc-700/50",
        green: "from-green-500/20 to-green-500/5 border-green-500/30",
        red: "from-red-500/20 to-red-500/5 border-red-500/30",
        yellow: "from-yellow-500/20 to-yellow-500/5 border-yellow-500/30",
        violet: "from-violet-500/20 to-violet-500/5 border-violet-500/30"
    };

    const iconColors = {
        zinc: "text-zinc-400",
        green: "text-green-400",
        red: "text-red-400",
        yellow: "text-yellow-400",
        violet: "text-violet-400"
    };

    return (
        <div className={`bg-gradient-to-br ${colorClasses[color]} rounded-xl border p-4`}>
            <div className="flex items-center gap-2 mb-2">
                {Icon && <Icon className={`w-4 h-4 ${iconColors[color]}`} />}
                <span className="text-xs font-medium text-zinc-400">{title}</span>
            </div>
            <p className="text-xl font-bold text-white font-mono">{value}</p>
            {subtitle && <p className="text-xs text-zinc-500 mt-1">{subtitle}</p>}
        </div>
    );
}
function StrategyRow({ level, strategy, onChange, showPityLimit }) {
    // Grid columns: Level, Şans %, [Pity Limit], Maliyet, Priority 1-3
    const gridCols = showPityLimit ? 'grid-cols-7' : 'grid-cols-6';

    return (
        <div className={`grid ${gridCols} gap-2 items-center py-2 border-b border-zinc-800/50`}>
            <div className="text-sm text-zinc-400 font-mono">
                +{level} ➜ +{level + 1}
            </div>

            {/* Base Chance */}
            <div>
                <SmartInput
                    value={strategy.baseChance}
                    onChange={(val) => onChange(level, 'baseChance', val)}
                    min={1}
                    max={100}
                    className="w-full px-2 py-1 text-xs font-mono text-white bg-zinc-950 border border-zinc-700 rounded"
                />
            </div>

            {/* Pity Limit - Conditionally Rendered */}
            {showPityLimit && (
                <div>
                    <SmartInput
                        value={strategy.pityLimit !== undefined ? strategy.pityLimit : 10}
                        onChange={(val) => onChange(level, 'pityLimit', val)}
                        min={0}
                        max={100}
                        placeholder="Limit (0=Yok)"
                        className="w-full px-2 py-1 text-xs font-mono text-white bg-zinc-950 border border-zinc-700 rounded border-orange-500/30 text-orange-400"
                    />
                </div>
            )}

            {/* Upgrade Cost (Yang) */}
            <div>
                <SmartInput
                    value={strategy.upgradeCost !== undefined ? strategy.upgradeCost : 0}
                    onChange={(val) => onChange(level, 'upgradeCost', val)}
                    min={0}
                    className="w-full px-2 py-1 text-xs font-mono text-yellow-400 bg-zinc-950 border border-zinc-700 rounded border-yellow-500/30"
                    placeholder="0"
                />
            </div>

            {/* Priority 1 */}
            <select
                value={strategy.priorityList[0] || 'blessing_scroll'}
                onChange={(e) => {
                    const newList = [...strategy.priorityList];
                    newList[0] = e.target.value;
                    onChange(level, 'priorityList', newList);
                }}
                className="px-2 py-1 text-xs text-white bg-zinc-950 border border-zinc-700 rounded"
            >
                {MATERIAL_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
            </select>

            {/* Priority 2 */}
            <select
                value={strategy.priorityList[1] || ''}
                onChange={(e) => {
                    const newList = [...strategy.priorityList];
                    newList[1] = e.target.value;
                    onChange(level, 'priorityList', newList.filter(Boolean));
                }}
                className="px-2 py-1 text-xs text-white bg-zinc-950 border border-zinc-700 rounded"
            >
                <option value="">-</option>
                {MATERIAL_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
            </select>

            {/* Priority 3 */}
            <select
                value={strategy.priorityList[2] || ''}
                onChange={(e) => {
                    const newList = [...strategy.priorityList];
                    newList[2] = e.target.value;
                    onChange(level, 'priorityList', newList.filter(Boolean));
                }}
                className="px-2 py-1 text-xs text-white bg-zinc-950 border border-zinc-700 rounded"
            >
                <option value="">-</option>
                {MATERIAL_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
            </select>
        </div>
    );
}

const DEFAULT_BONUSES = {
    blessing_scroll: 0,
    magic_stone: 5,
    ritual_stone: 10,
    blacksmith_book: 15
};

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function BlacksmithPanel() {
    // Persistent state
    const [config, setConfig] = usePersistentState("blacksmith-config-v1", DEFAULT_CONFIG);
    const [inventory, setInventory] = usePersistentState("blacksmith-inventory-v1", DEFAULT_INVENTORY);
    const [materialBonuses, setMaterialBonuses] = usePersistentState("blacksmith-bonuses-v1", DEFAULT_BONUSES);
    const [prices, setPrices] = usePersistentState("blacksmith-prices-v1", DEFAULT_PRICES);
    const [strategy, setStrategy] = usePersistentState("blacksmith-strategy-v1", DEFAULT_STRATEGY);
    const [input, setInput] = usePersistentState("blacksmith-input-v1", DEFAULT_INPUT);

    // Worker
    const { run, status, result, progress, isRunning } = useWorker("/workers/blacksmith.worker.js");

    // Handlers
    const handleInputChange = useCallback((field, value) => {
        setInput(prev => ({ ...prev, [field]: value }));
    }, [setInput]);

    const handleConfigChange = useCallback((field, value) => {
        setConfig(prev => ({ ...prev, [field]: value }));
    }, [setConfig]);

    const handleInventoryChange = useCallback((material, value) => {
        setInventory(prev => ({ ...prev, [material]: value }));
    }, [setInventory]);

    const handlePriceChange = useCallback((material, value) => {
        setPrices(prev => ({ ...prev, [material]: value }));
    }, [setPrices]);

    const handleStrategyChange = useCallback((level, field, value) => {
        setStrategy(prev => ({
            ...prev,
            [level]: { ...prev[level], [field]: value }
        }));
    }, [setStrategy]);

    const handleSimulate = useCallback(() => {
        run({
            action: "run_simulation",
            startLevel: input.startLevel,
            targetLevel: input.targetLevel,
            inventory: inventory,
            prices: prices, // Pass custom prices
            config: config,
            strategy: strategy,
            materialBonuses: materialBonuses,
            simCount: input.simCount
        });
    }, [run, input, inventory, config, strategy, prices, materialBonuses]);

    // Generate level range for strategy table
    const levelRange = useMemo(() => {
        const range = [];
        for (let i = input.startLevel; i < input.targetLevel; i++) {
            range.push(i);
        }
        return range;
    }, [input.startLevel, input.targetLevel]);

    return (
        <div className="h-full flex flex-col overflow-hidden">
            {/* Header */}
            <header className="flex-shrink-0 p-4 border-b border-zinc-800 bg-zinc-950/80">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-orange-900/30 rounded-xl border border-orange-500/30">
                            <Hammer className="w-5 h-5 text-orange-400" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-white">Demirci Simülasyonu</h2>
                            <p className="text-xs text-zinc-500">Strateji bazlı yükseltme analizi</p>
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content - 3 Column Layout */}
            <div className="flex-1 overflow-auto">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 p-4">

                    {/* LEFT PANEL - Config & Inventory */}
                    <div className="space-y-4">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                            <Settings className="w-4 h-4" />
                            Sunucu Ayarları
                        </h3>

                        {/* Calc Mode */}
                        <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Bonus Hesaplama
                            </label>
                            <div className="grid grid-cols-2 gap-2">
                                <button
                                    onClick={() => handleConfigChange("calcMode", "additive")}
                                    className={`p-2 text-xs rounded-lg border transition-all ${config.calcMode === 'additive'
                                        ? 'bg-orange-500/20 border-orange-500/50 text-orange-300'
                                        : 'bg-zinc-900 border-zinc-700 text-zinc-400'
                                        }`}
                                >
                                    Düz (+%10)
                                </button>
                                <button
                                    onClick={() => handleConfigChange("calcMode", "multiplicative")}
                                    className={`p-2 text-xs rounded-lg border transition-all ${config.calcMode === 'multiplicative'
                                        ? 'bg-orange-500/20 border-orange-500/50 text-orange-300'
                                        : 'bg-zinc-900 border-zinc-700 text-zinc-400'
                                        }`}
                                >
                                    Oransal (x1.1)
                                </button>
                            </div>
                        </div>

                        {/* Pity System */}
                        <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Pity Sistemi
                            </label>
                            <select
                                value={config.pitySystem}
                                onChange={(e) => handleConfigChange("pitySystem", e.target.value)}
                                className="w-full px-3 py-2 text-sm text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                            >
                                <option value="none">Yok</option>
                                <option value="incremental">Artan (Her yanışta +%5)</option>
                                <option value="hard">Garanti (X yanışta %100)</option>
                            </select>
                        </div>

                        {/* Inventory & Bonuses */}
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2 mt-4">
                            <Package className="w-4 h-4" />
                            Envanter & Bonuslar
                        </h3>

                        <div className="space-y-3">
                            {Object.entries(MATERIALS).map(([id, mat]) => (
                                <div key={id} className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                                    <div className="flex items-center justify-between mb-2">
                                        <span className={`text-xs font-semibold ${mat.color}`}>{mat.name}</span>
                                    </div>
                                    <div className="grid grid-cols-3 gap-2">
                                        {/* Stock Input */}
                                        <div>
                                            <label className="block text-[10px] text-zinc-500 mb-1">Adet</label>
                                            <SmartInput
                                                value={inventory[id] || 0}
                                                onChange={(val) => handleInventoryChange(id, val)}
                                                min={0}
                                                className="w-full px-2 py-1 text-xs font-mono text-white bg-zinc-950 border border-zinc-700 rounded"
                                            />
                                        </div>
                                        {/* Bonus Input */}
                                        <div>
                                            <label className="block text-[10px] text-zinc-500 mb-1">Şans %</label>
                                            <SmartInput
                                                value={materialBonuses[id] !== undefined ? materialBonuses[id] : (DEFAULT_BONUSES[id] || 0)}
                                                onChange={(val) => setMaterialBonuses(prev => ({ ...prev, [id]: val }))}
                                                min={0}
                                                max={100}
                                                className="w-full px-2 py-1 text-xs font-mono text-green-400 bg-zinc-950 border border-zinc-700 rounded border-green-500/20"
                                            />
                                        </div>
                                        {/* Price Input */}
                                        <div>
                                            <label className="block text-[10px] text-zinc-500 mb-1">Birim Fiyat</label>
                                            <SmartInput
                                                value={prices[id] !== undefined ? prices[id] : (mat.price || 0)}
                                                onChange={(val) => handlePriceChange(id, val)}
                                                min={0}
                                                className="w-full px-2 py-1 text-xs font-mono text-yellow-400 bg-zinc-950 border border-zinc-700 rounded border-yellow-500/20"
                                            />
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Level Range */}
                        <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <label className="block text-xs text-zinc-500 mb-1">Başlangıç</label>
                                    <SmartInput
                                        value={input.startLevel}
                                        onChange={(val) => handleInputChange("startLevel", val)}
                                        min={0}
                                        max={8}
                                        className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs text-zinc-500 mb-1">Hedef</label>
                                    <SmartInput
                                        value={input.targetLevel}
                                        onChange={(val) => handleInputChange("targetLevel", val)}
                                        min={1}
                                        max={9}
                                        className="w-full px-2 py-1.5 text-sm font-mono text-white bg-zinc-950 border border-zinc-700 rounded-lg"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Sim Count */}
                        <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                            <label className="block text-xs font-medium text-zinc-400 mb-2">
                                Simülasyon: {input.simCount.toLocaleString()}
                            </label>
                            <input
                                type="range"
                                min={100}
                                max={10000}
                                step={100}
                                value={input.simCount}
                                onChange={(e) => handleInputChange("simCount", parseInt(e.target.value))}
                                className="w-full h-2 bg-zinc-800 rounded-lg accent-orange-500"
                            />
                        </div>

                        {/* Simulate Button */}
                        <button
                            onClick={handleSimulate}
                            disabled={isRunning}
                            className={`
                                w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all
                                ${isRunning
                                    ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                                    : "bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white shadow-lg"
                                }
                            `}
                        >
                            {isRunning ? (
                                <>
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                    Simüle Ediliyor... {progress}%
                                </>
                            ) : (
                                <>
                                    <Calculator className="w-5 h-5" />
                                    Simülasyonu Başlat
                                </>
                            )}
                        </button>
                    </div>

                    {/* CENTER PANEL - Strategy Table */}
                    <div className="lg:col-span-2 space-y-4">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Strateji Tablosu
                        </h3>

                        <div className="bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden">
                            {/* Table Header */}
                            <div className={`grid ${config.pitySystem === 'hard' ? 'grid-cols-7' : 'grid-cols-6'} gap-2 px-3 py-2 bg-zinc-800/50 text-xs text-zinc-500 font-medium`}>
                                <div>Seviye</div>
                                <div>Şans %</div>
                                {config.pitySystem === 'hard' && <div className="text-orange-400">Pity</div>}
                                <div className="text-yellow-400">Maliyet</div>
                                <div>Öncelik 1</div>
                                <div>Öncelik 2</div>
                                <div>Öncelik 3</div>
                            </div>

                            {/* Table Rows */}
                            <div className="px-3 max-h-80 overflow-y-auto">
                                {levelRange.map(level => (
                                    <StrategyRow
                                        key={level}
                                        level={level}
                                        strategy={strategy[level] || DEFAULT_STRATEGY[level] || { baseChance: 30, pityLimit: 10, priorityList: ['blessing_scroll'], upgradeCost: 0 }}
                                        onChange={handleStrategyChange}
                                        showPityLimit={config.pitySystem === 'hard'}
                                    />
                                ))}
                            </div>
                        </div>

                        {/* Strategy Tips */}
                        <div className="bg-zinc-800/30 p-3 rounded-lg border border-zinc-700/50">
                            <p className="text-xs text-zinc-500">
                                💡 Her seviye için kullanılacak materyallerin öncelik sırasını belirleyin.
                                İlk materyal bittiğinde otomatik olarak bir sonrakine geçilir.
                            </p>
                        </div>
                    </div>

                    {/* RIGHT PANEL - Results */}
                    <div className="space-y-4">
                        <h3 className="text-sm font-semibold text-zinc-400 flex items-center gap-2">
                            <BarChart3 className="w-4 h-4" />
                            Sonuçlar
                        </h3>

                        {result ? (
                            <div className="space-y-3">
                                {/* Success Rate */}
                                <ResultCard
                                    title="Başarı Oranı"
                                    value={`%${result.successRate}`}
                                    subtitle={`${result.simCount} deneme`}
                                    icon={result.successRate >= 50 ? CheckCircle2 : XCircle}
                                    color={result.successRate >= 50 ? "green" : "red"}
                                />

                                {/* Average Cost (Total: Material + Yang) */}
                                <ResultCard
                                    title="Toplam Maliyet"
                                    value={`${formatCurrency(result.avgCost)} Yang`}
                                    subtitle={`${result.avgAttempts} deneme`}
                                    icon={Coins}
                                    color="yellow"
                                />

                                {/* Cost Breakdown */}
                                {(result.avgMaterialCost > 0 || result.avgYangCost > 0) && (
                                    <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                                        <h4 className="text-xs font-semibold text-zinc-400 mb-2">Maliyet Dağılımı</h4>
                                        <div className="space-y-1">
                                            <div className="flex justify-between text-xs">
                                                <span className="text-blue-400">Materyal</span>
                                                <span className="text-white font-mono">{formatCurrency(result.avgMaterialCost)}</span>
                                            </div>
                                            <div className="flex justify-between text-xs">
                                                <span className="text-yellow-400">Yükseltme Ücreti</span>
                                                <span className="text-white font-mono">{formatCurrency(result.avgYangCost)}</span>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* Material Usage */}
                                <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                                    <h4 className="text-xs font-semibold text-zinc-400 mb-2">Materyal Kullanımı</h4>
                                    <div className="space-y-1">
                                        {Object.entries(result.avgMaterials || {}).filter(([_, v]) => v > 0).map(([mat, avg]) => (
                                            <div key={mat} className="flex justify-between text-xs">
                                                <span className={MATERIALS[mat]?.color || 'text-zinc-400'}>
                                                    {MATERIALS[mat]?.name || mat}
                                                </span>
                                                <span className="text-white font-mono">{avg}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                {/* Stock Analysis */}
                                {result.stockAnalysis && (
                                    <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                                        <h4 className="text-xs font-semibold text-zinc-400 mb-2">Envanter Durumu</h4>
                                        <div className="space-y-1">
                                            {Object.entries(result.stockAnalysis)
                                                .filter(([_, data]) => data.required > 0)
                                                .map(([mat, data]) => (
                                                    <div key={mat} className="flex items-center justify-between text-xs">
                                                        <span className={data.sufficient ? 'text-green-400' : 'text-red-400'}>
                                                            {MATERIALS[mat]?.name || mat}
                                                        </span>
                                                        <span className="font-mono">
                                                            {data.available}/{data.required.toFixed(1)}
                                                            {data.deficit > 0 && (
                                                                <span className="text-red-400 ml-1">(-{data.deficit})</span>
                                                            )}
                                                        </span>
                                                    </div>
                                                ))}
                                        </div>
                                    </div>
                                )}

                                {/* Warnings */}
                                {result.stockOutSummary?.length > 0 && (
                                    <div className="bg-yellow-900/20 p-3 rounded-xl border border-yellow-500/30">
                                        <h4 className="text-xs font-semibold text-yellow-400 mb-2 flex items-center gap-1">
                                            <AlertTriangle className="w-3 h-3" />
                                            Uyarılar
                                        </h4>
                                        <div className="space-y-1 text-xs text-yellow-300/80">
                                            {result.stockOutSummary.slice(0, 3).map((warning, i) => (
                                                <p key={i}>
                                                    +{warning.level}'de {warning.materialName} %{warning.frequency} simülasyonda bitti
                                                </p>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/* Level Distribution Chart */}
                                {result.levelDistribution && (
                                    <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-800">
                                        <h4 className="text-xs font-semibold text-zinc-400 mb-2">Bitiş Seviyesi Dağılımı</h4>
                                        <div className="h-32">
                                            <ResponsiveContainer width="100%" height="100%">
                                                <BarChart data={result.levelDistribution}>
                                                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                                    <XAxis
                                                        dataKey="level"
                                                        tick={{ fill: '#888', fontSize: 10 }}
                                                        tickFormatter={(v) => `+${v}`}
                                                    />
                                                    <YAxis
                                                        tick={{ fill: '#888', fontSize: 10 }}
                                                        tickFormatter={(v) => `${v}%`}
                                                    />
                                                    <Tooltip
                                                        contentStyle={{ background: '#18181b', border: '1px solid #333' }}
                                                        labelFormatter={(v) => `+${v}`}
                                                        formatter={(v) => [`${v}%`, 'Oran']}
                                                    />
                                                    <Bar dataKey="percentage">
                                                        {result.levelDistribution.map((entry, index) => (
                                                            <Cell
                                                                key={`cell-${index}`}
                                                                fill={entry.level >= input.targetLevel ? '#22c55e' : '#f97316'}
                                                            />
                                                        ))}
                                                    </Bar>
                                                </BarChart>
                                            </ResponsiveContainer>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-48 text-zinc-600 bg-zinc-900/30 rounded-xl border border-zinc-800">
                                <Hammer className="w-10 h-10 mb-2 opacity-20" />
                                <p className="text-sm">Sonuçlar burada görünecek</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
