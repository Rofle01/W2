"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";

// Slice'ları içe aktar
import { createUISlice } from "./slices/createUISlice";
import { createMarketSlice } from "./slices/createMarketSlice";
import { createCraftingSlice } from "./slices/createCraftingSlice";

// Sabitleri içe aktar (Eğer app/store/constants.js oluşturmadıysan, WIDGET_REGISTRY'yi app/data/constants.js yolundan alabilirsin)
// Not: Eğer constants dosyan yoksa bu satırı kontrol et.
import { createBossSlice } from "./slices/createBossSlice";

// Sabitleri içe aktar (Eğer app/store/constants.js oluşturmadıysan, WIDGET_REGISTRY'yi app/data/constants.js yolundan alabilirsin)
// Not: Eğer constants dosyan yoksa bu satırı kontrol et.
import { WIDGET_REGISTRY } from "../store/constants";

// ============================================================================
// STORE OLUŞTURMA (Slice Pattern)
// ============================================================================
const useWidgetStore = create(
  persist(
    immer((...a) => ({
      ...createUISlice(...a),
      ...createMarketSlice(...a),
      ...createCraftingSlice(...a),
      ...createBossSlice(...a),
    })),
    {
      name: "financial-dashboard-storage", // LocalStorage Key
      version: 6, // ÖNEMLİ: Versiyon 6'ya geçtik, Boss slice eklendi.

      // Migration: Versiyon değişirse state'i temizle
      migrate: (persistedState, version) => {
        if (version < 6) {
          return {
            ...persistedState,
            bosses: [] // Yeni boss state'ini başlat
          };
        }
        return persistedState;
      },
    }
  )
);

// ============================================================================
// HELPER HOOKS
// ============================================================================

/**
 * Verilen widget tipine göre Registry'den tanım döndürür
 */
export const useWidgetDefinition = (type) => {
  return WIDGET_REGISTRY[type] || null;
};

/**
 * Aktif workspace'i döndürür
 */
export const useActiveWorkspace = () => {
  return useWidgetStore((state) => {
    const activeId = state.activeWorkspaceId;
    return state.workspaces.find((ws) => ws.id === activeId);
  });
};

// ============================================================================
// EXPORTS
// ============================================================================
export { WIDGET_REGISTRY };
export default useWidgetStore;
