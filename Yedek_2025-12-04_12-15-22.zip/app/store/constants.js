/**
 * ============================================================================
 * WIDGET REGISTRY - Sabit Widget Tanımları
 * ============================================================================
 * 
 * Bu dosya, uygulamadaki tüm widget tiplerinin katalogunu içerir.
 * Her widget için başlık, ikon ve varsayılan veri yapısı tanımlanmıştır.
 */

import { initialMetinList } from "../data/initialData";

export const WIDGET_REGISTRY = {
    "market-prices": {
        title: "Piyasa Fiyatları",
        icon: "Coins",
        defaultData: { prices: {} },
        description: "Eşya fiyatlarını görüntüle ve düzenle"
    },
    "character-stats": {
        title: "Karakterim",
        icon: "Sword",
        defaultData: {
            damage: 5000,
            hitsPerSecond: 2.5,
            findTime: 10
        },
        description: "Karakter istatistiklerini yönet"
    },
    "metin-settings": {
        title: "Metin Ayarları",
        icon: "Settings",
        defaultData: {
            metins: initialMetinList
        },
        description: "Metin HP ve drop ayarlarını düzenle"
    },
    "analysis-tool": {
        title: "Analiz & Simülasyon",
        icon: "Calculator",
        defaultData: {},
        description: "Karlılık analizi ve farming stratejisi"
    },
    "damage-progression": {
        title: "Hasar Yol Haritası",
        icon: "Map",
        defaultData: {},
        description: "Hasarınıza göre en verimli metin bölgelerini gösterir."
    },
    "market-supply": {
        title: "Piyasa Arzı",
        icon: "Package",
        defaultData: {},
        description: "Kişisel ve sunucu geneli eşya birikim simülasyonu"
    },
    "crafting-manager": {
        title: "Üretim & Boss",
        icon: "Hammer",
        defaultData: { items: [] },
        description: "Dönüşüm reçeteleri ve boss sandık içeriklerini yönetin."
    },
};
