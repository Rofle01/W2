"use client";

import { useEffect, useRef } from 'react';

export default function InteractiveBackground() {
    const canvasRef = useRef(null);
    const animationFrameIdRef = useRef(null);
    const particlesArrayRef = useRef([]);
    // Mouse etkileşim alanı ve konumu
    const mouseRef = useRef({ x: null, y: null, radius: 150 });

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        let isActive = true;

        // ---------------------------------------------------------
        // 1. Mouse Event Handlers
        // ---------------------------------------------------------
        const handleMouseMove = (e) => {
            mouseRef.current.x = e.x;
            mouseRef.current.y = e.y;
        };

        const handleMouseOut = () => {
            mouseRef.current.x = null;
            mouseRef.current.y = null;
        };

        // ---------------------------------------------------------
        // 2. Particle Class (Parçacık Mantığı)
        // ---------------------------------------------------------
        class Particle {
            constructor(x, y, size, color) {
                this.x = x;
                this.y = y;
                this.size = size;
                this.color = color;
                this.baseX = x;
                this.baseY = y;
                this.density = (Math.random() * 30) + 1;
            }

            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2, false);
                ctx.fillStyle = this.color;
                ctx.fill();
            }

            update() {
                const mouse = mouseRef.current;

                // Fare sahnede değilse orijinal yerine dön
                if (mouse.x === null || mouse.y === null) {
                    if (this.x !== this.baseX) {
                        let dx = this.x - this.baseX;
                        this.x -= dx / 20; // Yumuşak dönüş hızı
                    }
                    if (this.y !== this.baseY) {
                        let dy = this.y - this.baseY;
                        this.y -= dy / 20;
                    }
                    this.draw();
                    return;
                }

                // Fare ile mesafe hesapla
                let dx = mouse.x - this.x;
                let dy = mouse.y - this.y;
                let distance = Math.sqrt(dx * dx + dy * dy);

                // --- FİZİK MOTORU: YUMUŞAK KAÇIŞ ---
                const forceDistance = mouse.radius;

                if (distance < forceDistance) {
                    const forceDirectionX = dx / distance;
                    const forceDirectionY = dy / distance;

                    // Mesafe azaldıkça itme gücü artar (0 ile 1 arası)
                    const force = (forceDistance - distance) / forceDistance;

                    // İtme hızı (Katsayıyı düşürerek yumuşattık: 0.6)
                    const directionX = forceDirectionX * force * this.density * 0.6;
                    const directionY = forceDirectionY * force * this.density * 0.6;

                    this.x -= directionX;
                    this.y -= directionY;
                } else {
                    // Etki alanından çıkınca yerine dön (Elastik efekt)
                    if (this.x !== this.baseX) {
                        let dx = this.x - this.baseX;
                        this.x -= dx / 25;
                    }
                    if (this.y !== this.baseY) {
                        let dy = this.y - this.baseY;
                        this.y -= dy / 25;
                    }
                }
                this.draw();
            }
        }

        // ---------------------------------------------------------
        // 3. Initialization (Başlatma)
        // ---------------------------------------------------------
        function init() {
            particlesArrayRef.current = [];
            // Yoğunluk ayarı: (Ekran Alanı / 20000)
            // Sayıyı artırırsan (örn 15000) daha çok yıldız olur, azaltırsan (25000) daha az.
            let numberOfParticles = (canvas.width * canvas.height) / 20000;

            // Çok küçük ekranlarda veya hata durumunda en az 50 parçacık olsun
            if (numberOfParticles < 50) numberOfParticles = 50;

            for (let i = 0; i < numberOfParticles; i++) {
                const size = (Math.random() * 2) + 0.5; // Boyut
                const x = Math.random() * canvas.width;
                const y = Math.random() * canvas.height;
                // Renk: Hafif transparan beyaz (Siyah üzerinde güzel durur)
                const color = 'rgba(255, 255, 255, 0.6)';

                particlesArrayRef.current.push(new Particle(x, y, size, color));
            }
        }

        // ---------------------------------------------------------
        // 4. Resize Handler
        // ---------------------------------------------------------
        const handleResize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            init(); // Ekran değişince yıldızları yeniden dağıt
        };

        // ---------------------------------------------------------
        // 5. Animation Loop
        // ---------------------------------------------------------
        function animate() {
            if (!isActive || !canvasRef.current) return;

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            for (let i = 0; i < particlesArrayRef.current.length; i++) {
                particlesArrayRef.current[i].update();
            }

            animationFrameIdRef.current = requestAnimationFrame(animate);
        }

        // ---------------------------------------------------------
        // 6. Setup Listeners & Start
        // ---------------------------------------------------------
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseout', handleMouseOut);
        window.addEventListener('resize', handleResize);

        // İlk başlatma
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        init();
        animate();

        // ---------------------------------------------------------
        // 7. Cleanup
        // ---------------------------------------------------------
        return () => {
            isActive = false;
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseout', handleMouseOut);
            window.removeEventListener('resize', handleResize);
            if (animationFrameIdRef.current) {
                cancelAnimationFrame(animationFrameIdRef.current);
            }
        };
    }, []);

    return (
        <canvas
            ref={canvasRef}
            className="fixed inset-0 -z-50 pointer-events-none"
            style={{ background: 'transparent' }} // Arkaplan rengi globals.css'den gelecek
        />
    );
}
