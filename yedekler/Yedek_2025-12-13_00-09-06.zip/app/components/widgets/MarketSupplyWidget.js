"use client";

import { useState, useMemo, useEffect } from "react";
import { Package, User, Users, ChevronDown, Clock } from "lucide-react";
import {
    BarChart, Bar, XAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";
import {
    calculateItemYields,
    generatePlayerDistribution,
    calculateAllMetins,
    getBestMetin,
    formatCompactCurrency
} from "../../lib/calculator";
import { useSharedWidgetData } from "../../hooks/useSharedWidgetData";

// ============================================================================
// TAB 1: PERSONAL ACCUMULATION (Split View)
// ============================================================================
function PersonalAccumulationView({ userStats, metinList, marketItems }) {
    const [selectedMetinId, setSelectedMetinId] = useState(metinList[0]?.id || "");
    const [duration, setDuration] = useState(1);

    // Auto-select first
    useEffect(() => {
        if (!selectedMetinId && metinList?.length > 0) {
            setSelectedMetinId(metinList[0].id);
        }
    }, [metinList, selectedMetinId]);

    const selectedMetin = useMemo(() =>
        metinList.find(m => m.id === selectedMetinId),
        [metinList, selectedMetinId]);

    const results = useMemo(() => {
        if (!selectedMetin || !userStats) return null;
        const safeDuration = duration || 1;
        return calculateItemYields(selectedMetin, userStats, safeDuration);
    }, [selectedMetin, userStats, duration]);

    const getItemName = (targetId) => {
        const item = marketItems.find(i => i.id === targetId || i.originalId === targetId);
        return item ? item.name : targetId;
    };

    return (
        <div className="flex flex-col lg:flex-row h-full gap-6">
            {/* LEFT: SETTINGS (40%) */}
            <div className="lg:w-[40%] flex flex-col gap-6 bg-zinc-900/50 p-6 rounded-xl border border-zinc-800">
                <h3 className="text-zinc-300 font-semibold mb-2">Simülasyon Ayarları</h3>

                <div className="space-y-4">
                    <div>
                        <label className="block text-xs text-zinc-500 mb-1 font-medium">Hangi Metin?</label>
                        <div className="relative">
                            <select
                                value={selectedMetinId}
                                onChange={(e) => setSelectedMetinId(e.target.value)}
                                className="w-full appearance-none bg-zinc-950 border border-zinc-800 text-zinc-200 px-4 py-3 rounded-lg focus:outline-none focus:border-blue-500 font-medium transition-all"
                            >
                                {metinList.map(m => (
                                    <option key={m.id} value={m.id}>{m.name}</option>
                                ))}
                            </select>
                            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 pointer-events-none" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs text-zinc-500 mb-1 font-medium">Süre (Saat)</label>
                        <div className="relative">
                            <input
                                type="number"
                                value={duration}
                                onChange={(e) => {
                                    const val = e.target.value;
                                    setDuration(val === "" ? "" : Number(val));
                                }}
                                className="w-full bg-zinc-950 border border-zinc-800 text-zinc-200 px-4 py-3 rounded-lg focus:outline-none focus:border-blue-500 font-mono font-medium transition-all"
                                min="1"
                            />
                            <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 pointer-events-none" />
                        </div>
                    </div>
                </div>

                <div className="mt-auto bg-blue-900/10 p-4 rounded-lg border border-blue-900/30">
                    <h4 className="font-bold text-blue-400">Tahmini Sonuç</h4>
                    {results && (
                        <p className="text-sm text-zinc-400 mt-1">
                            {duration} saatte <span className="text-white font-bold">{Math.floor(results.metinsCount)}</span> adet {selectedMetin?.name} kesimi
                        </p>
                    )}
                </div>
            </div>

            {/* RIGHT: RESULTS (60%) */}
            <div className="lg:w-[60%] flex flex-col bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden">
                <div className="p-4 border-b border-zinc-800 bg-zinc-900/80">
                    <h4 className="font-semibold text-zinc-200">Elde Edilen Eşyalar</h4>
                </div>
                <div className="flex-1 overflow-y-auto p-2">
                    {results ? (
                        <div className="divide-y divide-zinc-800">
                            {results.yields.map((yieldData, idx) => (
                                <div key={idx} className="flex items-center justify-between p-3 hover:bg-zinc-800/50 transition-colors">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-xs font-bold text-zinc-400 border border-zinc-700">
                                            {getItemName(yieldData.itemId).charAt(0)}
                                        </div>
                                        <div>
                                            <div className="text-zinc-200 font-medium text-sm">{getItemName(yieldData.itemId)}</div>
                                            <div className="text-xs text-zinc-600">%{yieldData.chance} şans</div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-zinc-100 font-bold font-mono">
                                            {formatCompactCurrency(yieldData.count)}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-zinc-600">
                            <p>Sonuçlar burada görünecek</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// TAB 2: MARKET ACCUMULATION (Split View)
// ============================================================================
function MarketAccumulationView({ userStats, metinList, marketItems, prices, multipliers }) {
    const [playerCount, setPlayerCount] = useState(1000);
    const [distributionType, setDistributionType] = useState("normal");
    const [timeStrategy, setTimeStrategy] = useState("constant");
    const [minDamage, setMinDamage] = useState(1000);
    const [maxDamage, setMaxDamage] = useState(30000);
    const [simulationHours, setSimulationHours] = useState(24);

    const simulationResults = useMemo(() => {
        const segments = generatePlayerDistribution(minDamage, maxDamage, playerCount, distributionType, timeStrategy);
        const totalSupply = {};
        const metinCounts = {};

        segments.forEach(segment => {
            const tempStats = { ...userStats, damage: segment.avgDamage };
            const calculations = calculateAllMetins(metinList, prices, multipliers, tempStats);
            const bestMetinCalc = getBestMetin(calculations);

            if (bestMetinCalc) {
                const bestMetin = metinList.find(m => m.id === bestMetinCalc.metinId);
                if (bestMetin) {
                    const effectiveHours = segment.totalHours * (simulationHours / 24);
                    const yields = calculateItemYields(bestMetin, tempStats, effectiveHours);
                    metinCounts[bestMetin.name] = (metinCounts[bestMetin.name] || 0) + yields.metinsCount;
                    yields.yields.forEach(y => {
                        totalSupply[y.itemId] = (totalSupply[y.itemId] || 0) + y.count;
                    });
                }
            }
        });

        const supplyList = Object.entries(totalSupply)
            .map(([itemId, count]) => {
                const item = marketItems.find(i => i.id === itemId || i.originalId === itemId);
                return {
                    itemId,
                    name: item ? item.name : itemId,
                    count,
                    value: count * (item?.price || 0)
                };
            })
            .sort((a, b) => b.value - a.value);

        return { segments, supplyList, metinCounts };
    }, [minDamage, maxDamage, playerCount, distributionType, timeStrategy, simulationHours, userStats, metinList, prices, multipliers, marketItems]);

    return (
        <div className="flex flex-col lg:flex-row h-full gap-6">
            {/* LEFT: SETTINGS (40%) */}
            <div className="lg:w-[40%] bg-zinc-900/50 p-6 rounded-xl border border-zinc-800 flex flex-col gap-6 overflow-y-auto custom-scrollbar">
                <h3 className="text-zinc-300 font-semibold">Piyasa Senaryosu</h3>

                <div className="space-y-5">
                    {/* Player Count */}
                    <div>
                        <div className="flex justify-between mb-2">
                            <label className="text-xs text-zinc-500 font-medium">Oyuncu Sayısı</label>
                            <span className="text-xs text-blue-400 font-mono">{playerCount}</span>
                        </div>
                        <input
                            type="range" min="100" max="10000" step="100"
                            value={playerCount}
                            onChange={(e) => setPlayerCount(Number(e.target.value))}
                            className="w-full accent-blue-600 h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>

                    {/* Hours */}
                    <div>
                        <div className="flex justify-between mb-2">
                            <label className="text-xs text-zinc-500 font-medium">Ortalama Süre (Saat)</label>
                            <span className="text-xs text-blue-400 font-mono">{simulationHours}h</span>
                        </div>
                        <input
                            type="range" min="1" max="24" step="1"
                            value={simulationHours}
                            onChange={(e) => setSimulationHours(Number(e.target.value))}
                            className="w-full accent-blue-600 h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>

                    {/* Strategies */}
                    <div className="space-y-4">
                        <div>
                            <label className="block text-xs text-zinc-500 mb-1 font-medium">Hasar Dağılım Tipi</label>
                            <select
                                value={distributionType}
                                onChange={(e) => setDistributionType(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-800 text-zinc-300 px-3 py-2 rounded focus:border-blue-500 outline-none"
                            >
                                <option value="normal">Normal (Çan Eğrisi)</option>
                                <option value="uniform">Eşit Dağılım</option>
                                <option value="left-skewed">Düşük Hasar Yoğun</option>
                                <option value="right-skewed">Yüksek Hasar Yoğun</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-xs text-zinc-500 mb-1 font-medium">Oynama Süresi Stratejisi</label>
                            <select
                                value={timeStrategy}
                                onChange={(e) => setTimeStrategy(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-800 text-zinc-300 px-3 py-2 rounded focus:border-blue-500 outline-none"
                            >
                                <option value="constant">Herkes Eşit Süre</option>
                                <option value="linear">Güçlüler Daha Fazla</option>
                                <option value="linear-inverse">Zayıflar Daha Fazla</option>
                                <option value="exponential">Elitler Çok Daha Fazla</option>
                            </select>
                        </div>
                    </div>

                    {/* Damage Range */}
                    <div>
                        <label className="block text-xs text-zinc-500 mb-2 font-medium">Hasar Aralığı (Min - Max)</label>
                        <div className="flex items-center gap-2">
                            <input
                                type="number"
                                value={minDamage}
                                onChange={(e) => setMinDamage(Number(e.target.value))}
                                className="flex-1 bg-zinc-950 border border-zinc-800 px-3 py-2 rounded text-sm text-zinc-300 focus:border-blue-500 outline-none text-center"
                            />
                            <span className="text-zinc-600">-</span>
                            <input
                                type="number"
                                value={maxDamage}
                                onChange={(e) => setMaxDamage(Number(e.target.value))}
                                className="flex-1 bg-zinc-950 border border-zinc-800 px-3 py-2 rounded text-sm text-zinc-300 focus:border-blue-500 outline-none text-center"
                            />
                        </div>
                    </div>
                </div>

                {/* Mini Chart: Player Dist */}
                <div className="mt-6 flex-1 min-h-[150px] bg-zinc-950/50 rounded-lg border border-zinc-800 p-3">
                    <p className="text-xs text-zinc-500 mb-2">Oyuncu Dağılım Önizleme</p>
                    <ResponsiveContainer width="100%" height="90%">
                        <BarChart data={simulationResults.segments}>
                            <Bar dataKey="playerCount" fill="#2563eb" radius={[2, 2, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* RIGHT: RESULTS (60%) */}
            <div className="lg:w-[60%] flex flex-col bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden">
                <div className="p-4 border-b border-zinc-800 bg-zinc-900/80 flex justify-between items-center">
                    <h4 className="font-semibold text-zinc-200">Arz Tablosu</h4>
                    <span className="text-xs text-zinc-500">Toplam {simulationResults.supplyList.length} kalem eşya</span>
                </div>
                <div className="flex-1 overflow-y-auto p-0">
                    <table className="w-full text-left">
                        <thead className="bg-zinc-950 text-zinc-500 text-xs uppercase font-medium sticky top-0">
                            <tr>
                                <th className="p-3">Eşya</th>
                                <th className="p-3 text-right">Miktar</th>
                                <th className="p-3 text-right">Piyasa Değeri</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800">
                            {simulationResults.supplyList.map((item, idx) => (
                                <tr key={idx} className="hover:bg-zinc-800/50 transition-colors">
                                    <td className="p-3 text-zinc-300 text-sm">{item.name}</td>
                                    <td className="p-3 text-right text-zinc-400 text-sm font-mono">{formatCompactCurrency(item.count)}</td>
                                    <td className="p-3 text-right text-blue-400 text-sm font-mono font-bold">{formatCompactCurrency(item.value)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN WIDGET CONTAINER
// ============================================================================
export default function MarketSupplyWidget() {
    const { userStats, metinList, marketItems, craftingItems, prices, multipliers } = useSharedWidgetData();
    const [activeTab, setActiveTab] = useState("personal"); // 'personal' | 'market'

    return (
        <div className="w-full h-full flex flex-col p-8 space-y-6 bg-zinc-950">
            {/* Header */}
            <div className="flex justify-between items-center shrink-0">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-violet-900/20 rounded-xl border border-violet-800/50">
                        <Package className="w-8 h-8 text-violet-400" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-zinc-100">Arz / Talep Simülasyonu</h1>
                        <p className="text-zinc-500 text-sm">Sunucu ekonomisi ve kişisel farming projeksiyonları</p>
                    </div>
                </div>

                {/* Tabs */}
                <div className="bg-zinc-900 p-1 rounded-lg border border-zinc-800 flex">
                    <button
                        onClick={() => setActiveTab("personal")}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'personal' ? 'bg-violet-600 text-white' : 'text-zinc-400 hover:text-white'}`}
                    >
                        <div className="flex items-center gap-2">
                            <User size={16} /> Kişisel
                        </div>
                    </button>
                    <button
                        onClick={() => setActiveTab("market")}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'market' ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white'}`}
                    >
                        <div className="flex items-center gap-2">
                            <Users size={16} /> Piyasa Genel
                        </div>
                    </button>
                </div>
            </div>

            {/* Content Area - Split Panel logic handled inside components */}
            <div className="flex-1 overflow-hidden">
                {activeTab === "personal" ? (
                    <PersonalAccumulationView
                        userStats={userStats}
                        metinList={metinList}
                        marketItems={marketItems}
                    />
                ) : (
                    <MarketAccumulationView
                        userStats={userStats}
                        metinList={metinList}
                        craftingItems={craftingItems}
                        marketItems={marketItems}
                        prices={prices}
                        multipliers={multipliers}
                    />
                )}
            </div>
        </div>
    );
}
