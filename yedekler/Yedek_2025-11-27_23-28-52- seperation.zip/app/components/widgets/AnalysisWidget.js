"use client";

import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { X, EyeOff, TrendingUp, Award, Calculator, BarChart3, Target, AlertCircle, ChevronDown } from "lucide-react";
import {
    BarChart, Bar, LineChart, Line,
    XAxis, YAxis, CartesianGrid, Tooltip, Legend,
    ResponsiveContainer, Cell, ReferenceLine
} from "recharts";
import useWidgetStore from "../../store/useWidgetStore";
import {
    calculateMetinProfit,
    calculateAllMetins,
    getBestMetin,
    formatCurrency,
    formatCompactCurrency,
    formatTime,
} from "../../lib/calculator";
import { initialMetinList } from "../../data/initialData";

// ============================================================================
// HELPER: FIND SIBLING WIDGETS (CONTEXT-AWARE)
// ============================================================================
function useSiblingWidgetData(widgetId) {
    const activeWorkspaceId = useWidgetStore((state) => state.activeWorkspaceId);
    const workspaces = useWidgetStore((state) => state.workspaces);
    const marketItems = useWidgetStore((state) => state.marketItems);

    return useMemo(() => {
        // Find the active workspace
        const activeWorkspace = workspaces.find(ws => ws.id === activeWorkspaceId);
        if (!activeWorkspace) {
            return {
                userStats: { damage: 5000, hitsPerSecond: 2.5, findTime: 10 },
                metinList: initialMetinList,
                marketItems
            };
        }

        // Find sibling widgets in the same workspace
        const characterWidget = activeWorkspace.widgets.find(w => w.type === "character-stats");
        const metinWidget = activeWorkspace.widgets.find(w => w.type === "metin-settings");

        // Use sibling data or defaults
        const userStats = characterWidget?.data || { damage: 5000, hitsPerSecond: 2.5, findTime: 10 };
        const metinList = metinWidget?.data?.metins?.length > 0 ? metinWidget.data.metins : initialMetinList;

        return { userStats, metinList, marketItems };
    }, [activeWorkspaceId, workspaces, marketItems, widgetId]);
}

// ============================================================================
// SUMMARY VIEW (Collapsed)
// ============================================================================
function AnalysisSummaryView({ userStats, metinList, marketItems }) {
    const calculations = useMemo(() => {
        return calculateAllMetins(metinList, marketItems, userStats);
    }, [metinList, marketItems, userStats]);

    const bestMetin = getBestMetin(calculations);

    // Prepare mini chart data (top 5)
    const miniChartData = useMemo(() => {
        return calculations.slice(0, 5).map((calc) => ({
            name: calc.metinName.substring(0, 6),
            profit: calc.hourlyProfit,
        }));
    }, [calculations]);

    if (!bestMetin) {
        return (
            <div className="flex items-center justify-center h-full text-white/50">
                <p>Veri bekleniyor...</p>
            </div>
        );
    }

    return (
        <div className="flex flex-col items-center justify-center h-full w-full overflow-hidden px-4 relative">
            {/* Mini Background Chart */}
            <div className="absolute inset-0 opacity-10 pointer-events-none">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={miniChartData}>
                        <Bar dataKey="profit" fill="#06b6d4" />
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* Best Metin Badge */}
            <div className="flex items-center gap-2 mb-3 relative z-10">
                <Award className="w-6 h-6 text-cyan-400" />
                <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wide">
                    En Karlı Metin
                </span>
            </div>

            {/* Metin Name */}
            <h3 className="text-2xl font-bold text-white mb-4 text-center relative z-10 drop-shadow-[0_0_10px_rgba(6,182,212,0.5)]">
                {bestMetin.metinName}
            </h3>

            {/* Split Stats */}
            <div className="grid grid-cols-2 gap-6 w-full max-w-xs relative z-10">
                <div className="flex flex-col items-center border-r border-white/10 pr-4">
                    <span className="text-xs text-white/60 mb-1">Metin Başı</span>
                    <span className="text-xl font-bold text-cyan-300 font-mono">
                        {formatCompactCurrency(bestMetin.dropValuePerMetin)}
                    </span>
                    <span className="text-xs text-white/50">Yang</span>
                </div>
                <div className="flex flex-col items-center pl-4">
                    <span className="text-xs text-white/60 mb-1 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-violet-400" />
                        Saatte
                    </span>
                    <span className="text-xl font-bold text-violet-300 font-mono">
                        {bestMetin.metinsPerHour.toFixed(1)}
                    </span>
                    <span className="text-xs text-white/50">Adet</span>
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// DETAIL VIEW (Expanded - Executive Summary)
// ============================================================================
function AnalysisDetailView({ userStats, metinList, marketItems }) {
    const [chartType, setChartType] = useState("comparison"); // 'comparison' | 'efficiency'
    const [hourlyCost, setHourlyCost] = useState(0);

    // 1. Basic Calculations
    const calculations = useMemo(() => {
        return calculateAllMetins(metinList, marketItems, userStats);
    }, [metinList, marketItems, userStats]);

    const bestMetin = getBestMetin(calculations);
    const topMetins = useMemo(() => calculations.slice(0, 5), [calculations]);

    // 2. Chart Data: Comparison
    const comparisonData = useMemo(() => {
        return calculations.map((calc) => ({
            name: calc.metinName,
            profit: calc.hourlyProfit,
            isBest: calc.metinId === bestMetin?.metinId,
        }));
    }, [calculations, bestMetin]);

    // 3. Chart Data: Efficiency Curve (Multi-Line for Top 5)
    const efficiencyData = useMemo(() => {
        if (!bestMetin || !marketItems || marketItems.length === 0 || !userStats || !userStats.damage) {
            return null;
        }

        const currentDamage = userStats.damage;
        const minDamage = 100; // Start from near zero
        const maxDamage = Math.max(currentDamage * 2, 10000); // Go up to 2x or at least 10k
        const step = Math.max(100, Math.floor(maxDamage / 50)); // Adaptive step

        const simulations = [];

        // Get full metin objects for top 5
        const targetMetins = topMetins.map(calc =>
            metinList.find(m => m.id === calc.metinId)
        ).filter(Boolean);

        for (let dmg = minDamage; dmg <= maxDamage; dmg += step) {
            const modifiedStats = { ...userStats, damage: dmg };

            const dataPoint = { damage: dmg };

            targetMetins.forEach(metin => {
                const result = calculateMetinProfit(metin, marketItems, modifiedStats);
                // Store profit with metin name as key
                dataPoint[metin.name] = result.hourlyProfit - hourlyCost;
            });

            simulations.push(dataPoint);
        }

        return simulations;
    }, [bestMetin, marketItems, userStats, hourlyCost, metinList, topMetins]);

    // Chart Colors
    const CHART_COLORS = ['#06b6d4', '#8b5cf6', '#d946ef', '#f43f5e', '#eab308'];

    // 4. Softcap Detection
    const softcapWarning = useMemo(() => {
        if (!bestMetin || !userStats) return null;
        const killTime = bestMetin.killTime;
        const findTime = userStats.findTime;

        if (killTime < findTime * 0.1) {
            return {
                active: true,
                message: "Metin kesme süreniz, bulma sürenize göre çok düşük. Hasar artışı artık verimsiz."
            };
        }
        return { active: false };
    }, [bestMetin, userStats]);

    if (!bestMetin) {
        return (
            <div className="flex items-center justify-center h-full text-white/50">
                Veri bekleniyor...
            </div>
        );
    }

    const netHourlyProfit = bestMetin.hourlyProfit - hourlyCost;

    return (
        <div className="h-full flex flex-col space-y-6 overflow-y-auto pr-2">

            {/* TOP SECTION: KPI CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Best Metin Card */}
                <div className="bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-white/5 hover:border-cyan-500/30 transition-colors shadow-sm flex items-center justify-between relative overflow-hidden">
                    <div className="absolute -right-6 -bottom-6 opacity-10">
                        <Award className="w-32 h-32 text-cyan-400" />
                    </div>
                    <div>
                        <p className="text-sm text-white/70 mb-1 flex items-center gap-2">
                            <Award className="w-4 h-4 text-cyan-400" />
                            En Karlı Seçim
                        </p>
                        <h3 className="text-3xl font-bold text-white">
                            {bestMetin.metinName}
                        </h3>
                    </div>
                    <div className="text-right z-10">
                        <p className="text-sm text-white/60">Metin Başı</p>
                        <p className="text-xl font-bold text-cyan-400">
                            {formatCompactCurrency(bestMetin.dropValuePerMetin)}
                        </p>
                    </div>
                </div>

                {/* Profit Card */}
                <div className="bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-white/5 hover:border-cyan-500/30 transition-colors shadow-sm flex items-center justify-between relative overflow-hidden">
                    <div className="absolute -right-6 -bottom-6 opacity-10">
                        <TrendingUp className="w-32 h-32 text-violet-400" />
                    </div>
                    <div>
                        <p className="text-sm text-white/70 mb-1 flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-violet-400" />
                            Tahmini Net Kazanç
                        </p>
                        <h3 className="text-3xl font-bold text-white">
                            {formatCompactCurrency(netHourlyProfit)}
                        </h3>
                        <p className="text-xs text-white/50">Yang / Saat</p>
                    </div>
                    <div className="z-10 bg-black/20 p-2 rounded-lg border border-white/10">
                        <label className="block text-xs text-white/60 mb-1">Saatlik Masraf</label>
                        <input
                            type="number"
                            value={hourlyCost}
                            onChange={(e) => setHourlyCost(Number(e.target.value))}
                            className="w-24 bg-transparent text-right text-white font-bold focus:outline-none border-b border-white/20 focus:border-violet-400 transition-colors"
                            placeholder="0"
                        />
                    </div>
                </div>
            </div>

            {/* CHART SECTION */}
            <div className="bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-white/5 hover:border-cyan-500/30 transition-colors shadow-sm min-h-[350px] flex flex-col">
                <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-white/70" />
                        Analiz Grafiği
                    </h3>

                    {/* Chart Type Selector */}
                    <div className="relative">
                        <select
                            value={chartType}
                            onChange={(e) => setChartType(e.target.value)}
                            className="appearance-none bg-black/50 border border-white/10 text-white px-4 py-2 pr-10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500/50 cursor-pointer font-medium"
                        >
                            <option value="comparison">Metin Karşılaştırması</option>
                            <option value="efficiency">Hasar Verimliliği (Top 5)</option>
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50 pointer-events-none" />
                    </div>
                </div>

                <div className="flex-1 w-full h-full min-h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                        {chartType === "comparison" ? (
                            <BarChart data={comparisonData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                                <XAxis
                                    dataKey="name"
                                    tick={{ fontSize: 12, fill: '#ffffff80' }}
                                    axisLine={false}
                                    tickLine={false}
                                    interval={0}
                                    height={50}
                                    angle={-15}
                                    textAnchor="end"
                                />
                                <YAxis
                                    tick={{ fontSize: 12, fill: '#ffffff80' }}
                                    tickFormatter={(value) => formatCompactCurrency(value)}
                                    axisLine={false}
                                    tickLine={false}
                                />
                                <Tooltip
                                    cursor={{ fill: '#ffffff05' }}
                                    formatter={(value) => [`${formatCurrency(value)} Yang`, 'Saatlik Kazanç']}
                                    contentStyle={{
                                        backgroundColor: '#000000',
                                        border: '1px solid rgba(6, 182, 212, 0.3)',
                                        borderRadius: '8px',
                                        color: '#fff'
                                    }}
                                />
                                <Bar dataKey="profit" radius={[4, 4, 0, 0]}>
                                    {comparisonData.map((entry, index) => (
                                        <Cell
                                            key={`cell-${index}`}
                                            fill={entry.isBest ? "#06b6d4" : "#4b5563"}
                                        />
                                    ))}
                                </Bar>
                            </BarChart>
                        ) : (
                            <LineChart data={efficiencyData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" />
                                <XAxis
                                    dataKey="damage"
                                    tick={{ fontSize: 12, fill: '#ffffff80' }}
                                    tickFormatter={(value) => formatCompactCurrency(value)}
                                    label={{ value: 'Hasar', position: 'insideBottom', offset: -5, fill: '#ffffff60', fontSize: 12 }}
                                />
                                <YAxis
                                    tick={{ fontSize: 12, fill: '#ffffff80' }}
                                    tickFormatter={(value) => formatCompactCurrency(value)}
                                />
                                <Tooltip
                                    formatter={(value, name) => [`${formatCurrency(value)} Yang`, name]}
                                    labelFormatter={(label) => `Hasar: ${formatCurrency(label)}`}
                                    contentStyle={{
                                        backgroundColor: '#000000',
                                        border: '1px solid rgba(6, 182, 212, 0.3)',
                                        borderRadius: '8px',
                                        color: '#fff'
                                    }}
                                    itemSorter={(item) => -item.value} // Sort by profit descending
                                />
                                <Legend wrapperStyle={{ paddingTop: '10px' }} />
                                <ReferenceLine
                                    x={userStats.damage}
                                    stroke="#ffffff"
                                    strokeDasharray="3 3"
                                    label={{ value: 'Siz', position: 'top', fill: '#ffffff', fontSize: 12 }}
                                />
                                {topMetins.map((metin, index) => (
                                    <Line
                                        key={metin.metinId}
                                        type="monotone"
                                        dataKey={metin.metinName}
                                        stroke={CHART_COLORS[index % CHART_COLORS.length]}
                                        strokeWidth={index === 0 ? 3 : 2}
                                        dot={false}
                                        activeDot={{ r: 6 }}
                                    />
                                ))}
                            </LineChart>
                        )}
                    </ResponsiveContainer>
                </div>
            </div>

            {/* BOTTOM SECTION: SOFTCAP & TABLE */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                {/* Softcap Status */}
                <div className="lg:col-span-1">
                    {softcapWarning?.active ? (
                        <div className="bg-red-500/10 backdrop-blur-xl p-6 rounded-2xl border border-red-500/30 h-full">
                            <div className="flex items-center gap-3 mb-3">
                                <AlertCircle className="w-6 h-6 text-red-400" />
                                <h4 className="font-bold text-white">Softcap Uyarısı</h4>
                            </div>
                            <p className="text-sm text-white/80 leading-relaxed">
                                {softcapWarning.message}
                            </p>
                            <div className="mt-4 p-3 bg-black/20 rounded-lg border border-red-500/20">
                                <p className="text-xs text-red-300">
                                    Öneri: Hasar artırmak yerine metin bulma sürenizi (hareket hızı) iyileştirmeye odaklanın.
                                </p>
                            </div>
                        </div>
                    ) : (
                        <div className="bg-cyan-500/10 backdrop-blur-xl p-6 rounded-2xl border border-cyan-500/30 h-full flex flex-col justify-center items-center text-center">
                            <div className="p-3 bg-cyan-500/20 rounded-full mb-3">
                                <Target className="w-6 h-6 text-cyan-400" />
                            </div>
                            <h4 className="font-bold text-white mb-1">Verimlilik İyi</h4>
                            <p className="text-sm text-white/70">
                                Mevcut hasarınızla henüz softcap sınırına ulaşmadınız. Hasar artışı kârınızı artırmaya devam edecektir.
                            </p>
                        </div>
                    )}
                </div>

                {/* Detailed Table */}
                <div className="lg:col-span-2 bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-white/5 hover:border-cyan-500/30 transition-colors shadow-sm overflow-hidden flex flex-col">
                    <h3 className="text-lg font-semibold text-white mb-4">Detaylı Sıralama</h3>
                    <div className="overflow-auto max-h-[300px] -mr-2 pr-2">
                        <table className="w-full">
                            <thead className="bg-black/60 sticky top-0 backdrop-blur-md z-10">
                                <tr>
                                    <th className="px-3 py-2 text-left text-xs font-semibold text-white/60">Sıra</th>
                                    <th className="px-3 py-2 text-left text-xs font-semibold text-white/60">Metin</th>
                                    <th className="px-3 py-2 text-right text-xs font-semibold text-white/60">Kesim Süresi</th>
                                    <th className="px-3 py-2 text-right text-xs font-semibold text-white/60">Adet/Saat</th>
                                    <th className="px-3 py-2 text-right text-xs font-semibold text-white/60">Kazanç</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {calculations.map((calc, index) => (
                                    <tr
                                        key={calc.metinId}
                                        className={`hover:bg-cyan-500/5 transition-colors ${index === 0 ? "bg-cyan-500/10" : ""}`}
                                    >
                                        <td className="px-3 py-3 text-sm text-white/50">#{index + 1}</td>
                                        <td className="px-3 py-3">
                                            <span className={`text-sm font-medium ${index === 0 ? "text-cyan-400" : "text-white"}`}>
                                                {calc.metinName}
                                            </span>
                                        </td>
                                        <td className="px-3 py-3 text-sm text-white/70 text-right font-mono">
                                            {formatTime(calc.killTime)}
                                        </td>
                                        <td className="px-3 py-3 text-sm text-violet-300 text-right font-mono">
                                            {calc.metinsPerHour.toFixed(1)}
                                        </td>
                                        <td className="px-3 py-3 text-right">
                                            <span className={`text-sm font-bold font-mono ${index === 0 ? "text-cyan-400" : "text-white/90"}`}>
                                                {formatCompactCurrency(calc.hourlyProfit)}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}

// ============================================================================
// MAIN ANALYSIS WIDGET COMPONENT
// ============================================================================
export default function AnalysisWidget({ id, data, isSelected, onClick, onHide }) {
    // Get context-aware data from sibling widgets
    const { userStats, metinList, marketItems } = useSiblingWidgetData(id);

    return (
        <motion.div
            layoutId={`card-${id}`}
            layout
            onClick={!isSelected ? onClick : undefined}
            className={`group rounded-3xl shadow-2xl cursor-pointer overflow-hidden backdrop-blur-xl border border-white/10 ${isSelected
                ? "fixed inset-0 m-auto w-[90%] h-[90%] max-w-6xl z-[100] bg-black/80"
                : "relative h-64 hover:-translate-y-1 hover:border-cyan-400/50 transition-all duration-300 bg-white/5 hover:bg-white/10"
                }`}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
            {/* SUMMARY VIEW (Collapsed) */}
            {!isSelected && (
                <>
                    <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => {
                            e.stopPropagation();
                            onHide && onHide();
                        }}
                        className="absolute top-4 right-4 z-20 p-2 bg-white/10 backdrop-blur-sm shadow-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-white/60 hover:text-cyan-400 hover:bg-cyan-500/20 border border-white/20"
                    >
                        <EyeOff className="w-4 h-4" />
                    </motion.button>

                    <div className="w-full h-full p-6 relative">
                        <Calculator className="absolute -bottom-4 -right-4 w-32 h-32 text-white/5 opacity-50 rotate-12 pointer-events-none" />
                        <AnalysisSummaryView userStats={userStats} metinList={metinList} marketItems={marketItems} />
                    </div>
                </>
            )}

            {/* DETAIL VIEW (Expanded) */}
            {isSelected && (
                <div className="flex flex-col h-full bg-black/20">
                    <div className="flex items-center justify-between p-8 border-b border-white/20 bg-white/5 backdrop-blur-xl">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                                <Calculator className="w-8 h-8 text-cyan-400" />
                            </div>
                            <div>
                                <motion.h2
                                    layoutId={`title-${id}`}
                                    className="text-2xl font-bold text-white"
                                >
                                    Analiz & Simülasyon
                                </motion.h2>
                                <p className="text-white/60">
                                    Karlılık analizi ve en iyi farming stratejisi
                                </p>
                            </div>
                        </div>

                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick();
                            }}
                            className="p-2 hover:bg-white/10 rounded-full transition-colors backdrop-blur-sm border border-white/10 hover:border-white/20"
                        >
                            <X className="w-6 h-6 text-white/80" />
                        </button>
                    </div>

                    <div className="flex-1 p-8 overflow-hidden">
                        <AnalysisDetailView userStats={userStats} metinList={metinList} marketItems={marketItems} />
                    </div>
                </div>
            )}
        </motion.div>
    );
}
